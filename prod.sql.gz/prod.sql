--
-- PostgreSQL database dump
--

\restrict 1Zpiw87ABIhhd1Uujbq4RYCe3wgfQmIsacqHae9HMEU54fzRiTy5b9d5vmjwr7V

-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    name character varying(150) NOT NULL,
    type character varying(20) NOT NULL,
    balance integer NOT NULL,
    daily_change integer NOT NULL,
    color character varying(7) NOT NULL,
    is_system boolean NOT NULL
);


--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_logs (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    event_type character varying(40) NOT NULL,
    title character varying(200) NOT NULL,
    actor_name character varying(100),
    entity_type character varying(30),
    entity_id integer,
    color character varying(7),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: agent_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_jobs (
    id integer NOT NULL,
    inbound_event_id integer NOT NULL,
    status character varying(10) DEFAULT 'pending'::character varying NOT NULL,
    attempt integer DEFAULT 0 NOT NULL,
    claimed_at timestamp without time zone,
    finished_at timestamp without time zone,
    last_error character varying(500),
    run_after timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agent_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agent_jobs_id_seq OWNED BY public.agent_jobs.id;


--
-- Name: ai_chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_chat_messages (
    id integer NOT NULL,
    session_id integer NOT NULL,
    role character varying(10) NOT NULL,
    text text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    action_jti character varying(36),
    rating integer,
    undo json,
    request_id character varying(32)
);


--
-- Name: ai_chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_chat_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_chat_messages_id_seq OWNED BY public.ai_chat_messages.id;


--
-- Name: ai_chat_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_chat_sessions (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    user_id integer,
    title character varying(200) NOT NULL,
    preview character varying(500),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_chat_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_chat_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_chat_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_chat_sessions_id_seq OWNED BY public.ai_chat_sessions.id;


--
-- Name: ai_studio_facts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_studio_facts (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    text character varying(200) NOT NULL,
    author_user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_studio_facts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_studio_facts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_studio_facts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_studio_facts_id_seq OWNED BY public.ai_studio_facts.id;


--
-- Name: ai_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_usage (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    surface character varying(20) NOT NULL,
    model character varying(60) NOT NULL,
    prompt_tokens integer NOT NULL,
    cached_tokens integer NOT NULL,
    completion_tokens integer NOT NULL,
    cost_micro integer NOT NULL,
    billable boolean NOT NULL,
    sender_ref character varying(64),
    tools character varying(500),
    iterations integer,
    escalated boolean,
    escalation_reason character varying(32),
    escalation_from_model character varying(60),
    request_id character varying(32),
    response_language character varying(8),
    language_source character varying(24)
);


--
-- Name: ai_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_usage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_usage_id_seq OWNED BY public.ai_usage.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: billing_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_invoices (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    user_id integer,
    plan_name character varying(100) NOT NULL,
    amount integer NOT NULL,
    payment_method character varying(50),
    paid_at timestamp without time zone DEFAULT now() NOT NULL,
    status character varying(20) NOT NULL,
    pdf_url character varying(500),
    order_id character varying(100),
    period_months integer DEFAULT 1 NOT NULL,
    stripe_invoice_id character varying(255),
    hosted_invoice_url character varying(500),
    kind character varying(20) DEFAULT 'subscription'::character varying NOT NULL,
    due_at timestamp without time zone,
    reminder_sent_at timestamp without time zone,
    period character varying(7)
);


--
-- Name: billing_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.billing_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: billing_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.billing_invoices_id_seq OWNED BY public.billing_invoices.id;


--
-- Name: booking_channel_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.booking_channel_configs (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    channel_type character varying(20) NOT NULL,
    is_active boolean NOT NULL,
    connected_at timestamp without time zone,
    config json
);


--
-- Name: booking_channel_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.booking_channel_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: booking_channel_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.booking_channel_configs_id_seq OWNED BY public.booking_channel_configs.id;


--
-- Name: branch_working_hours; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branch_working_hours (
    id integer NOT NULL,
    branch_id integer NOT NULL,
    day_of_week integer NOT NULL,
    is_open boolean DEFAULT true NOT NULL,
    open_time character varying(5) NOT NULL,
    close_time character varying(5) NOT NULL
);


--
-- Name: branch_working_hours_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.branch_working_hours_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: branch_working_hours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.branch_working_hours_id_seq OWNED BY public.branch_working_hours.id;


--
-- Name: channel_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_threads (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    channel character varying(20) NOT NULL,
    sender_ref character varying(128) NOT NULL,
    lease_owner character varying(64),
    lease_until timestamp without time zone,
    lease_seq bigint DEFAULT '0'::bigint NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    search_version integer DEFAULT 0 NOT NULL,
    search_state json,
    search_state_at timestamp without time zone
);


--
-- Name: channel_threads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.channel_threads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_threads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.channel_threads_id_seq OWNED BY public.channel_threads.id;


--
-- Name: client_email_otp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_email_otp (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    email character varying(255) NOT NULL,
    code_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    attempts integer DEFAULT 0 NOT NULL
);


--
-- Name: client_email_otp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.client_email_otp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: client_email_otp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.client_email_otp_id_seq OWNED BY public.client_email_otp.id;


--
-- Name: client_loyalty_cards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_loyalty_cards (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    client_id integer NOT NULL,
    level_id integer,
    points_balance integer NOT NULL,
    total_spent integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    deposit_balance integer DEFAULT 0 NOT NULL
);


--
-- Name: client_loyalty_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.client_loyalty_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: client_loyalty_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.client_loyalty_cards_id_seq OWNED BY public.client_loyalty_cards.id;


--
-- Name: client_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_notes (
    id integer NOT NULL,
    client_id integer NOT NULL,
    studio_id integer NOT NULL,
    author_id integer,
    text text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: client_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.client_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: client_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.client_notes_id_seq OWNED BY public.client_notes.id;


--
-- Name: client_offers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_offers (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    client_id integer NOT NULL,
    discount_type character varying(10) NOT NULL,
    value integer NOT NULL,
    reason character varying(20) NOT NULL,
    scope character varying(20) NOT NULL,
    valid_until date,
    is_used boolean NOT NULL,
    used_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_offer_discount_type CHECK (((discount_type)::text = ANY ((ARRAY['percent'::character varying, 'amount'::character varying])::text[]))),
    CONSTRAINT check_offer_reason CHECK (((reason)::text = ANY ((ARRAY['scenario'::character varying, 'manual'::character varying, 'campaign'::character varying])::text[]))),
    CONSTRAINT check_offer_scope CHECK (((scope)::text = ANY ((ARRAY['renewal'::character varying, 'any'::character varying])::text[])))
);


--
-- Name: client_offers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.client_offers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: client_offers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.client_offers_id_seq OWNED BY public.client_offers.id;


--
-- Name: client_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_payments (
    id integer NOT NULL,
    client_id integer NOT NULL,
    amount integer NOT NULL,
    description character varying(255) NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    action_type character varying(50) NOT NULL,
    item_key character varying(50) NOT NULL,
    CONSTRAINT check_payment_status CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'pending'::character varying, 'failed'::character varying])::text[])))
);


--
-- Name: client_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.client_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: client_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.client_payments_id_seq OWNED BY public.client_payments.id;


--
-- Name: client_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_subscriptions (
    id integer NOT NULL,
    client_id integer NOT NULL,
    type character varying(100) NOT NULL,
    total_classes integer NOT NULL,
    used_classes integer NOT NULL,
    expires_at date NOT NULL,
    status character varying(20) NOT NULL,
    is_frozen boolean DEFAULT false NOT NULL,
    frozen_at timestamp without time zone,
    freeze_until timestamp without time zone,
    package_id integer,
    created_at timestamp without time zone DEFAULT now(),
    starts_at date,
    duration_days integer DEFAULT 90 NOT NULL
);


--
-- Name: client_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.client_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: client_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.client_subscriptions_id_seq OWNED BY public.client_subscriptions.id;


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    tg_id bigint,
    name character varying(100) NOT NULL,
    phone character varying(20),
    registration_date timestamp without time zone DEFAULT now() NOT NULL,
    notifs_enabled boolean NOT NULL,
    reminders_enabled boolean NOT NULL,
    last_name character varying(100),
    email character varying(255),
    birth_date date,
    city character varying(100),
    avatar_color character varying(7),
    status character varying(20) DEFAULT 'new'::character varying NOT NULL,
    tags json,
    last_visit_date date,
    is_active boolean DEFAULT true NOT NULL,
    source character varying(30),
    invite_code character varying(12),
    ig_id character varying(50),
    phone_verified boolean DEFAULT false NOT NULL
);


--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: counterparties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.counterparties (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    name character varying(200) NOT NULL,
    counterparty_type character varying(30) NOT NULL,
    inn character varying(12),
    category character varying(100) NOT NULL,
    balance integer NOT NULL,
    deals_count integer NOT NULL,
    color character varying(7) NOT NULL
);


--
-- Name: counterparties_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.counterparties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: counterparties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.counterparties_id_seq OWNED BY public.counterparties.id;


--
-- Name: daily_metric_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_metric_snapshots (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    date date NOT NULL,
    revenue integer NOT NULL,
    new_clients integer NOT NULL,
    total_bookings integer NOT NULL,
    cancelled_bookings integer NOT NULL,
    retention_rate double precision
);


--
-- Name: daily_metric_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.daily_metric_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_metric_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.daily_metric_snapshots_id_seq OWNED BY public.daily_metric_snapshots.id;


--
-- Name: deposit_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deposit_transactions (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    client_id integer NOT NULL,
    amount integer NOT NULL,
    description character varying(200) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: deposit_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deposit_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deposit_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deposit_transactions_id_seq OWNED BY public.deposit_transactions.id;


--
-- Name: event_attendees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_attendees (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    event_id integer NOT NULL,
    client_id integer,
    guest_name character varying(100),
    paid_amount integer NOT NULL,
    attended boolean NOT NULL
);


--
-- Name: event_attendees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.event_attendees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: event_attendees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.event_attendees_id_seq OWNED BY public.event_attendees.id;


--
-- Name: fin_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fin_documents (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    counterparty_id integer,
    title character varying(300) NOT NULL,
    doc_type character varying(50) NOT NULL,
    upload_date timestamp without time zone DEFAULT now() NOT NULL,
    amount integer,
    status character varying(20) NOT NULL,
    file_ext character varying(10) NOT NULL,
    file_url character varying(500),
    requires_signature boolean NOT NULL
);


--
-- Name: fin_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fin_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fin_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fin_documents_id_seq OWNED BY public.fin_documents.id;


--
-- Name: financial_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_goals (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    title character varying(200) NOT NULL,
    target_amount integer NOT NULL,
    current_amount integer NOT NULL,
    deadline date,
    category character varying(100),
    color character varying(7) NOT NULL,
    priority character varying(10) NOT NULL,
    tracking_mode character varying(10) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    op_type character varying(3) NOT NULL
);


--
-- Name: financial_goals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.financial_goals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: financial_goals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.financial_goals_id_seq OWNED BY public.financial_goals.id;


--
-- Name: fx_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fx_rates (
    id integer NOT NULL,
    base character varying(3) NOT NULL,
    code character varying(3) NOT NULL,
    rate double precision NOT NULL,
    fetched_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: fx_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fx_rates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fx_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fx_rates_id_seq OWNED BY public.fx_rates.id;


--
-- Name: gift_certificates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gift_certificates (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    client_id integer,
    recipient_name character varying(100),
    code character varying(50) NOT NULL,
    amount integer NOT NULL,
    cert_type character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    issued_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at date,
    used_at timestamp without time zone,
    CONSTRAINT check_cert_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'used'::character varying, 'expired'::character varying])::text[])))
);


--
-- Name: gift_certificates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gift_certificates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gift_certificates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gift_certificates_id_seq OWNED BY public.gift_certificates.id;


--
-- Name: halls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.halls (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(7),
    capacity integer NOT NULL,
    is_online boolean NOT NULL,
    is_active boolean NOT NULL,
    branch_id integer,
    area double precision,
    equipment json,
    hourly_rate double precision,
    photo_url character varying(500)
);


--
-- Name: halls_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.halls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: halls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.halls_id_seq OWNED BY public.halls.id;


--
-- Name: inbound_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inbound_events (
    id integer NOT NULL,
    provider character varying(20) NOT NULL,
    provider_event_id character varying(200) NOT NULL,
    studio_id integer NOT NULL,
    event_type character varying(30) NOT NULL,
    sender_ref character varying(128) NOT NULL,
    text text NOT NULL,
    payload_sha256 character varying(64) NOT NULL,
    received_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: inbound_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inbound_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inbound_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inbound_events_id_seq OWNED BY public.inbound_events.id;


--
-- Name: lessons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lessons (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    name character varying(100) NOT NULL,
    teacher_name character varying(100) NOT NULL,
    start_time timestamp without time zone NOT NULL,
    duration_min integer NOT NULL,
    price integer NOT NULL,
    level character varying(50) NOT NULL,
    equipment character varying(50) NOT NULL,
    total_spots integer NOT NULL,
    teacher_id integer,
    hall_id integer,
    service_id integer,
    status character varying(20) DEFAULT 'scheduled'::character varying NOT NULL,
    cancel_reason character varying(300),
    clients_notified boolean DEFAULT false NOT NULL,
    gcal_event_id character varying(120),
    tz_iana character varying(64)
);


--
-- Name: lessons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lessons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lessons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lessons_id_seq OWNED BY public.lessons.id;


--
-- Name: loyalty_levels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loyalty_levels (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    name character varying(50) NOT NULL,
    color character varying(7) NOT NULL,
    min_threshold integer NOT NULL,
    max_threshold integer,
    sort_order integer NOT NULL,
    point_value integer DEFAULT 1 NOT NULL
);


--
-- Name: loyalty_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.loyalty_levels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: loyalty_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.loyalty_levels_id_seq OWNED BY public.loyalty_levels.id;


--
-- Name: loyalty_point_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loyalty_point_transactions (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    client_id integer NOT NULL,
    points integer NOT NULL,
    description character varying(200) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: loyalty_point_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.loyalty_point_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: loyalty_point_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.loyalty_point_transactions_id_seq OWNED BY public.loyalty_point_transactions.id;


--
-- Name: loyalty_scenarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loyalty_scenarios (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    trigger_type character varying(20) NOT NULL,
    trigger_params json NOT NULL,
    action_type character varying(20) NOT NULL,
    action_params json NOT NULL,
    channel character varying(20) NOT NULL,
    is_enabled boolean NOT NULL,
    fired_count integer NOT NULL,
    last_run_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_scenario_action_type CHECK (((action_type)::text = ANY ((ARRAY['points'::character varying, 'gift_classes'::character varying, 'certificate'::character varying, 'renewal_offer'::character varying])::text[]))),
    CONSTRAINT check_scenario_trigger_type CHECK (((trigger_type)::text = ANY ((ARRAY['inactive_days'::character varying, 'low_subscription'::character varying, 'birthday'::character varying, 'nth_visit'::character varying, 'referral'::character varying])::text[])))
);


--
-- Name: loyalty_scenarios_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.loyalty_scenarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: loyalty_scenarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.loyalty_scenarios_id_seq OWNED BY public.loyalty_scenarios.id;


--
-- Name: notification_event_toggles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_event_toggles (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    role character varying(20) NOT NULL,
    event_id character varying(10) NOT NULL,
    channel_key character varying(20) NOT NULL,
    is_enabled boolean NOT NULL
);


--
-- Name: notification_event_toggles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_event_toggles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_event_toggles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_event_toggles_id_seq OWNED BY public.notification_event_toggles.id;


--
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_logs (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    event_id character varying(10),
    channel character varying(20) NOT NULL,
    recipient_id integer,
    recipient_address character varying(255),
    dedup_key character varying(64) NOT NULL,
    status character varying(10) NOT NULL,
    error character varying(500),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    finished_at timestamp without time zone
);


--
-- Name: notification_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_logs_id_seq OWNED BY public.notification_logs.id;


--
-- Name: offline_transaction_fees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offline_transaction_fees (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    client_id integer,
    sale_amount integer NOT NULL,
    fee_amount integer NOT NULL,
    currency character varying(3) NOT NULL,
    percent_rate double precision NOT NULL,
    payment_method character varying(30),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    invoice_id integer
);


--
-- Name: offline_transaction_fees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.offline_transaction_fees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: offline_transaction_fees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.offline_transaction_fees_id_seq OWNED BY public.offline_transaction_fees.id;


--
-- Name: online_channel_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.online_channel_metrics (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    channel_id integer NOT NULL,
    period_type character varying(10) NOT NULL,
    period_date date NOT NULL,
    amount integer NOT NULL,
    transactions_count integer NOT NULL
);


--
-- Name: online_channel_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.online_channel_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: online_channel_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.online_channel_metrics_id_seq OWNED BY public.online_channel_metrics.id;


--
-- Name: online_channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.online_channels (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    channel_type character varying(30) NOT NULL,
    is_active boolean NOT NULL,
    monthly_amount integer NOT NULL,
    monthly_sessions integer NOT NULL,
    account_id character varying(60)
);


--
-- Name: online_channels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.online_channels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: online_channels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.online_channels_id_seq OWNED BY public.online_channels.id;


--
-- Name: operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operations (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    client_id integer,
    account_id integer,
    counterparty_id integer,
    trainer_id integer,
    product_id integer,
    type character varying(10) NOT NULL,
    title character varying(200) NOT NULL,
    amount integer NOT NULL,
    op_date date NOT NULL,
    category character varying(100) NOT NULL,
    method character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    service_id integer
);


--
-- Name: operations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.operations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: operations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.operations_id_seq OWNED BY public.operations.id;


--
-- Name: outbound_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbound_messages (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    thread_id integer NOT NULL,
    origin character varying(10) DEFAULT 'agent'::character varying NOT NULL,
    payload json NOT NULL,
    dedup_key character varying(120) NOT NULL,
    status character varying(10) DEFAULT 'queued'::character varying NOT NULL,
    attempt integer DEFAULT 0 NOT NULL,
    run_after timestamp without time zone DEFAULT now() NOT NULL,
    locked_by character varying(64),
    locked_at timestamp without time zone,
    provider_message_id character varying(128),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    accepted_at timestamp without time zone,
    last_error character varying(200)
);


--
-- Name: outbound_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.outbound_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: outbound_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.outbound_messages_id_seq OWNED BY public.outbound_messages.id;


--
-- Name: payment_cards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_cards (
    id integer NOT NULL,
    user_id integer NOT NULL,
    card_last4 character varying(4) NOT NULL,
    card_brand character varying(20) NOT NULL,
    card_expiry character varying(5) NOT NULL,
    cardholder_name character varying(100) NOT NULL,
    is_primary boolean NOT NULL,
    rectoken character varying(255),
    method_type character varying(10) DEFAULT 'card'::character varying NOT NULL,
    stripe_customer_id character varying(255)
);


--
-- Name: payment_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_cards_id_seq OWNED BY public.payment_cards.id;


--
-- Name: payment_method_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_method_configs (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    method_type character varying(30) NOT NULL,
    method_name character varying(100) NOT NULL,
    is_enabled boolean NOT NULL,
    commission_rate double precision NOT NULL,
    monthly_transactions integer NOT NULL
);


--
-- Name: payment_method_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_method_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_method_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_method_configs_id_seq OWNED BY public.payment_method_configs.id;


--
-- Name: platform_revenue_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_revenue_ledger (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    source character varying(20) NOT NULL,
    amount integer NOT NULL,
    currency character varying(3) NOT NULL,
    external_id character varying(255) NOT NULL,
    occurred_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: platform_revenue_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.platform_revenue_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_revenue_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.platform_revenue_ledger_id_seq OWNED BY public.platform_revenue_ledger.id;


--
-- Name: product_sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_sales (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    product_id integer,
    client_id integer,
    operation_id integer,
    quantity integer NOT NULL,
    amount integer NOT NULL,
    payment_method character varying(30) NOT NULL,
    is_new_client boolean NOT NULL,
    sold_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: product_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_sales_id_seq OWNED BY public.product_sales.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    name character varying(150) NOT NULL,
    product_type character varying(30) NOT NULL,
    price integer NOT NULL,
    unit_label character varying(30) NOT NULL,
    badge_type character varying(10),
    is_active boolean NOT NULL,
    color character varying(7),
    sort_order integer NOT NULL
);


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: referral_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.referral_records (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    referrer_client_id integer,
    referred_client_id integer,
    status character varying(20) NOT NULL,
    bonus_paid boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    discount_used boolean DEFAULT false NOT NULL,
    CONSTRAINT check_referral_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: referral_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.referral_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: referral_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.referral_records_id_seq OWNED BY public.referral_records.id;


--
-- Name: reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reservations (
    id integer NOT NULL,
    client_id integer NOT NULL,
    lesson_id integer NOT NULL,
    spot_number integer NOT NULL,
    status character varying(20) NOT NULL,
    rating integer,
    review_text character varying(500),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    booking_channel character varying(20),
    cancelled_at timestamp without time zone,
    cancellation_reason character varying(300),
    subscription_id integer,
    coffee boolean DEFAULT false NOT NULL,
    is_trial boolean DEFAULT false NOT NULL,
    debt_payment_id integer,
    CONSTRAINT check_reservation_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'pending'::character varying, 'cancelled'::character varying, 'attended'::character varying])::text[])))
);


--
-- Name: reservations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reservations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reservations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reservations_id_seq OWNED BY public.reservations.id;


--
-- Name: salary_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_payments (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    user_id integer NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    sessions_count integer NOT NULL,
    hours_worked double precision NOT NULL,
    rate_snapshot double precision NOT NULL,
    rate_type_snapshot character varying(10) NOT NULL,
    amount integer NOT NULL,
    status character varying(20) NOT NULL,
    paid_at timestamp without time zone,
    note character varying(300)
);


--
-- Name: salary_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_payments_id_seq OWNED BY public.salary_payments.id;


--
-- Name: scenario_fires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scenario_fires (
    id integer NOT NULL,
    scenario_id integer NOT NULL,
    client_id integer NOT NULL,
    dedup_key character varying(40) NOT NULL,
    fired_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: scenario_fires_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.scenario_fires_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: scenario_fires_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.scenario_fires_id_seq OWNED BY public.scenario_fires.id;


--
-- Name: service_schedule_slots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_schedule_slots (
    id integer NOT NULL,
    service_id integer NOT NULL,
    day_of_week integer NOT NULL,
    start_time character varying(5) NOT NULL,
    end_time character varying(5) NOT NULL
);


--
-- Name: service_schedule_slots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_schedule_slots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_schedule_slots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_schedule_slots_id_seq OWNED BY public.service_schedule_slots.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    name character varying(150) NOT NULL,
    description character varying(500),
    price integer NOT NULL,
    duration_min integer NOT NULL,
    category character varying(100),
    service_type character varying(20),
    color character varying(7),
    max_clients integer,
    bookings_count integer DEFAULT 0 NOT NULL,
    revenue_total integer DEFAULT 0 NOT NULL
);


--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: staff_day_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_day_overrides (
    id integer NOT NULL,
    user_id integer NOT NULL,
    studio_id integer NOT NULL,
    day date NOT NULL,
    is_working boolean DEFAULT true NOT NULL
);


--
-- Name: staff_day_overrides_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_day_overrides_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_day_overrides_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_day_overrides_id_seq OWNED BY public.staff_day_overrides.id;


--
-- Name: staff_working_hours; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_working_hours (
    id integer NOT NULL,
    user_id integer NOT NULL,
    day_of_week integer NOT NULL,
    is_open boolean NOT NULL,
    open_time character varying(5) NOT NULL,
    close_time character varying(5) NOT NULL,
    studio_id integer NOT NULL
);


--
-- Name: staff_working_hours_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_working_hours_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_working_hours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_working_hours_id_seq OWNED BY public.staff_working_hours.id;


--
-- Name: stripe_checkouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stripe_checkouts (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    user_id integer,
    session_id character varying(200) NOT NULL,
    account_id character varying(60) NOT NULL,
    payload json NOT NULL,
    amount integer NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    application_fee integer DEFAULT 0 NOT NULL,
    subscription_id integer
);


--
-- Name: stripe_checkouts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stripe_checkouts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stripe_checkouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stripe_checkouts_id_seq OWNED BY public.stripe_checkouts.id;


--
-- Name: studio_ai_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_ai_settings (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    model character varying(30) NOT NULL,
    language character varying(10) NOT NULL,
    system_prompt character varying(2000),
    tg_enabled boolean NOT NULL,
    tg_token character varying(600),
    tg_username character varying(100),
    tg_tone character varying(20) NOT NULL,
    tg_max_length integer NOT NULL,
    tg_handled_count integer NOT NULL,
    tg_avg_rating double precision NOT NULL,
    ig_enabled boolean NOT NULL,
    ig_token character varying(600),
    ig_username character varying(100),
    ig_tone character varying(20) NOT NULL,
    ig_max_length integer NOT NULL,
    ig_off_hours_only boolean NOT NULL,
    ig_handled_count integer NOT NULL,
    ig_avg_rating double precision NOT NULL,
    ig_user_id character varying(50),
    ig_token_expires_at timestamp without time zone,
    wa_enabled boolean DEFAULT false NOT NULL,
    wa_tone character varying(20) DEFAULT 'friendly'::character varying NOT NULL,
    wa_max_length integer DEFAULT 300 NOT NULL,
    wa_off_hours_only boolean DEFAULT false NOT NULL,
    wa_handled_count integer DEFAULT 0 NOT NULL,
    wa_avg_rating double precision DEFAULT '0'::double precision NOT NULL
);


--
-- Name: studio_ai_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_ai_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_ai_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_ai_settings_id_seq OWNED BY public.studio_ai_settings.id;


--
-- Name: studio_billing_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_billing_plans (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    plan_name character varying(100) NOT NULL,
    billing_cycle character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    expires_at timestamp without time zone,
    max_staff integer NOT NULL,
    billing_mode character varying(20) NOT NULL,
    percent_rate double precision,
    fixed_base_amount integer,
    auto_renewal boolean NOT NULL,
    email_receipt_enabled boolean NOT NULL,
    notify_before_days integer NOT NULL,
    sms_notification_enabled boolean NOT NULL,
    notify_before_autocharge boolean DEFAULT true NOT NULL,
    stripe_customer_id character varying(255),
    stripe_subscription_id character varying(255),
    percent_terms_accepted_at timestamp without time zone,
    percent_terms_rate double precision,
    percent_terms_version character varying(20),
    scheduled_plan character varying(100),
    scheduled_at timestamp without time zone,
    trial_started_at timestamp without time zone
);


--
-- Name: studio_billing_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_billing_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_billing_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_billing_plans_id_seq OWNED BY public.studio_billing_plans.id;


--
-- Name: studio_booking_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_booking_settings (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    booking_active boolean NOT NULL,
    prefill_on_booking boolean NOT NULL,
    trainer_confirmation_required boolean NOT NULL,
    repeat_booking_allowed boolean NOT NULL,
    min_booking_advance_min integer NOT NULL,
    booking_window_days integer NOT NULL,
    cancellation_deadline_min integer NOT NULL,
    widget_accent_color character varying(7) NOT NULL,
    widget_logo_url character varying(500),
    widget_dark_mode boolean NOT NULL,
    widget_language character varying(5) NOT NULL,
    reminder_24h boolean NOT NULL,
    reminder_2h boolean NOT NULL,
    review_request boolean NOT NULL,
    miniapp_generated boolean NOT NULL,
    widget_work_start character varying(5) NOT NULL,
    widget_work_end character varying(5) NOT NULL,
    coffee_enabled boolean DEFAULT true NOT NULL,
    coffee_spots json,
    trial_lesson_free boolean DEFAULT false NOT NULL
);


--
-- Name: studio_booking_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_booking_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_booking_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_booking_settings_id_seq OWNED BY public.studio_booking_settings.id;


--
-- Name: studio_branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_branches (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    name character varying(150) NOT NULL,
    phone character varying(20),
    email character varying(255),
    address character varying(300),
    country character varying(100),
    city character varying(100),
    photo_url character varying(500)
);


--
-- Name: studio_branches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_branches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_branches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_branches_id_seq OWNED BY public.studio_branches.id;


--
-- Name: studio_certificate_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_certificate_configs (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    is_enabled boolean NOT NULL,
    cert_type character varying(20) NOT NULL,
    expiry_days integer NOT NULL,
    denominations json,
    service_id integer
);


--
-- Name: studio_certificate_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_certificate_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_certificate_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_certificate_configs_id_seq OWNED BY public.studio_certificate_configs.id;


--
-- Name: studio_client_segment_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_client_segment_configs (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    new_client_days integer DEFAULT 15 NOT NULL,
    active_within_days integer DEFAULT 60 NOT NULL,
    vip_min_spent integer DEFAULT 50000 NOT NULL,
    vip_min_visits integer DEFAULT 30 NOT NULL
);


--
-- Name: studio_client_segment_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_client_segment_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_client_segment_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_client_segment_configs_id_seq OWNED BY public.studio_client_segment_configs.id;


--
-- Name: studio_discount_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_discount_configs (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    is_enabled boolean NOT NULL,
    discount_type character varying(20) NOT NULL,
    discount_value integer NOT NULL,
    min_purchase_amount integer,
    applies_to_all_services boolean NOT NULL,
    stackable boolean NOT NULL,
    visible_in_cabinet boolean NOT NULL,
    CONSTRAINT check_studio_discount_type CHECK (((discount_type)::text = ANY ((ARRAY['percentage'::character varying, 'fixed'::character varying, 'cashback'::character varying])::text[])))
);


--
-- Name: studio_discount_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_discount_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_discount_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_discount_configs_id_seq OWNED BY public.studio_discount_configs.id;


--
-- Name: studio_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_events (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    title character varying(200) NOT NULL,
    description character varying(1000),
    event_type character varying(30) NOT NULL,
    status character varying(20) NOT NULL,
    event_date date NOT NULL,
    start_time character varying(5),
    duration_min integer,
    max_attendees integer,
    revenue integer NOT NULL,
    trainer_id integer,
    color character varying(7),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_event_status CHECK (((status)::text = ANY ((ARRAY['upcoming'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: studio_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_events_id_seq OWNED BY public.studio_events.id;


--
-- Name: studio_feature_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_feature_flags (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    flag character varying(50) NOT NULL,
    is_enabled boolean DEFAULT false NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: studio_feature_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_feature_flags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_feature_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_feature_flags_id_seq OWNED BY public.studio_feature_flags.id;


--
-- Name: studio_integrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_integrations (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    integration_type character varying(30) NOT NULL,
    is_connected boolean NOT NULL,
    config json,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: studio_integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_integrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_integrations_id_seq OWNED BY public.studio_integrations.id;


--
-- Name: studio_loyalty_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_loyalty_configs (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    is_enabled boolean NOT NULL,
    program_name character varying(100) NOT NULL,
    points_exchange_rate integer NOT NULL,
    expiry_period character varying(20) NOT NULL
);


--
-- Name: studio_loyalty_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_loyalty_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_loyalty_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_loyalty_configs_id_seq OWNED BY public.studio_loyalty_configs.id;


--
-- Name: studio_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_members (
    id integer NOT NULL,
    user_id integer NOT NULL,
    studio_id integer NOT NULL,
    role character varying(50) NOT NULL,
    department character varying(50),
    salary double precision,
    rate double precision,
    rate_type character varying(20),
    name character varying(100) NOT NULL,
    last_name character varying(100),
    photo_url character varying(500),
    status character varying(20) NOT NULL
);


--
-- Name: studio_members_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_members_id_seq OWNED BY public.studio_members.id;


--
-- Name: studio_notification_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_notification_settings (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    telegram_notifications boolean NOT NULL,
    instagram_notifications boolean NOT NULL,
    whatsapp_notifications boolean NOT NULL,
    email_notifications boolean NOT NULL,
    sms_notifications boolean NOT NULL,
    push_notifications boolean NOT NULL,
    marketing_emails boolean NOT NULL,
    primary_email character varying(255),
    backup_email character varying(255)
);


--
-- Name: studio_notification_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_notification_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_notification_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_notification_settings_id_seq OWNED BY public.studio_notification_settings.id;


--
-- Name: studio_promo_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_promo_codes (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    code character varying(30) NOT NULL,
    discount_type character varying(10) NOT NULL,
    value integer NOT NULL,
    valid_until date,
    usage_limit integer,
    used_count integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_promo_discount_type CHECK (((discount_type)::text = ANY ((ARRAY['percent'::character varying, 'amount'::character varying])::text[])))
);


--
-- Name: studio_promo_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_promo_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_promo_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_promo_codes_id_seq OWNED BY public.studio_promo_codes.id;


--
-- Name: studio_referral_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_referral_configs (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    is_enabled boolean NOT NULL,
    referrer_bonus integer DEFAULT 500 NOT NULL,
    new_client_discount integer NOT NULL,
    trigger_condition character varying(30) NOT NULL,
    bonus_type character varying(20) NOT NULL
);


--
-- Name: studio_referral_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_referral_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_referral_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_referral_configs_id_seq OWNED BY public.studio_referral_configs.id;


--
-- Name: studio_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_reviews (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    client_id integer,
    author_name character varying(100),
    rating integer NOT NULL,
    nps_score integer,
    text character varying(2000),
    source character varying(20) NOT NULL,
    lesson_id integer,
    event_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: studio_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_reviews_id_seq OWNED BY public.studio_reviews.id;


--
-- Name: studio_subscription_program_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_subscription_program_configs (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    is_enabled boolean NOT NULL,
    allow_freeze boolean NOT NULL,
    allow_transfer boolean NOT NULL,
    auto_renewal boolean NOT NULL
);


--
-- Name: studio_subscription_program_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_subscription_program_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_subscription_program_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_subscription_program_configs_id_seq OWNED BY public.studio_subscription_program_configs.id;


--
-- Name: studio_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_tasks (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    author_id integer,
    text character varying(500) NOT NULL,
    priority character varying(10) NOT NULL,
    tag character varying(50) NOT NULL,
    is_done boolean NOT NULL,
    done_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    assignee_id integer
);


--
-- Name: studio_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_tasks_id_seq OWNED BY public.studio_tasks.id;


--
-- Name: studio_working_hours; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studio_working_hours (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    day_of_week integer NOT NULL,
    is_open boolean NOT NULL,
    open_time character varying(5) NOT NULL,
    close_time character varying(5) NOT NULL
);


--
-- Name: studio_working_hours_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studio_working_hours_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studio_working_hours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studio_working_hours_id_seq OWNED BY public.studio_working_hours.id;


--
-- Name: studios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.studios (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    phone character varying(20),
    business_type character varying(50),
    business_subtype character varying(50),
    timezone character varying(50),
    language character varying(10),
    currency character varying(10),
    description character varying(500),
    email character varying(255),
    website character varying(255),
    address character varying(300),
    logo_url character varying(500),
    date_format character varying(20),
    first_day_of_week character varying(10),
    journal_time_step integer DEFAULT 30 NOT NULL,
    country character varying(2),
    postal_code character varying(20),
    vat_id character varying(50),
    company_id character varying(30),
    city character varying(100),
    tz_iana character varying(64)
);


--
-- Name: studios_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.studios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: studios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.studios_id_seq OWNED BY public.studios.id;


--
-- Name: subscription_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_packages (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    config_id integer NOT NULL,
    name character varying(100) NOT NULL,
    class_count integer NOT NULL,
    price integer NOT NULL,
    per_visit_price integer NOT NULL,
    is_active boolean NOT NULL,
    sort_order integer NOT NULL,
    duration_days integer DEFAULT 90 NOT NULL,
    service_ids json,
    sold_as_single boolean NOT NULL,
    sold_as_subscription boolean NOT NULL
);


--
-- Name: subscription_packages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscription_packages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscription_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscription_packages_id_seq OWNED BY public.subscription_packages.id;


--
-- Name: thread_options; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.thread_options (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    thread_id integer NOT NULL,
    token character varying(64) NOT NULL,
    search_version integer NOT NULL,
    ordinal integer NOT NULL,
    lesson_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone NOT NULL
);


--
-- Name: thread_options_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.thread_options_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: thread_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.thread_options_id_seq OWNED BY public.thread_options.id;


--
-- Name: trainer_sales_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trainer_sales_goals (
    id integer NOT NULL,
    studio_id integer NOT NULL,
    user_id integer NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    target_revenue integer NOT NULL,
    target_sessions integer NOT NULL,
    actual_revenue integer NOT NULL,
    actual_sessions integer NOT NULL
);


--
-- Name: trainer_sales_goals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trainer_sales_goals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trainer_sales_goals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trainer_sales_goals_id_seq OWNED BY public.trainer_sales_goals.id;


--
-- Name: user_consents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_consents (
    id integer NOT NULL,
    user_id integer NOT NULL,
    version character varying(20) NOT NULL,
    source character varying(20) NOT NULL,
    ip character varying(45),
    user_agent character varying(400),
    accepted_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: user_consents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_consents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_consents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_consents_id_seq OWNED BY public.user_consents.id;


--
-- Name: user_notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_notification_preferences (
    id integer NOT NULL,
    user_id integer NOT NULL,
    event_id character varying(10) NOT NULL,
    channel_key character varying(20) NOT NULL,
    is_enabled boolean NOT NULL
);


--
-- Name: user_notification_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_notification_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_notification_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_notification_preferences_id_seq OWNED BY public.user_notification_preferences.id;


--
-- Name: user_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_services (
    user_id integer NOT NULL,
    service_id integer NOT NULL
);


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device character varying(100) NOT NULL,
    platform character varying(20) NOT NULL,
    browser character varying(50),
    location_city character varying(100),
    location_country character varying(100),
    last_active timestamp without time zone DEFAULT now() NOT NULL,
    is_current boolean NOT NULL,
    token_hash character varying(255) NOT NULL,
    ip_address character varying(45),
    user_agent character varying(300),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    revoked_at timestamp without time zone
);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    name character varying(100) NOT NULL,
    phone character varying(20),
    is_verified boolean NOT NULL,
    verification_code character varying(10),
    is_onboarded boolean DEFAULT false NOT NULL,
    last_name character varying(100),
    photo_url character varying(500),
    avg_rating double precision,
    two_fa_enabled boolean DEFAULT false NOT NULL,
    theme character varying(20),
    accent_color character varying(7),
    account_label character varying(100),
    avatar_gradient character varying(200),
    primary_user_id integer,
    last_online_at date,
    tg_id bigint,
    otp_code_hash character varying(255),
    otp_action character varying(30),
    otp_expires_at timestamp without time zone,
    otp_attempts integer DEFAULT 0 NOT NULL,
    ig_id character varying(50),
    last_studio_id integer,
    language character varying(5),
    billing_country character varying(2),
    billing_line1 character varying(200),
    billing_line2 character varying(200),
    billing_postal_code character varying(20),
    billing_city character varying(100),
    billing_vat_id character varying(30),
    billing_vat_verified boolean DEFAULT false NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: agent_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_jobs ALTER COLUMN id SET DEFAULT nextval('public.agent_jobs_id_seq'::regclass);


--
-- Name: ai_chat_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_messages ALTER COLUMN id SET DEFAULT nextval('public.ai_chat_messages_id_seq'::regclass);


--
-- Name: ai_chat_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_sessions ALTER COLUMN id SET DEFAULT nextval('public.ai_chat_sessions_id_seq'::regclass);


--
-- Name: ai_studio_facts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_studio_facts ALTER COLUMN id SET DEFAULT nextval('public.ai_studio_facts_id_seq'::regclass);


--
-- Name: ai_usage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage ALTER COLUMN id SET DEFAULT nextval('public.ai_usage_id_seq'::regclass);


--
-- Name: billing_invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_invoices ALTER COLUMN id SET DEFAULT nextval('public.billing_invoices_id_seq'::regclass);


--
-- Name: booking_channel_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_channel_configs ALTER COLUMN id SET DEFAULT nextval('public.booking_channel_configs_id_seq'::regclass);


--
-- Name: branch_working_hours id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branch_working_hours ALTER COLUMN id SET DEFAULT nextval('public.branch_working_hours_id_seq'::regclass);


--
-- Name: channel_threads id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_threads ALTER COLUMN id SET DEFAULT nextval('public.channel_threads_id_seq'::regclass);


--
-- Name: client_email_otp id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_email_otp ALTER COLUMN id SET DEFAULT nextval('public.client_email_otp_id_seq'::regclass);


--
-- Name: client_loyalty_cards id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_loyalty_cards ALTER COLUMN id SET DEFAULT nextval('public.client_loyalty_cards_id_seq'::regclass);


--
-- Name: client_notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_notes ALTER COLUMN id SET DEFAULT nextval('public.client_notes_id_seq'::regclass);


--
-- Name: client_offers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_offers ALTER COLUMN id SET DEFAULT nextval('public.client_offers_id_seq'::regclass);


--
-- Name: client_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_payments ALTER COLUMN id SET DEFAULT nextval('public.client_payments_id_seq'::regclass);


--
-- Name: client_subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.client_subscriptions_id_seq'::regclass);


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: counterparties id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.counterparties ALTER COLUMN id SET DEFAULT nextval('public.counterparties_id_seq'::regclass);


--
-- Name: daily_metric_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_metric_snapshots ALTER COLUMN id SET DEFAULT nextval('public.daily_metric_snapshots_id_seq'::regclass);


--
-- Name: deposit_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deposit_transactions ALTER COLUMN id SET DEFAULT nextval('public.deposit_transactions_id_seq'::regclass);


--
-- Name: event_attendees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendees ALTER COLUMN id SET DEFAULT nextval('public.event_attendees_id_seq'::regclass);


--
-- Name: fin_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fin_documents ALTER COLUMN id SET DEFAULT nextval('public.fin_documents_id_seq'::regclass);


--
-- Name: financial_goals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_goals ALTER COLUMN id SET DEFAULT nextval('public.financial_goals_id_seq'::regclass);


--
-- Name: fx_rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fx_rates ALTER COLUMN id SET DEFAULT nextval('public.fx_rates_id_seq'::regclass);


--
-- Name: gift_certificates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_certificates ALTER COLUMN id SET DEFAULT nextval('public.gift_certificates_id_seq'::regclass);


--
-- Name: halls id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.halls ALTER COLUMN id SET DEFAULT nextval('public.halls_id_seq'::regclass);


--
-- Name: inbound_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inbound_events ALTER COLUMN id SET DEFAULT nextval('public.inbound_events_id_seq'::regclass);


--
-- Name: lessons id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lessons ALTER COLUMN id SET DEFAULT nextval('public.lessons_id_seq'::regclass);


--
-- Name: loyalty_levels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_levels ALTER COLUMN id SET DEFAULT nextval('public.loyalty_levels_id_seq'::regclass);


--
-- Name: loyalty_point_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_point_transactions ALTER COLUMN id SET DEFAULT nextval('public.loyalty_point_transactions_id_seq'::regclass);


--
-- Name: loyalty_scenarios id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_scenarios ALTER COLUMN id SET DEFAULT nextval('public.loyalty_scenarios_id_seq'::regclass);


--
-- Name: notification_event_toggles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_event_toggles ALTER COLUMN id SET DEFAULT nextval('public.notification_event_toggles_id_seq'::regclass);


--
-- Name: notification_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs ALTER COLUMN id SET DEFAULT nextval('public.notification_logs_id_seq'::regclass);


--
-- Name: offline_transaction_fees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offline_transaction_fees ALTER COLUMN id SET DEFAULT nextval('public.offline_transaction_fees_id_seq'::regclass);


--
-- Name: online_channel_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_channel_metrics ALTER COLUMN id SET DEFAULT nextval('public.online_channel_metrics_id_seq'::regclass);


--
-- Name: online_channels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_channels ALTER COLUMN id SET DEFAULT nextval('public.online_channels_id_seq'::regclass);


--
-- Name: operations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations ALTER COLUMN id SET DEFAULT nextval('public.operations_id_seq'::regclass);


--
-- Name: outbound_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbound_messages ALTER COLUMN id SET DEFAULT nextval('public.outbound_messages_id_seq'::regclass);


--
-- Name: payment_cards id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_cards ALTER COLUMN id SET DEFAULT nextval('public.payment_cards_id_seq'::regclass);


--
-- Name: payment_method_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_method_configs ALTER COLUMN id SET DEFAULT nextval('public.payment_method_configs_id_seq'::regclass);


--
-- Name: platform_revenue_ledger id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_revenue_ledger ALTER COLUMN id SET DEFAULT nextval('public.platform_revenue_ledger_id_seq'::regclass);


--
-- Name: product_sales id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_sales ALTER COLUMN id SET DEFAULT nextval('public.product_sales_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: referral_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_records ALTER COLUMN id SET DEFAULT nextval('public.referral_records_id_seq'::regclass);


--
-- Name: reservations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations ALTER COLUMN id SET DEFAULT nextval('public.reservations_id_seq'::regclass);


--
-- Name: salary_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_payments ALTER COLUMN id SET DEFAULT nextval('public.salary_payments_id_seq'::regclass);


--
-- Name: scenario_fires id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scenario_fires ALTER COLUMN id SET DEFAULT nextval('public.scenario_fires_id_seq'::regclass);


--
-- Name: service_schedule_slots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_schedule_slots ALTER COLUMN id SET DEFAULT nextval('public.service_schedule_slots_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: staff_day_overrides id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_day_overrides ALTER COLUMN id SET DEFAULT nextval('public.staff_day_overrides_id_seq'::regclass);


--
-- Name: staff_working_hours id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_working_hours ALTER COLUMN id SET DEFAULT nextval('public.staff_working_hours_id_seq'::regclass);


--
-- Name: stripe_checkouts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stripe_checkouts ALTER COLUMN id SET DEFAULT nextval('public.stripe_checkouts_id_seq'::regclass);


--
-- Name: studio_ai_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_ai_settings ALTER COLUMN id SET DEFAULT nextval('public.studio_ai_settings_id_seq'::regclass);


--
-- Name: studio_billing_plans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_billing_plans ALTER COLUMN id SET DEFAULT nextval('public.studio_billing_plans_id_seq'::regclass);


--
-- Name: studio_booking_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_booking_settings ALTER COLUMN id SET DEFAULT nextval('public.studio_booking_settings_id_seq'::regclass);


--
-- Name: studio_branches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_branches ALTER COLUMN id SET DEFAULT nextval('public.studio_branches_id_seq'::regclass);


--
-- Name: studio_certificate_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_certificate_configs ALTER COLUMN id SET DEFAULT nextval('public.studio_certificate_configs_id_seq'::regclass);


--
-- Name: studio_client_segment_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_client_segment_configs ALTER COLUMN id SET DEFAULT nextval('public.studio_client_segment_configs_id_seq'::regclass);


--
-- Name: studio_discount_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_discount_configs ALTER COLUMN id SET DEFAULT nextval('public.studio_discount_configs_id_seq'::regclass);


--
-- Name: studio_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_events ALTER COLUMN id SET DEFAULT nextval('public.studio_events_id_seq'::regclass);


--
-- Name: studio_feature_flags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_feature_flags ALTER COLUMN id SET DEFAULT nextval('public.studio_feature_flags_id_seq'::regclass);


--
-- Name: studio_integrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_integrations ALTER COLUMN id SET DEFAULT nextval('public.studio_integrations_id_seq'::regclass);


--
-- Name: studio_loyalty_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_loyalty_configs ALTER COLUMN id SET DEFAULT nextval('public.studio_loyalty_configs_id_seq'::regclass);


--
-- Name: studio_members id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_members ALTER COLUMN id SET DEFAULT nextval('public.studio_members_id_seq'::regclass);


--
-- Name: studio_notification_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_notification_settings ALTER COLUMN id SET DEFAULT nextval('public.studio_notification_settings_id_seq'::regclass);


--
-- Name: studio_promo_codes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_promo_codes ALTER COLUMN id SET DEFAULT nextval('public.studio_promo_codes_id_seq'::regclass);


--
-- Name: studio_referral_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_referral_configs ALTER COLUMN id SET DEFAULT nextval('public.studio_referral_configs_id_seq'::regclass);


--
-- Name: studio_reviews id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_reviews ALTER COLUMN id SET DEFAULT nextval('public.studio_reviews_id_seq'::regclass);


--
-- Name: studio_subscription_program_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_subscription_program_configs ALTER COLUMN id SET DEFAULT nextval('public.studio_subscription_program_configs_id_seq'::regclass);


--
-- Name: studio_tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_tasks ALTER COLUMN id SET DEFAULT nextval('public.studio_tasks_id_seq'::regclass);


--
-- Name: studio_working_hours id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_working_hours ALTER COLUMN id SET DEFAULT nextval('public.studio_working_hours_id_seq'::regclass);


--
-- Name: studios id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studios ALTER COLUMN id SET DEFAULT nextval('public.studios_id_seq'::regclass);


--
-- Name: subscription_packages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_packages ALTER COLUMN id SET DEFAULT nextval('public.subscription_packages_id_seq'::regclass);


--
-- Name: thread_options id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_options ALTER COLUMN id SET DEFAULT nextval('public.thread_options_id_seq'::regclass);


--
-- Name: trainer_sales_goals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer_sales_goals ALTER COLUMN id SET DEFAULT nextval('public.trainer_sales_goals_id_seq'::regclass);


--
-- Name: user_consents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_consents ALTER COLUMN id SET DEFAULT nextval('public.user_consents_id_seq'::regclass);


--
-- Name: user_notification_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notification_preferences ALTER COLUMN id SET DEFAULT nextval('public.user_notification_preferences_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (id, studio_id, name, type, balance, daily_change, color, is_system) FROM stdin;
1	1	Основная касса	cash	15200	0	#FCAE91	f
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_logs (id, studio_id, event_type, title, actor_name, entity_type, entity_id, color, created_at) FROM stdin;
1	1	client	Новый клиент: Матвей	Мини-приложение	client	1	#FCAE91	2026-08-16 20:34:35.61973
2	1	payment	Оплата «8 занятий» — Матвей	Sad Mat	subscription	1	#A3C9A8	2026-08-16 20:41:53.560563
3	1	client	Новый клиент: Valeria	Мини-приложение	client	2	#FCAE91	2026-08-16 22:28:38.850266
4	1	payment	Оплата «8 занятий» — Valeria	Sad Mat	subscription	2	#A3C9A8	2026-08-16 22:34:55.529049
5	4	billing	Активирован пробный период на 14 дней	Sadovskiy Matvii	billing_plan	\N	\N	2026-08-17 09:33:55.096484
6	2	billing	Приняты условия постоплаты комиссии 3.0% (ред. 2026-08-4)	Valeri	billing_plan	2	\N	2026-08-31 13:05:13.62635
7	5	billing	Активирован пробный период на 14 дней	Valeria Mesniankina	billing_plan	\N	\N	2026-08-31 13:23:49.272441
8	6	billing	Активирован пробный период на 14 дней	Matvey	billing_plan	\N	\N	2026-08-31 14:02:55.590032
\.


--
-- Data for Name: agent_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_jobs (id, inbound_event_id, status, attempt, claimed_at, finished_at, last_error, run_after) FROM stdin;
\.


--
-- Data for Name: ai_chat_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_chat_messages (id, session_id, role, text, created_at, action_jti, rating, undo, request_id) FROM stdin;
1	1	user	Xxx	2026-08-05 02:48:26.76939	\N	\N	\N	\N
2	1	assistant	Модель Velora AI 3.5 ещё не подключена, но история этого диалога уже сохранена и никуда не пропадёт.	2026-08-05 02:48:26.76939	\N	\N	\N	\N
3	2	user	Как мне создать сотрудников?	2026-08-05 08:28:41.931305	\N	\N	\N	\N
4	2	assistant	Velora AI 3.5 isn't connected yet, but this conversation's history is safely saved.	2026-08-05 08:28:41.931305	\N	\N	\N	\N
5	3	user	Где кнопка создать стафф?	2026-08-16 14:27:12.071616	\N	\N	\N	\N
6	3	assistant	На телефоне: над лентой карточек сотрудников справа находится кнопка **«+»** без подписи. На десктопе: в левой панели **«Команда · N чел.»** в правом верхнем углу заголовка есть кнопка **«+»** без подписи.	2026-08-16 14:27:12.071616	\N	\N	\N	\N
7	3	user	Создай стафф кирил с почтой cartoonlvl2@gmail.com рабочии дни каждый день с 10 по 8	2026-08-16 14:29:29.230041	\N	\N	\N	\N
8	3	assistant	Для создания сотрудника мне не хватает информации о его роли доступа (администратор или тренер). Пожалуйста, уточните.	2026-08-16 14:29:29.230041	\N	\N	\N	\N
9	3	user	тренер с зарплатой почасовой 200, хатха его тренировки	2026-08-16 14:30:13.121962	\N	\N	\N	\N
10	3	assistant	Подтвердите действие: Завести сотрудника Кирилл — (trainer), email cartoonlvl2@gmail.com	2026-08-16 14:30:13.121962	\N	\N	\N	\N
11	4	user	Создай стафф кирил с почтой cartoonlvl2@gmail.com рабочии дни каждый день с 10 по 8	2026-08-16 17:16:25.398928	\N	\N	\N	\N
12	4	assistant	На какую роль доступа мне оформить Кирилла: администратор или тренер? И какой пароль мне использовать для его учетной записи?	2026-08-16 17:16:25.398928	\N	\N	\N	\N
13	4	user	Тренер а пароль КИРИЛ26	2026-08-16 17:16:54.05761	\N	\N	\N	\N
14	4	assistant	Подтвердите действие: Завести сотрудника Кирилл — (trainer), email cartoonlvl2@gmail.com	2026-08-16 17:16:54.05761	\N	\N	\N	\N
15	4	user	Пароль сделай КИРИЛ2026	2026-08-16 17:17:16.178138	\N	\N	\N	\N
16	4	assistant	Подтвердите действие: Завести сотрудника Кирилл — (trainer), email cartoonlvl2@gmail.com	2026-08-16 17:17:16.178138	\N	\N	\N	\N
17	4	assistant	Готово: Завести сотрудника Кирилл — (trainer), email cartoonlvl2@gmail.com	2026-08-16 17:17:19.46492	5e517f7e-eb4a-40b5-b9e0-7e5caae91eec	\N	\N	\N
18	5	user	Создай тренеру Кирил график на следующую всю неделю чтобы он был заняят весь его рабочий  график хатхой	2026-08-16 17:20:15.974208	\N	\N	\N	\N
19	5	assistant	Услуги "хатха" не нашлось. Возможно, вы имели в виду что-то другое? Можете назвать точное название услуги?	2026-08-16 17:20:15.974208	\N	\N	\N	\N
20	5	user	А теперь должжно быть	2026-08-16 17:21:00.160052	\N	\N	\N	\N
21	5	assistant	Для создания расписания тренеру Кириллу на следующую неделю услугой "Хатха" мне нужно знать его id. Подскажите, пожалуйста, id Кирилла.	2026-08-16 17:21:00.160052	\N	\N	\N	\N
22	6	user	Создай тренеру Кирил график на следующую всю неделю чтобы он был заняят весь его рабочий график хатхой	2026-08-16 17:23:09.783744	\N	\N	\N	\N
23	6	assistant	Подтвердите действие: Заполнить расписание: Хатха, тренер Кирилл, 2026-08-18 — 2026-08-24, по 60 мин	2026-08-16 17:23:09.783744	\N	\N	\N	\N
24	6	user	Создай рабочии часы тренеру, чтобы он работал от 8 до 8	2026-08-16 17:24:40.886999	\N	\N	\N	\N
25	6	assistant	Уточните, пожалуйста, какому именно тренеру вы хотите установить рабочие часы?	2026-08-16 17:24:40.886999	\N	\N	\N	\N
26	6	user	Кирилу	2026-08-16 17:24:53.334201	\N	\N	\N	\N
27	6	assistant	Подтвердите действие: Рабочие часы сотрудника Кирилл: ['{"day_of_week": 0, "start_time": "08:00", "end_time": "20:00"}', '{"day_of_week": 1, "start_time": "08:00", "end_time": "20:00"}', '{"day_of_week": 2, "start_time": "08:00", "end_time": "20:00"}', '{"day_of_week": 3, "start_time": "08:00", "end_time": "20:00"}', '{"day_of_week": 4, "start_time": "08:00", "end_time": "20:00"}', '{"day_of_week": 5, "is_open": false}', '{"day_of_week": 6, "is_open": false}']	2026-08-16 17:24:53.334201	\N	\N	\N	\N
28	7	user	Создай тренеру Кирил график на следующую всю неделю чтобы он был заняят весь его рабочий график хатхой	2026-08-16 17:27:23.845809	\N	\N	\N	\N
29	7	assistant	Я могу заполнить расписание для Кирилла на следующую неделю хатхой. Уточните, пожалуйста, со скольки и до скольки он работает, если это не полный рабочий день.	2026-08-16 17:27:23.845809	\N	\N	\N	\N
30	7	user	Сам посмотри	2026-08-16 17:27:42.979519	\N	\N	\N	\N
31	7	assistant	Хорошо, Кирилл работает по будням с 9:00 до 18:00, а в выходные с 10:00 до 16:00.\n\nПрежде чем я заполню расписание, мне нужно уточнить: какой тип услуги "хатха" вы имеете в виду? Я не нашел услуги с таким названием. Уточните, пожалуйста, id услуги.	2026-08-16 17:27:42.979519	\N	\N	\N	\N
32	7	user	Хатху давай	2026-08-16 17:27:56.188639	\N	\N	\N	\N
33	7	assistant	Прошу прощения, произошла ошибка. Сотрудника с ID 2 нет в студии. Есть Sad Mat (#1) и Кирилл (#4).\n\nЯ заполняю расписание для Кирилла (ID 4) на следующую неделю (с 19.08.2026 по 25.08.2026) хатхой, с 9:00 до 18:00 по будням и с 10:00 до 16:00 по выходным.\n	2026-08-16 17:27:56.188639	\N	\N	\N	\N
34	7	assistant	Готово: Заполнить расписание: Хатха, тренер Кирилл, 2026-08-19 — 2026-08-25, по 60 мин	2026-08-16 17:28:07.349586	8acca42d-219c-4d97-9f22-95ff06ea40d7	\N	\N	\N
35	8	user	Создай занятие на 30 августа на 10:00 с кирилом по хатхе	2026-08-16 17:34:22.630764	\N	\N	\N	\N
36	8	assistant	Какова будет продолжительность занятия?	2026-08-16 17:34:22.630764	\N	\N	\N	\N
37	8	user	60 минут	2026-08-16 17:34:32.015326	\N	\N	\N	\N
38	8	assistant	Подтвердите действие: Создать занятие: Хатха, 2026-08-30T10:00:00, тренер Кирилл, мест 8	2026-08-16 17:34:32.015326	\N	\N	\N	\N
39	8	user	Давай 10 сентября	2026-08-16 17:34:48.692075	\N	\N	\N	\N
111	21	user	Ja se ptam  co umis?	2026-08-31 14:08:43.064933	\N	\N	\N	\N
40	8	assistant	Подтвердите действие: Создать занятие: Хатха, 2026-09-10T10:00:00, тренер Кирилл, мест 8, продолжительность 60 минут, цена 1500 UAH.	2026-08-16 17:34:48.692075	\N	\N	\N	\N
41	8	user	создавай	2026-08-16 17:35:00.899626	\N	\N	\N	\N
42	8	assistant	Подтвердите действие: Создать занятие: Хатха, 2026-09-10T10:00:00, тренер Sad Mat, мест 8	2026-08-16 17:35:00.899626	\N	\N	\N	\N
43	8	assistant	Готово: Создать занятие: Хатха, 2026-09-10T10:00:00, тренер Sad Mat, мест 8	2026-08-16 17:35:03.275965	411f7afb-1d09-454f-83e6-a530130cf187	\N	\N	\N
44	9	user	как добавить тренера	2026-08-16 22:09:09.499975	\N	\N	\N	\N
45	9	assistant	Чтобы добавить тренера:\n\n1.  В боковом меню выберите раздел **Сотрудники**.\n2.  На странице справа над списком сотрудников нажмите кнопку **«+»**.\n3.  Заполните данные о сотруднике в открывшемся мастере из 4 шагов.\n\nПосле этого на email сотрудника будет отправлена ссылка-приглашение. Он появится в списке со статусом «Invitation pending» и получит доступ после того, как примет приглашение своим паролем.	2026-08-16 22:09:09.499975	\N	\N	\N	\N
46	10	user	короче мне в падлу это все заполнять можешь мне добавить сотрудников Аня Саша Оля и вика оплата в час по 300 крон и вести они будут стерлинг по вторникам для по средам Саша и по пятницам вика в 9 00 утра и добавь это все в мой журнал на эту неделю	2026-08-16 22:15:31.868366	\N	\N	\N	\N
47	10	assistant	Извини, я не могу выполнить эту задачу. Я не умею работать с кронами: назови сумму в гривнах. Также, пожалуйста, уточни названия дней недели, я не могу понять, что такое "вторникам" и "по средам".	2026-08-16 22:15:31.868366	\N	\N	\N	\N
48	10	user	в гривнах 600 грн вторник и среда день	2026-08-16 22:16:13.686771	\N	\N	\N	\N
49	10	assistant	Подтвердите действие: Завести сотрудника Аня — (trainer), email anya@example.com	2026-08-16 22:16:13.686771	\N	\N	\N	\N
50	10	user	подтвержаю	2026-08-16 22:17:20.710153	\N	\N	\N	\N
51	10	assistant	Подтвердите действие: Завести сотрудника Аня — (trainer), email anya@example.com	2026-08-16 22:17:20.710153	\N	\N	\N	\N
52	10	user	aloyoga3478	2026-08-16 22:18:03.848307	\N	\N	\N	\N
53	10	assistant	Извините, кажется, произошла ошибка. Я не могу создать сотрудника с таким email. Пожалуйста, убедитесь, что email корректный.	2026-08-16 22:18:03.848307	\N	\N	\N	\N
54	10	user	запиши мне занятия для тренера Пети на следующую неделю	2026-08-16 22:18:44.858004	\N	\N	\N	\N
55	10	assistant	Я не могу найти Петю среди сотрудников. Уточните, пожалуйста, полное имя тренера.	2026-08-16 22:18:44.858004	\N	\N	\N	\N
56	10	user	тренер петя	2026-08-16 22:18:54.544573	\N	\N	\N	\N
57	10	assistant	Для Тренера Пети я могу записать занятия, но мне нужно знать, какие именно занятия и в какое время. Укажите, пожалуйста, название услуги, которую будет вести Петя, и желаемое время.	2026-08-16 22:18:54.544573	\N	\N	\N	\N
58	10	user	время вторник 7 утра и четверг 7 вечера	2026-08-16 22:19:15.716837	\N	\N	\N	\N
59	10	assistant	Какое занятие будет вести Петя во вторник в 7 утра и в четверг в 7 вечера?	2026-08-16 22:19:15.716837	\N	\N	\N	\N
60	10	user	бути и абс	2026-08-16 22:19:22.718967	\N	\N	\N	\N
61	10	assistant	Отлично! Каждую неделю будут добавляться два занятия для Тренера Пети:\n\n*   **Вторник**, 7:00: занятие **Booty+Abs**.\n*   **Четверг**, 19:00: занятие **Booty+Abs**.\n\nПодтверждаете?	2026-08-16 22:19:22.718967	\N	\N	\N	\N
62	10	user	да	2026-08-16 22:19:29.591572	\N	\N	\N	\N
63	10	assistant	Подтвердите действие: Заполнить расписание: Booty+Abs, тренер Тренер Петя, 2026-08-18 — 2026-08-24, по 60 мин	2026-08-16 22:19:29.591572	\N	\N	\N	\N
64	10	assistant	Готово: Заполнить расписание: Booty+Abs, тренер Тренер Петя, 2026-08-18 — 2026-08-24, по 60 мин	2026-08-16 22:19:34.322306	ddab2bc4-8830-420e-a6bb-95ccfac84fcb	\N	\N	\N
65	10	user	так шайтан машина расскажи мне что ты можешь и нафигачить ты вообще тут нужен	2026-08-16 22:20:53.516248	\N	\N	\N	\N
66	10	assistant	Я — Velora AI, ваш ассистент в CRM для студий йоги, пилатеса и фитнеса. Я создан для того, чтобы помогать вам управлять студией, автоматизировать рутинные задачи и предоставлять информацию.\n\nЯ могу:\n\n*   **Найти информацию** о клиентах, сотрудниках, расписании, финансах и многом другом. Просто спросите меня, например: "Покажи всех клиентов", "Сколько заработала студия в прошлом месяце?", "Какие занятия у Пети на этой неделе?".\n*   **Выполнять действия**, такие как:\n    *   **Записывать клиентов на занятия** или отменять записи.\n    *   **Создавать новых клиентов** или обновлять их данные.\n    *   **Добавлять новых сотрудников** или изменять их расписание.\n    *   **Заполнять расписание** занятий на несколько дней вперед.\n    *   **Добавлять услуги, залы, филиалы**.\n    *   **Проводить финансовые операции** (доходы, расходы).\n    *   **Начислять баллы лояльности** клиентам.\n    *   И многое другое!\n*   **Открывать нужные разделы** в CRM. Если вам нужно что-то сделать вручную, я могу сразу открыть нужный экран. Например: "Открой карточку клиента Анны", "Покажи создание нового сотрудника".\n*   **Запоминать факты о вашей студии**. Вы можете сказать мне, например: "Запомни, что по воскресеньям мы не работаем", и я буду учитывать это в дальнейших диалогах.\n*   **Настраивать AI-агентов** для автоматических ответов клиентам в мессенджерах.\n\nЯ нужен вам, чтобы вы могли экономить время на административных задачах, получать быстрые ответы на свои вопросы и эффективно управлять вашей студией.	2026-08-16 22:20:53.516248	\N	\N	\N	\N
67	10	user	короче ты умный типа\\	2026-08-16 22:21:45.203535	\N	\N	\N	\N
68	10	assistant	Я стремлюсь быть полезным и эффективным ассистентом, чтобы максимально упростить вашу работу!	2026-08-16 22:21:45.203535	\N	\N	\N	\N
69	10	user	класс а тебе имя можно дать	2026-08-16 22:21:59.513282	\N	\N	\N	\N
70	10	assistant	Вы можете называть меня как угодно! Я Velora AI, и я здесь, чтобы помогать вам.	2026-08-16 22:21:59.513282	\N	\N	\N	\N
71	10	user	хорошо ты будешь хозяин	2026-08-16 22:24:21.893209	\N	\N	\N	\N
72	10	assistant	Хорошо, если вам удобно, можете называть меня Хозяин. Как я могу помочь вам сейчас, Хозяин?	2026-08-16 22:24:21.893209	\N	\N	\N	\N
73	11	user	Надо создать стаф валерия с почтой sadomat31@gmail.com и пусть он работает каждый день с 10 по 10 и он админ	2026-08-16 23:38:04.106068	\N	\N	\N	\N
74	11	assistant	Мне нужен пароль для Валерии. Какой пароль вы хотите установить?	2026-08-16 23:38:04.106068	\N	\N	\N	\N
75	11	user	лето2026	2026-08-16 23:38:18.677463	\N	\N	\N	\N
76	11	assistant	Подтвердите действие: Завести сотрудника Валерия — (admin), email sadomat31@gmail.com	2026-08-16 23:38:18.677463	\N	\N	\N	\N
77	11	assistant	Готово: Завести сотрудника Валерия — (admin), email sadomat31@gmail.com	2026-08-16 23:38:22.74496	9c6220b7-c5d0-4c77-9803-991da435408b	\N	\N	\N
78	12	user	короче мне в падлу это все заполнять можешь мне добавить сотрудников Аня Саша Оля и вика оплата в час по 300 крон и вести они будут стерлинг по вторникам для по средам Саша и по пятницам вика в 9 00 утра и добавь это все в мой журнал на эту неделю	2026-08-18 14:46:06.823499	\N	\N	\N	\N
79	12	assistant	Для добавления сотрудников мне нужны их email, пароли, и какая роль доступа будет у каждого (администратор или тренер). Пожалуйста, уточните эти данные.	2026-08-18 14:46:06.823499	\N	\N	\N	\N
80	13	user	короче мне в падлу это все заполнять можешь мне добавить сотрудников Аня Саша Оля и вика оплата в час по 300 крон и вести они будут стерлинг по вторникам для по средам Саша и по пятницам вика в 9 00 утра и добавь это все в мой журнал на эту неделю	2026-08-18 14:46:28.721915	\N	\N	\N	\N
81	13	assistant	Из	2026-08-18 14:46:28.721915	\N	\N	\N	\N
82	14	user	короче мне в падлу это все заполнять можешь мне добавить сотрудников Аня Саша Оля и вика оплата в час по 300 крон и вести они будут стерлинг по вторникам для по средам Саша и по пятницам вика в 9 00 утра и добавь это все в мой журнал на эту неделю	2026-08-18 14:46:41.750578	\N	\N	\N	\N
83	14	assistant	Я могу добавить сотрудников, но мне нужен пароль для каждого нового сотрудника, а также их email и роль. Пароль вы придумываете сами, а я его передам сотрудникам. Без этих данных создать сотрудников я не смогу.\n\nТакже мне понадобится id услуги "стерлинг", чтобы добавить её в расписание.\n\nЕсли хотите, я могу создать сотрудников с именами Аня, Саша, Оля и Вика с оплатой 300 крон в час, а вы потом добавите остальную информацию.	2026-08-18 14:46:41.750578	\N	\N	\N	\N
84	15	user	короче мне в падлу это все заполнять можешь мне добавить сотрудников Аня Саша Оля и вика оплата в час по 300 крон и вести они будут стерлинг по вторникам для по средам Саша и по пятницам вика в 9 00 утра и добавь это все в мой журнал на эту неделю	2026-08-18 15:44:30.114471	\N	\N	\N	\N
85	15	assistant	Завёл услугу «Стретчинг», подготовил карточки для всех четырёх тренеров (ставка 300 UAH/час) и поставил занятия в расписание на эту неделю в **Зал А** в 09:00:\n\n- **Вторник, 18 августа** — Аня\n- **Среда, 19 августа** — Саша\n- **Пятница, 21 августа** — Вика\n\nОля осталась без занятия в сетке — вы её не распределили по дням. Если нужно поставить и ей, скажите день и время.	2026-08-18 15:44:30.114471	\N	\N	\N	\N
86	15	assistant	Готово: 4 из 8. Не получилось: шаг 2 — Этот человек уже работает в вашей студии; шаг 6 — Пропустил: шаг 2, от которого он зависит, не выполнился; шаг 7 — Не удалось выполнить запрос — попробуйте иначе	2026-08-18 15:46:08.963844	c08256e5-8b41-4157-8f38-f6d38ed3ba79	\N	\N	\N
87	15	user	Создай в журнале занятия на Олю, то есть заполни ее график полностью на три недели вперед и чередуй хатха стретчинг хатха и так далее, и так какдлый ее рабочий час	2026-08-18 15:56:37.614	\N	\N	\N	\N
88	15	assistant	У Оли в карточке вообще не задан рабочий график — часов нет ни на один день, поэтому расписание ставить пока некуда.\n\nНазовите, пожалуйста, по каким дням и с какого до какого часа она работает — задам график и сразу поставлю чередующиеся Хатха/Стретчинг на каждый её рабочий час на три недели вперёд.	2026-08-18 15:56:37.614	\N	\N	\N	\N
89	15	user	Да есть с пн по пт с 9 по 17	2026-08-18 15:57:54.939903	\N	\N	\N	\N
90	15	assistant	Задал Оле график с понедельника по пятницу с 09:00 до 17:00 и заполнил расписание на три недели вперёд (с 18 августа по 7 сентября) в **Зал А**.\n\nЗанятия расставлены на каждый её рабочий час. Чередование услуг «Хатха» и «Стретчинг» можно при необходимости скорректировать прямо в сетке расписания.	2026-08-18 15:57:54.939903	\N	\N	\N	\N
91	15	assistant	Готово: 1 из 2. Не получилось: шаг 1 — Неверные аргументы (schedule.0, schedule.1, schedule.2, schedule.3, schedule.4, schedule.5, schedule.6) — проверьте формат и повторите	2026-08-18 15:58:27.052751	3e91b841-a914-47a9-bbdd-4c1cd2207368	\N	\N	\N
92	15	user	Переделай так чтобы была хатха и стретчинг по очередно	2026-08-18 15:59:55.088518	\N	\N	\N	\N
93	15	assistant	В Velora нет встроенного автоматического шаблона для чередования двух разных услуг через шаг при генерации сетки — расписание заполняется одной выбранной услугой на весь период.\n\nПоскольку занятий у Оли получилось больше 100 на три недели, поменять их на чередование можно несколькими способами:\n1. **В Журнале руками**: кликать на нужные слоты (каждый второй час) и менять услугу на «Стретчинг».\n2. **Точечно через ассистента**: назвать конкретные дни или недели, где заменить каждый второй час с Хатхи на Стретчинг.	2026-08-18 15:59:55.088518	\N	\N	\N	\N
94	16	user	Удали занятия кирила, когда и у Оли занятия, и когда это в одном зале	2026-08-18 16:06:02.586915	\N	\N	\N	\N
95	16	assistant	Смотрю — тут не получается сопоставить по залу технически: у **всех** занятий Кирилла зал вообще не указан (hall_id пустой), а вот у Оли все занятия идут в **«Зал А»**. То есть по критерию «совпадает время И зал» у Кирилла нет ни одного такого занятия — сравнивать не с чем, зала там просто нет в карточке.\n\nПри этом по **времени** занятия действительно пересекаются сплошь: 19 августа у обоих слоты 9:00–17:00 один в один.\n\nУточните: удалить занятия Кирилла, которые просто совпадают по времени с занятиями Оли (без учёта зала, потому что у него зал не заведён), или дело в другом — может, занятия Кирилла на самом деле идут в том же «Зале А», просто это не указано в системе, и стоит сначала это поправить?	2026-08-18 16:06:02.586915	\N	\N	\N	\N
96	17	user	Сделай так чтобы график работы Оли был и в суботу и воскресенье от 10 до 10	2026-08-18 17:31:14.81461	\N	\N	\N	\N
97	17	assistant	Добавил Оле субботу и воскресенье с 10:00 до 22:00, будние дни (пн–пт с 09:00 до 17:00) сохранил. Подтвердите изменение графика в карточке ниже.	2026-08-18 17:31:14.81461	\N	\N	\N	\N
98	18	user	Создай на 29 на 10 тренировку у кирила стретчинг	2026-08-18 17:38:17.026598	\N	\N	\N	\N
99	18	assistant	Оформил создание занятия:\n\n- **Услуга:** Стретчинг\n- **Тренер:** Кирилл\n- **Дата и время:** 29 августа 2026, 10:00\n- **Зал:** Зал А (филиал «Студия»)\n\nПодтвердите создание карточкой ниже.	2026-08-18 17:38:17.026598	\N	\N	\N	\N
100	18	assistant	Готово: Создать занятие: Стретчинг, 2026-08-29T10:00:00, тренер Кирилл, 60 мин.	2026-08-18 17:38:33.916975	460fc42d-79ee-4b6a-b91c-d23e3a7cf664	\N	\N	\N
101	19	user	СЛУШАЙ НАДО ВСЕМ ТРЕНЕРАМ ПОСТАВИТЬ ЗАРПЛАТУ 50000рублей в месяц	2026-08-20 20:47:37.79456	\N	\N	\N	\N
102	19	assistant	Подготовил изменения оклада до 50 000 UAH в месяц для обоих тренеров студии:\n\n* **Кирилл** (тренер) — оклад 50 000 UAH\n* **Оля** (тренер по стретчингу) — оклад 50 000 UAH	2026-08-20 20:47:37.79456	\N	\N	\N	\N
103	20	user	Роскажи о разделе финансов, что там есть, и зачем он нужен, что лучше не нажимать а что лучше я новичок хочу разобраться	2026-08-20 20:49:48.310117	\N	\N	\N	\N
104	20	assistant	Раздел вы sейчас видите сами — сверху девять вкладок, разберём по порядку.\n\n**Что есть в разделе**\n\n| Вкладка | Что там |\n|---|---|\n| Счета и кассы | Общий капитал студии и три системных счёта: Наличные, Карта, Сеть. Тут же можно завести копилку под конкретную цель. |\n| Операции | Лента всех доходов/расходов. Кнопкой «Операция» заносите вручную то, что прошло не через кассу — аренду, закупки, зарплату наличкой и т.п. |\n| Зарплаты | Начисления по каждому сотруднику: ставка, число тренировок, сумма к выплате. Кнопка «Выплатить» проводит реальный расход. |\n| Контрагенты | Арендодатели, поставщики, подрядчики — чтобы привязывать их к операциям и документам. |\n| Документы | Хранилище файлов (договоры, акты), можно отмечать «требует подписи». |\n| Онлайн-платежи | Подключение Stripe и приёма оплат через интернет. |\n| Методы оплаты | Статистика, чем платят клиенты — нал/карта/QR/перевод/Stripe. |\n| Отчёты | Свод за период: выручка, расходы, прибыль, рентабельность, движение денег. |\n| Цели | Финансовые цели студии с прогресс-баром, можно копить вручную или автоматически по метрике. |\n\n**С чего разобраться новичку**\n1. Зайдите в **Счета и кассы** — посмотрите текущие балансы, это ничем не грозит, чисто просмотр.\n2. Загляните в **Операции** — там видно, откуда деньги приходят и куда уходят.\n3. **Отчёты** дадут общую картину за месяц/квартал без лишних движений.\n\n**Что лучше не жать бездумно**\n- Кнопка **«Выплатить»** в Зарплатах — реально проводит расход со счёта и шлёт сотруднику уведомление о начислении. Не тыкайте «посмотреть, что будет» — сразу списывает деньги. Отменить можно («Отменить зарплату»), но лучше сразу быть уверенным.\n- Категория **«Возвраты»** в операции — она не просто пометка, а возвращает студии комиссию платформы. Ставить её на обычный расход не надо, иначе цифры в отчётах поедут.\n- Операция **без указания счёта** не двинет баланс вообще — если хотите, чтобы касса реально изменилась, счёт указывайте.\n- Системные счета (Наличные/Карта/Сеть) удалить нельзя и не нужно — не тратьте время на попытки.\n\nЕсли что-то конкретное хочется — провести операцию, посмотреть баланс, выплатить кому-то зарплату — скажите, сделаю сразу.	2026-08-20 20:49:48.310117	\N	\N	\N	\N
105	21	user	dsd	2026-08-31 14:07:01.254429	\N	\N	\N	\N
106	21	assistant	Привет! Похоже, сообщение получилось случайным — "dsd" ни на что конкретное не похоже.\n\nЧем помочь? Могу глянуть расписание, показать клиентов, заполнить график тренеру, посмотреть финансы — что нужно?	2026-08-31 14:07:01.254429	\N	\N	\N	f9c678907fa045f2b3898e58fadb6538
107	21	user	А что ты можешь?	2026-08-31 14:07:37.121971	\N	\N	\N	\N
108	21	assistant	Я — второй администратор студии, работаю прямо в CRM. Вот что умею:\n\n**Клиенты**\n- находить, создавать, редактировать карточки\n- смотреть абонементы, историю визитов, заметки\n- замораживать, начислять баллы, давать скидки, продавать абонементы\n- искать «спящих» клиентов и тех, кто скоро отвалится\n\n**Расписание**\n- смотреть журнал за период\n- ставить, переносить, менять занятия — на один день или сразу на неделю/месяц\n- записывать и снимать клиентов с занятий, отмечать оплату на месте\n\n**Команда**\n- заводить сотрудников, менять ставки, роли, услуги, рабочие часы\n- сравнивать тренеров по загрузке, выручке, возврату клиентов\n\n**Каталог**\n- услуги, залы, филиалы, пакеты абонементов\n\n**Деньги**\n- доходы/расходы, финансовая сводка, зарплаты, счета, сертификаты, промокоды\n\n**Аналитика**\n- статистика студии, отчёты по команде, сегменты лояльности\n\n**Интерфейс**\n- подскажу, где в CRM что находится и как это сделать руками\n\nПросто скажи, что нужно — сделаю сразу, без лишних вопросов.	2026-08-31 14:07:37.121971	\N	\N	\N	1d7597edbf0b452aa5540a6dd5fe3588
109	21	user	Co jsi umis?	2026-08-31 14:08:06.725959	\N	\N	\N	\N
110	21	assistant	Модель Velora AI 3.5 ещё не подключена, но история этого диалога уже сохранена и никуда не пропадёт.	2026-08-31 14:08:06.725959	\N	\N	\N	8c775673b4dd4fd4acbbe57b79e10ece
112	21	assistant	Já jsem Velora AI — druhý administrátor téhle studia. Umím toho dost, konkrétně:\n\n**Klienti**\n- vyhledám, založím, upravím kartu klienta\n- podívám se na permanentky, historii návštěv, poznámky\n- zmrazím, přidám body, dám slevu, prodám permanentku\n- najdu "usnuté" klienty nebo ty, co brzy odpadnou\n\n**Rozvrh**\n- ukážu rozvrh za období\n- naplánuju, přesunu, změním lekce — na den nebo hned na týden/měsíc\n- přihlásím/odhlásím klienta z lekce, zapíšu platbu na místě\n\n**Tým**\n- založím zaměstnance, změním sazby, role, služby, pracovní hodiny\n- porovnám trenéry podle vytížení, tržeb, návratnosti klientů\n\n**Katalog**\n- služby, sály, pobočky, balíčky permanentek\n\n**Finance**\n- příjmy/výdaje, finanční přehled, mzdy, účty, poukazy, promokódy\n\n**Analytika**\n- statistiky studia, reporty týmu, segmenty věrnostního programu\n\n**Rozhraní**\n- poradím, kde v CRM co najít a jak to udělat\n\nŘekni, co potřebuješ — udělám to hned, bez zbytečných otázek.	2026-08-31 14:08:43.064933	\N	\N	\N	38cfa9a8cfad47fe942d97db02f0650d
\.


--
-- Data for Name: ai_chat_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_chat_sessions (id, studio_id, user_id, title, preview, created_at, updated_at) FROM stdin;
1	1	1	Xxx	Модель Velora AI 3.5 ещё не подключена, но история этого диалога уже сохранена и никуда не пропадёт.	2026-08-05 02:48:26.609876	2026-08-05 02:48:26.76939
2	2	2	Как мне создать сотрудников?	Velora AI 3.5 isn't connected yet, but this conversation's history is safely saved.	2026-08-05 08:28:41.721959	2026-08-05 08:28:41.931305
14	1	1	короче мне в падлу это все заполнять мож	Я могу добавить сотрудников, но мне нужен пароль для каждого нового сотрудника, а также их email и роль. Пароль вы придумываете сами, а я его передам сотрудникам. Без этих данных создать сотрудников я не смогу.\n\nТакже мне понадобится id услуги "стерлинг", чтобы добавить её в расписание.\n\nЕсли хотите, я могу создать сотрудников с именами Аня, Саша, Оля и Вика с оплатой 300 крон в час, а вы потом добавите остальную информацию.	2026-08-18 14:46:41.680283	2026-08-18 14:46:41.750578
8	1	1	Создай занятие на 30 августа на 10:00 с 	Готово: Создать занятие: Хатха, 2026-09-10T10:00:00, тренер Sad Mat, мест 8	2026-08-16 17:34:22.558911	2026-08-16 17:35:03.275965
3	1	1	Где кнопка создать стафф?	Подтвердите действие: Завести сотрудника Кирилл — (trainer), email cartoonlvl2@gmail.com	2026-08-16 14:27:11.998851	2026-08-16 14:30:13.121962
9	2	2	как добавить тренера	Чтобы добавить тренера:\n\n1.  В боковом меню выберите раздел **Сотрудники**.\n2.  На странице справа над списком сотрудников нажмите кнопку **«+»**.\n3.  Заполните данные о сотруднике в открывшемся мастере из 4 шагов.\n\nПосле этого на email сотрудника будет отправлена ссылка-приглашение. Он появится в списке со статусом «Invitation pending» и получит доступ после того, как примет приглашение своим паролем.	2026-08-16 22:09:09.407525	2026-08-16 22:09:09.499975
4	1	1	Создай стафф кирил с почтой cartoonlvl2@	Готово: Завести сотрудника Кирилл — (trainer), email cartoonlvl2@gmail.com	2026-08-16 17:16:25.30741	2026-08-16 17:17:19.46492
5	1	1	Создай тренеру Кирил график на следующую	Для создания расписания тренеру Кириллу на следующую неделю услугой "Хатха" мне нужно знать его id. Подскажите, пожалуйста, id Кирилла.	2026-08-16 17:20:15.897693	2026-08-16 17:21:00.160052
6	1	1	Создай тренеру Кирил график на следующую	Подтвердите действие: Рабочие часы сотрудника Кирилл: ['{"day_of_week": 0, "start_time": "08:00", "end_time": "20:00"}', '{"day_of_week": 1, "start_time": "08:00", "end_time": "20:00"}', '{"day_of_week": 2, "start_time": "08:00", "end_time": "20:00"}', '{"day_of_week": 3, "start_time": "08:00", "end_time": "20:00"}', '{"day_of_week": 4, "start_time": "08:00", "end_time": "20:00"}', '{"day_of_week": 5, "is_open": false}', '{"day_of_week": 6, "is_open": false}']	2026-08-16 17:23:09.712329	2026-08-16 17:24:53.334201
10	2	2	короче мне в падлу это все заполнять мож	Хорошо, если вам удобно, можете называть меня Хозяин. Как я могу помочь вам сейчас, Хозяин?	2026-08-16 22:15:31.789011	2026-08-16 22:24:21.893209
15	1	1	короче мне в падлу это все заполнять мож	В Velora нет встроенного автоматического шаблона для чередования двух разных услуг через шаг при генерации сетки — расписание заполняется одной выбранной услугой на весь период.\n\nПоскольку занятий у Оли получилось больше 100 на три недели, поменять их на чередование можно несколькими способами:\n1. **В Журнале руками**: кликать на нужные слоты (каждый второй час) и менять услугу на «Стретчинг».\n2. **Точечно через ассистента**: назвать конкретные дни или недели, где заменить каждый второй час с Ха	2026-08-18 15:44:30.015828	2026-08-18 15:59:55.088518
7	1	1	Создай тренеру Кирил график на следующую	Готово: Заполнить расписание: Хатха, тренер Кирилл, 2026-08-19 — 2026-08-25, по 60 мин	2026-08-16 17:27:23.776285	2026-08-16 17:28:07.349586
16	1	1	Удали занятия кирила, когда и у Оли заня	Смотрю — тут не получается сопоставить по залу технически: у **всех** занятий Кирилла зал вообще не указан (hall_id пустой), а вот у Оли все занятия идут в **«Зал А»**. То есть по критерию «совпадает время И зал» у Кирилла нет ни одного такого занятия — сравнивать не с чем, зала там просто нет в карточке.\n\nПри этом по **времени** занятия действительно пересекаются сплошь: 19 августа у обоих слоты 9:00–17:00 один в один.\n\nУточните: удалить занятия Кирилла, которые просто совпадают по времени с за	2026-08-18 16:06:02.477997	2026-08-18 16:06:02.586915
11	1	1	Надо создать стаф валерия с почтой sadom	Готово: Завести сотрудника Валерия — (admin), email sadomat31@gmail.com	2026-08-16 23:38:04.02717	2026-08-16 23:38:22.74496
12	1	1	короче мне в падлу это все заполнять мож	Для добавления сотрудников мне нужны их email, пароли, и какая роль доступа будет у каждого (администратор или тренер). Пожалуйста, уточните эти данные.	2026-08-18 14:46:06.745277	2026-08-18 14:46:06.823499
17	1	1	Сделай так чтобы график работы Оли был и	Добавил Оле субботу и воскресенье с 10:00 до 22:00, будние дни (пн–пт с 09:00 до 17:00) сохранил. Подтвердите изменение графика в карточке ниже.	2026-08-18 17:31:14.722081	2026-08-18 17:31:14.81461
13	1	1	короче мне в падлу это все заполнять мож	Из	2026-08-18 14:46:28.648006	2026-08-18 14:46:28.721915
18	1	1	Создай на 29 на 10 тренировку у кирила с	Готово: Создать занятие: Стретчинг, 2026-08-29T10:00:00, тренер Кирилл, 60 мин.	2026-08-18 17:38:16.92678	2026-08-18 17:38:33.916975
19	1	1	СЛУШАЙ НАДО ВСЕМ ТРЕНЕРАМ ПОСТАВИТЬ ЗАРП	Подготовил изменения оклада до 50 000 UAH в месяц для обоих тренеров студии:\n\n* **Кирилл** (тренер) — оклад 50 000 UAH\n* **Оля** (тренер по стретчингу) — оклад 50 000 UAH	2026-08-20 20:47:37.642693	2026-08-20 20:47:37.79456
20	1	1	Роскажи о разделе финансов, что там есть	Раздел вы sейчас видите сами — сверху девять вкладок, разберём по порядку.\n\n**Что есть в разделе**\n\n| Вкладка | Что там |\n|---|---|\n| Счета и кассы | Общий капитал студии и три системных счёта: Наличные, Карта, Сеть. Тут же можно завести копилку под конкретную цель. |\n| Операции | Лента всех доходов/расходов. Кнопкой «Операция» заносите вручную то, что прошло не через кассу — аренду, закупки, зарплату наличкой и т.п. |\n| Зарплаты | Начисления по каждому сотруднику: ставка, число тренировок, сумм	2026-08-20 20:49:48.23883	2026-08-20 20:49:48.310117
21	2	2	dsd	Já jsem Velora AI — druhý administrátor téhle studia. Umím toho dost, konkrétně:\n\n**Klienti**\n- vyhledám, založím, upravím kartu klienta\n- podívám se na permanentky, historii návštěv, poznámky\n- zmrazím, přidám body, dám slevu, prodám permanentku\n- najdu "usnuté" klienty nebo ty, co brzy odpadnou\n\n**Rozvrh**\n- ukážu rozvrh za období\n- naplánuju, přesunu, změním lekce — na den nebo hned na týden/měsíc\n- přihlásím/odhlásím klienta z lekce, zapíšu platbu na místě\n\n**Tým**\n- založím zaměstnance, změ	2026-08-31 14:07:00.914157	2026-08-31 14:08:43.064933
\.


--
-- Data for Name: ai_studio_facts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_studio_facts (id, studio_id, text, author_user_id, created_at) FROM stdin;
\.


--
-- Data for Name: ai_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_usage (id, studio_id, user_id, created_at, surface, model, prompt_tokens, cached_tokens, completion_tokens, cost_micro, billable, sender_ref, tools, iterations, escalated, escalation_reason, escalation_from_model, request_id, response_language, language_source) FROM stdin;
1	1	1	2026-08-16 14:27:15.429493	crm	google/gemini-2.5-flash	9566	9559	63	446	t	\N	\N	1	f	\N	\N	\N	\N	\N
2	1	1	2026-08-16 14:29:30.987544	crm	google/gemini-2.5-flash	9658	9559	25	379	t	\N	\N	1	f	\N	\N	\N	\N	\N
3	1	1	2026-08-16 14:30:14.206142	crm	google/gemini-2.5-flash	9702	9559	30	405	t	\N	\N	1	f	\N	\N	\N	\N	\N
4	1	1	2026-08-16 17:16:27.921319	crm	google/gemini-2.5-flash	9708	9680	27	366	t	\N	\N	1	f	\N	\N	\N	\N	\N
5	1	1	2026-08-16 17:16:55.278033	crm	google/gemini-2.5-flash	9746	9680	25	373	t	\N	\N	1	f	\N	\N	\N	\N	\N
6	1	1	2026-08-16 17:17:17.205065	crm	google/gemini-2.5-flash	9782	9680	30	396	t	\N	\N	1	f	\N	\N	\N	\N	\N
7	1	1	2026-08-16 17:20:19.274604	crm	google/gemini-2.5-flash	9369	9343	7	306	t	\N	\N	1	f	\N	\N	\N	\N	\N
8	1	1	2026-08-16 17:20:20.077085	crm	google/gemini-2.5-flash	9494	9343	7	343	f	\N	get_staff	2	f	\N	\N	\N	\N	\N
9	1	1	2026-08-16 17:20:20.88905	crm	google/gemini-2.5-flash	9515	9343	31	409	f	\N	get_staff,get_services	3	f	\N	\N	\N	\N	\N
10	1	1	2026-08-16 17:21:03.221944	crm	google/gemini-2.5-flash	10012	9949	3	325	t	\N	\N	1	f	\N	\N	\N	\N	\N
11	1	1	2026-08-16 17:21:04.423718	crm	google/gemini-2.5-flash	10078	9949	38	432	f	\N	get_services	2	f	\N	\N	\N	\N	\N
12	1	1	2026-08-16 17:23:11.489292	crm	google/gemini-2.5-flash	9973	9949	3	313	t	\N	\N	1	f	\N	\N	\N	\N	\N
13	1	1	2026-08-16 17:23:12.375562	crm	google/gemini-2.5-flash	10094	9949	3	349	f	\N	get_staff	2	f	\N	\N	\N	\N	\N
14	1	1	2026-08-16 17:23:13.550629	crm	google/gemini-2.5-flash	10160	9949	37	454	f	\N	get_staff,get_services	3	f	\N	\N	\N	\N	\N
15	1	1	2026-08-16 17:24:42.510174	crm	google/gemini-2.5-flash	10040	9949	19	373	t	\N	\N	1	f	\N	\N	\N	\N	\N
16	1	1	2026-08-16 17:24:55.048726	crm	google/gemini-2.5-flash	10062	9949	216	872	t	\N	\N	1	f	\N	\N	\N	\N	\N
17	1	1	2026-08-16 17:27:26.991361	crm	google/gemini-2.5-flash	9704	9680	3	305	t	\N	\N	1	f	\N	\N	\N	\N	\N
18	1	1	2026-08-16 17:27:27.770898	crm	google/gemini-2.5-flash	9823	9680	3	341	f	\N	get_staff	2	f	\N	\N	\N	\N	\N
19	1	1	2026-08-16 17:27:28.857305	crm	google/gemini-2.5-flash	9889	9680	40	453	f	\N	get_staff,get_services	3	f	\N	\N	\N	\N	\N
20	1	1	2026-08-16 17:27:43.803145	crm	google/gemini-2.5-flash	9749	9680	3	319	t	\N	\N	1	f	\N	\N	\N	\N	\N
21	1	1	2026-08-16 17:27:44.442708	crm	google/gemini-2.5-flash	9868	9680	9	369	f	\N	get_staff	2	f	\N	\N	\N	\N	\N
22	1	1	2026-08-16 17:27:45.986583	crm	google/gemini-2.5-flash	10166	9680	90	661	f	\N	get_staff,get_staff_profile	3	f	\N	\N	\N	\N	\N
23	1	1	2026-08-16 17:27:57.018803	crm	google/gemini-2.5-flash	9844	9680	3	347	t	\N	\N	1	f	\N	\N	\N	\N	\N
24	1	1	2026-08-16 17:27:59.320083	crm	google/gemini-2.5-flash	9910	9680	135	697	f	\N	get_services	2	f	\N	\N	\N	\N	\N
25	1	1	2026-08-16 17:28:00.917619	crm	google/gemini-2.5-flash	10077	9680	155	797	f	\N	get_services,fill_schedule	3	f	\N	\N	\N	\N	\N
26	1	1	2026-08-16 17:34:25.83638	crm	google/gemini-2.5-flash	9549	9526	7	310	t	\N	\N	1	f	\N	\N	\N	\N	\N
27	1	1	2026-08-16 17:34:33.62807	crm	google/gemini-2.5-flash	9559	9526	3	303	t	\N	\N	1	f	\N	\N	\N	\N	\N
28	1	1	2026-08-16 17:34:34.705593	crm	google/gemini-2.5-flash	9678	9526	3	339	f	\N	get_staff	2	f	\N	\N	\N	\N	\N
29	1	1	2026-08-16 17:34:35.552891	crm	google/gemini-2.5-flash	9744	9526	37	444	f	\N	get_staff,get_services	3	f	\N	\N	\N	\N	\N
30	1	1	2026-08-16 17:34:49.560113	crm	google/gemini-2.5-flash	9607	9526	7	328	t	\N	\N	1	f	\N	\N	\N	\N	\N
31	1	1	2026-08-16 17:34:50.974158	crm	google/gemini-2.5-flash	9730	9526	7	364	f	\N	get_staff	2	f	\N	\N	\N	\N	\N
32	1	1	2026-08-16 17:34:51.941833	crm	google/gemini-2.5-flash	9800	9526	59	515	f	\N	get_staff,get_services	3	f	\N	\N	\N	\N	\N
33	1	1	2026-08-16 17:35:02.181199	crm	google/gemini-2.5-flash	9669	9526	43	436	t	\N	\N	1	f	\N	\N	\N	\N	\N
34	2	2	2026-08-16 22:09:12.907413	crm	google/gemini-2.5-flash	11422	11419	8	363	t	\N	\N	1	f	\N	\N	\N	\N	\N
35	2	2	2026-08-16 22:09:14.165151	crm	google/gemini-2.5-flash	12499	11419	108	937	f	\N	ui_section	2	f	\N	\N	\N	\N	\N
36	2	2	2026-08-16 22:15:34.906486	crm	google/gemini-2.5-flash	10431	10356	56	473	t	\N	\N	1	f	\N	\N	\N	\N	\N
37	2	2	2026-08-16 22:16:15.236499	crm	google/gemini-2.5-flash	10502	10356	106	619	t	\N	\N	1	f	\N	\N	\N	\N	\N
38	2	2	2026-08-16 22:17:21.923282	crm	google/gemini-2.5-flash	10527	10356	21	414	t	\N	\N	1	f	\N	\N	\N	\N	\N
39	2	2	2026-08-16 22:18:04.796179	crm	google/gemini-2.5-flash	10556	10356	32	451	t	\N	\N	1	f	\N	\N	\N	\N	\N
40	2	2	2026-08-16 22:18:45.898999	crm	google/gemini-2.5-flash	10602	10356	20	434	t	\N	\N	1	f	\N	\N	\N	\N	\N
41	2	2	2026-08-16 22:18:55.416049	crm	google/gemini-2.5-flash	10626	10356	6	407	t	\N	\N	1	f	\N	\N	\N	\N	\N
42	2	2	2026-08-16 22:18:56.931057	crm	google/gemini-2.5-flash	10693	10356	44	522	f	\N	get_staff	2	f	\N	\N	\N	\N	\N
43	2	2	2026-08-16 22:19:16.455787	crm	google/gemini-2.5-flash	10683	10356	25	471	t	\N	\N	1	f	\N	\N	\N	\N	\N
44	2	2	2026-08-16 22:19:23.357364	crm	google/gemini-2.5-flash	10713	10356	6	433	t	\N	\N	1	f	\N	\N	\N	\N	\N
45	2	2	2026-08-16 22:19:23.800293	crm	google/gemini-2.5-flash	10780	10356	3	445	f	\N	get_staff	2	f	\N	\N	\N	\N	\N
46	2	2	2026-08-16 22:19:24.712276	crm	google/gemini-2.5-flash	10846	10356	69	630	f	\N	get_staff,get_services	3	f	\N	\N	\N	\N	\N
47	2	2	2026-08-16 22:19:30.654573	crm	google/gemini-2.5-flash	10783	10356	6	454	t	\N	\N	1	f	\N	\N	\N	\N	\N
48	2	2	2026-08-16 22:19:31.227387	crm	google/gemini-2.5-flash	10850	10356	3	466	f	\N	get_staff	2	f	\N	\N	\N	\N	\N
49	2	2	2026-08-16 22:19:31.997081	crm	google/gemini-2.5-flash	10916	10356	53	611	f	\N	get_staff,get_services	3	f	\N	\N	\N	\N	\N
50	2	2	2026-08-16 22:20:59.06819	crm	google/gemini-2.5-flash	10905	10356	422	1530	t	\N	\N	1	f	\N	\N	\N	\N	\N
51	2	2	2026-08-16 22:21:45.960364	crm	google/gemini-2.5-flash	11203	10356	22	620	t	\N	\N	1	f	\N	\N	\N	\N	\N
52	2	2	2026-08-16 22:22:00.653151	crm	google/gemini-2.5-flash	11194	10356	22	617	t	\N	\N	1	f	\N	\N	\N	\N	\N
53	2	2	2026-08-16 22:24:23.279026	crm	google/gemini-2.5-flash	11198	10356	27	631	t	\N	\N	1	f	\N	\N	\N	\N	\N
54	1	1	2026-08-16 23:38:07.457881	crm	google/gemini-2.5-flash	10323	10287	15	357	t	\N	\N	1	f	\N	\N	\N	\N	\N
55	1	1	2026-08-16 23:38:19.702057	crm	google/gemini-2.5-flash	10343	10287	26	390	t	\N	\N	1	f	\N	\N	\N	\N	\N
56	1	\N	2026-08-18 14:42:55.023622	telegram	google/gemini-2.5-flash	447	0	24	194	t	620994031	\N	\N	\N	\N	\N	\N	\N	\N
57	1	\N	2026-08-18 14:42:56.573189	telegram	google/gemini-2.5-flash	447	0	23	192	t	620994031	\N	\N	\N	\N	\N	\N	\N	\N
58	1	\N	2026-08-18 14:43:21.348199	telegram	google/gemini-2.5-flash	461	0	45	251	t	620994031	\N	\N	\N	\N	\N	\N	\N	\N
59	1	\N	2026-08-18 14:43:32.9842	telegram	google/gemini-2.5-flash	531	0	27	227	f	620994031	\N	\N	\N	\N	\N	\N	\N	\N
60	1	1	2026-08-18 14:46:11.612969	crm	google/gemini-2.5-flash	13519	13444	34	511	t	\N	\N	1	f	\N	\N	\N	\N	\N
61	1	1	2026-08-18 14:46:31.189639	crm	google/gemini-2.5-flash	0	0	0	0	t	\N	\N	1	f	\N	\N	\N	\N	\N
62	1	1	2026-08-18 14:46:55.407116	crm	google/gemini-2.5-flash	13519	13444	111	703	t	\N	\N	1	f	\N	\N	\N	\N	\N
63	1	1	2026-08-18 15:44:39.193548	crm	google/gemini-3.7-flash	14737	14662	576	1658	t	\N	\N	1	f	\N	\N	\N	\N	\N
64	1	1	2026-08-18 15:44:42.984538	crm	google/gemini-3.7-flash	15453	14662	293	1396	f	\N	get_services,get_rooms	2	f	\N	\N	\N	\N	\N
65	1	1	2026-08-18 15:44:46.055989	crm	google/gemini-3.7-flash	15896	14662	180	1350	f	\N	get_services,get_rooms,create_service,create_staff,create_staff,create_staff,create_staff	3	f	\N	\N	\N	\N	\N
66	1	1	2026-08-18 15:44:49.462568	crm	google/gemini-3.7-flash	16208	14662	134	1381	f	\N	get_services,get_rooms,create_service,create_staff,create_staff,create_staff,create_staff,create_lesson,create_lesson,create_lesson	4	f	\N	\N	\N	\N	\N
67	1	1	2026-08-18 15:56:43.123192	crm	google/gemini-3.7-flash	14979	14662	160	969	t	\N	\N	1	f	\N	\N	\N	\N	\N
68	1	1	2026-08-18 15:56:46.635449	crm	google/gemini-3.7-flash	15830	14662	18	1022	f	\N	get_staff,get_services,get_rooms	2	f	\N	\N	\N	\N	\N
69	1	1	2026-08-18 15:56:48.691017	crm	google/gemini-3.7-flash	15962	14662	62	1154	f	\N	get_staff,get_services,get_rooms,get_staff_profile	3	f	\N	\N	\N	\N	\N
70	1	1	2026-08-18 15:57:20.85551	crm	anthropic/claude-sonnet-5	32546	0	2110	86192	f	\N	get_staff,get_services,get_rooms,get_staff_profile,fill_schedule	4	t	\N	\N	\N	\N	\N
71	1	1	2026-08-18 15:57:58.789681	crm	google/gemini-3.7-flash	15072	14662	145	975	t	\N	\N	1	f	\N	\N	\N	\N	\N
72	1	1	2026-08-18 15:58:01.980703	crm	google/gemini-3.7-flash	15923	14662	193	1385	f	\N	get_staff,get_services,get_rooms	2	f	\N	\N	\N	\N	\N
73	1	1	2026-08-18 15:58:04.54815	crm	google/gemini-3.7-flash	16180	14662	99	1305	f	\N	get_staff,get_services,get_rooms,set_staff_schedule,fill_schedule	3	f	\N	\N	\N	\N	\N
74	1	1	2026-08-18 16:00:01.628036	crm	google/gemini-3.7-flash	15711	15127	222	1203	t	\N	\N	1	f	\N	\N	\N	\N	\N
75	1	1	2026-08-18 16:00:04.267969	crm	google/gemini-3.7-flash	16945	15127	189	1603	f	\N	get_staff,get_services,get_schedule	2	f	\N	\N	\N	\N	\N
76	1	1	2026-08-18 16:00:07.218317	crm	google/gemini-3.7-flash	20097	15127	138	2690	f	\N	get_staff,get_services,get_schedule,get_schedule,get_schedule,get_schedule	3	f	\N	\N	\N	\N	\N
77	1	\N	2026-08-18 16:01:28.284023	telegram	google/gemini-3.7-flash	550	0	85	366	t	620994031	\N	\N	\N	\N	\N	\N	\N	\N
78	1	\N	2026-08-18 16:01:46.382279	telegram	google/gemini-3.7-flash	564	0	145	483	t	620994031	\N	\N	\N	\N	\N	\N	\N	\N
79	1	\N	2026-08-18 16:01:48.491349	telegram	google/gemini-3.7-flash	679	0	97	436	f	620994031	\N	\N	\N	\N	\N	\N	\N	\N
80	1	\N	2026-08-18 16:02:35.319254	telegram	google/gemini-3.7-flash	566	0	57	319	t	620994031	\N	\N	\N	\N	\N	\N	\N	\N
81	1	\N	2026-08-18 16:02:37.827862	telegram	google/gemini-3.7-flash	681	0	106	454	f	620994031	\N	\N	\N	\N	\N	\N	\N	\N
82	1	1	2026-08-18 16:06:11.736226	crm	google/gemini-3.7-flash	15237	15219	613	1727	t	\N	\N	1	f	\N	\N	\N	\N	\N
83	1	1	2026-08-18 16:06:14.347384	crm	google/gemini-3.7-flash	16362	15219	27	1050	f	\N	get_staff,get_staff,get_schedule	2	f	\N	\N	\N	\N	\N
84	1	1	2026-08-18 16:06:17.014583	crm	google/gemini-3.7-flash	17085	15219	100	1458	f	\N	get_staff,get_staff,get_schedule,get_staff,get_rooms	3	f	\N	\N	\N	\N	\N
85	1	1	2026-08-18 16:06:19.597445	crm	google/gemini-3.7-flash	19132	15219	50	2132	f	\N	get_staff,get_staff,get_schedule,get_staff,get_rooms,get_schedule,get_schedule	4	f	\N	\N	\N	\N	\N
86	1	1	2026-08-18 16:06:41.880272	crm	anthropic/claude-sonnet-5	40446	0	1421	95102	f	\N	get_staff,get_staff,get_schedule,get_staff,get_rooms,get_schedule,get_schedule,get_schedule	5	t	\N	\N	\N	\N	\N
87	1	1	2026-08-18 17:31:22.635692	crm	google/gemini-3.7-flash	14679	14654	152	844	t	\N	\N	1	f	\N	\N	\N	\N	\N
88	1	1	2026-08-18 17:31:25.14112	crm	google/gemini-3.7-flash	14765	14654	18	625	f	\N	get_staff	2	f	\N	\N	\N	\N	\N
89	1	1	2026-08-18 17:31:29.080532	crm	google/gemini-3.7-flash	15041	14654	287	1233	f	\N	get_staff,get_staff_profile	3	f	\N	\N	\N	\N	\N
90	1	1	2026-08-18 17:31:32.138235	crm	google/gemini-3.7-flash	15298	14654	62	907	f	\N	get_staff,get_staff_profile,set_staff_schedule	4	f	\N	\N	\N	\N	\N
91	1	1	2026-08-18 17:38:23.086801	crm	google/gemini-3.7-flash	15145	15127	203	955	t	\N	\N	1	f	\N	\N	\N	\N	\N
92	1	1	2026-08-18 17:38:26.425613	crm	google/gemini-3.7-flash	15991	15127	174	1218	f	\N	get_staff,get_services,get_rooms	2	f	\N	\N	\N	\N	\N
93	1	1	2026-08-18 17:38:28.888432	crm	google/gemini-3.7-flash	16089	15127	75	1069	f	\N	get_staff,get_services,get_rooms,create_lesson	3	f	\N	\N	\N	\N	\N
94	1	\N	2026-08-18 23:29:15.901456	telegram	google/gemini-3.5-flash-lite	598	0	70	354	t	620994031	\N	\N	\N	\N	\N	\N	\N	\N
95	1	\N	2026-08-18 23:29:42.710678	telegram	google/gemini-3.5-flash-lite	594	0	27	246	t	620994031	\N	\N	\N	\N	\N	\N	\N	\N
96	1	\N	2026-08-18 23:29:43.286995	telegram	google/gemini-3.5-flash-lite	643	0	62	348	f	620994031	\N	\N	\N	\N	\N	\N	\N	\N
97	1	\N	2026-08-18 23:29:59.611237	telegram	google/gemini-3.5-flash-lite	590	0	27	244	t	620994031	\N	\N	\N	\N	\N	\N	\N	\N
98	1	\N	2026-08-18 23:30:00.294846	telegram	google/gemini-3.5-flash-lite	639	0	54	327	f	620994031	\N	\N	\N	\N	\N	\N	\N	\N
99	1	\N	2026-08-18 23:30:11.276611	telegram	google/gemini-3.5-flash-lite	588	0	37	269	t	620994031	\N	\N	\N	\N	\N	\N	\N	\N
100	1	\N	2026-08-18 23:43:30.162307	telegram	google/gemini-3.5-flash-lite	1179	0	46	469	t	620994031	\N	\N	\N	\N	\N	\N	\N	\N
101	1	\N	2026-08-18 23:44:12.793425	telegram	google/gemini-3.5-flash-lite	1184	0	95	593	t	620994031	\N	\N	\N	\N	\N	\N	\N	\N
102	1	\N	2026-08-19 23:09:53.442343	telegram	google/gemini-3.5-flash-lite	1176	0	39	450	t	5968761069	\N	\N	\N	\N	\N	\N	\N	\N
103	1	\N	2026-08-19 23:10:28.292524	telegram	google/gemini-3.5-flash-lite	1186	0	27	423	t	5968761069	\N	\N	\N	\N	\N	\N	\N	\N
104	1	\N	2026-08-19 23:10:28.911545	telegram	google/gemini-3.5-flash-lite	2242	0	79	870	f	5968761069	\N	\N	\N	\N	\N	\N	\N	\N
105	1	\N	2026-08-19 23:10:51.752097	telegram	google/gemini-3.5-flash-lite	1183	0	48	475	t	5968761069	\N	\N	\N	\N	\N	\N	\N	\N
106	1	1	2026-08-20 20:47:44.337611	crm	google/gemini-3.7-flash	15422	15385	133	840	t	\N	\N	1	f	\N	\N	\N	\N	\N
107	1	1	2026-08-20 20:47:46.693568	crm	google/gemini-3.7-flash	15659	15385	48	770	f	\N	get_staff	2	f	\N	\N	\N	\N	\N
108	1	1	2026-08-20 20:47:49.367199	crm	google/gemini-3.7-flash	15807	15385	76	878	f	\N	get_staff,update_staff,update_staff	3	f	\N	\N	\N	\N	\N
109	1	1	2026-08-20 20:50:02.337238	crm	google/gemini-3.7-flash	15478	15447	1116	2683	t	\N	\N	1	f	\N	\N	\N	\N	\N
110	1	1	2026-08-20 20:50:23.469211	crm	anthropic/claude-sonnet-5	31707	0	1291	76324	f	\N	\N	2	t	\N	\N	\N	\N	\N
111	2	2	2026-08-31 14:07:08.694082	crm	google/gemini-3.7-flash	16362	16361	68	741	t	\N	\N	1	f	\N	\N	f9c678907fa045f2b3898e58fadb6538	en	latest_user_message
112	2	2	2026-08-31 14:07:13.440121	crm	anthropic/claude-sonnet-5	33515	0	90	67930	f	\N	\N	2	t	gave_up_no_tools	google/gemini-3.7-flash	f9c678907fa045f2b3898e58fadb6538	en	latest_user_message
113	2	2	2026-08-31 14:07:45.860633	crm	google/gemini-3.7-flash	16419	16361	423	1428	t	\N	\N	1	f	\N	\N	1d7597edbf0b452aa5540a6dd5fe3588	ru	latest_user_message
114	2	2	2026-08-31 14:07:54.163078	crm	anthropic/claude-sonnet-5	33618	31714	436	14511	f	\N	\N	2	t	gave_up_no_tools	google/gemini-3.7-flash	1d7597edbf0b452aa5540a6dd5fe3588	ru	latest_user_message
115	2	2	2026-08-31 14:08:18.880413	crm	google/gemini-3.7-flash	0	0	0	0	t	\N	\N	1	f	\N	\N	8c775673b4dd4fd4acbbe57b79e10ece	ru	previous_user_message
116	2	2	2026-08-31 14:08:58.714543	crm	google/gemini-3.7-flash	16754	16361	657	1993	t	\N	\N	1	f	\N	\N	38cfa9a8cfad47fe942d97db02f0650d	cs	latest_user_message
117	2	2	2026-08-31 14:09:09.29372	crm	anthropic/claude-sonnet-5	34125	31714	466	15825	f	\N	\N	2	t	gave_up_no_tools	google/gemini-3.7-flash	38cfa9a8cfad47fe942d97db02f0650d	cs	latest_user_message
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
a1c4e70b9d26
\.


--
-- Data for Name: billing_invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.billing_invoices (id, studio_id, user_id, plan_name, amount, payment_method, paid_at, status, pdf_url, order_id, period_months, stripe_invoice_id, hosted_invoice_url, kind, due_at, reminder_sent_at, period) FROM stdin;
1	1	\N	start	0	iban	2026-08-11 22:19:36.54768	pending	https://pay.stripe.com/invoice/acct_1TyL8R1PBkRXkxBR/live_YWNjdF8xVHlMOFIxUEJrUlhreEJSLF9WM1YxaElUVFpJUlozWnBWUWxVUzhsSDRXblRNcXViLDE3NzAyNzU3Ng0200Qx662Mqb/pdf?s=ap	\N	1	in_1U3O1B1PBkRXkxBRtUyidys6	https://invoice.stripe.com/i/acct_1TyL8R1PBkRXkxBR/live_YWNjdF8xVHlMOFIxUEJrUlhreEJSLF9WM1YxaElUVFpJUlozWnBWUWxVUzhsSDRXblRNcXViLDE3NzAyNzU3Ng0200Qx662Mqb?s=ap	subscription	\N	\N	\N
\.


--
-- Data for Name: booking_channel_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.booking_channel_configs (id, studio_id, channel_type, is_active, connected_at, config) FROM stdin;
1	1	telegram	t	2026-08-18 13:28:49.425642	{"token": "7957635360:AAEe8sp-YfNzRIM6cfN5CiPCzHCr8TtEpew", "bot_username": "ClientToBarberBot"}
\.


--
-- Data for Name: branch_working_hours; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branch_working_hours (id, branch_id, day_of_week, is_open, open_time, close_time) FROM stdin;
8	1	0	t	09:00	21:00
9	1	1	t	09:00	21:00
10	1	2	t	09:00	21:00
11	1	3	t	09:00	21:00
12	1	4	t	09:00	21:00
13	1	5	t	10:00	20:00
14	1	6	t	10:00	20:00
15	2	0	t	09:00	21:00
16	2	1	t	09:00	21:00
17	2	2	t	09:00	21:00
18	2	3	t	09:00	21:00
19	2	4	t	09:00	21:00
20	2	5	t	10:00	18:00
21	2	6	f	10:00	18:00
\.


--
-- Data for Name: channel_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_threads (id, studio_id, channel, sender_ref, lease_owner, lease_until, lease_seq, created_at, search_version, search_state, search_state_at) FROM stdin;
\.


--
-- Data for Name: client_email_otp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_email_otp (id, studio_id, email, code_hash, expires_at, attempts) FROM stdin;
\.


--
-- Data for Name: client_loyalty_cards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_loyalty_cards (id, studio_id, client_id, level_id, points_balance, total_spent, created_at, deposit_balance) FROM stdin;
1	1	1	4	0	8000	2026-08-16 20:41:53.560563	0
2	1	2	4	72	7200	2026-08-16 22:34:55.529049	0
\.


--
-- Data for Name: client_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_notes (id, client_id, studio_id, author_id, text, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: client_offers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_offers (id, studio_id, client_id, discount_type, value, reason, scope, valid_until, is_used, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: client_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_payments (id, client_id, amount, description, status, created_at, action_type, item_key) FROM stdin;
1	1	8000	Абонемент «8 занятий»	success	2026-08-16 20:41:53.560563	subscription	1
2	2	7200	Абонемент «8 занятий»	success	2026-08-16 22:34:55.529049	subscription	1
\.


--
-- Data for Name: client_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_subscriptions (id, client_id, type, total_classes, used_classes, expires_at, status, is_frozen, frozen_at, freeze_until, package_id, created_at, starts_at, duration_days) FROM stdin;
2	2	8 занятий	8	0	2026-09-15	active	f	\N	\N	1	2026-08-16 22:34:55.529049	2026-08-16	30
1	1	8 занятий	8	2	2026-09-15	active	f	\N	\N	1	2026-08-16 20:41:53.560563	2026-08-16	30
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (id, studio_id, tg_id, name, phone, registration_date, notifs_enabled, reminders_enabled, last_name, email, birth_date, city, avatar_color, status, tags, last_visit_date, is_active, source, invite_code, ig_id, phone_verified) FROM stdin;
1	1	\N	Матвей	\N	2026-08-16 20:34:35.61973	t	f	\N	smat5302@gmail.com	\N	\N	#C8A8D8	new	\N	\N	t	online	MN7T9S8B	\N	f
2	1	\N	Valeria	\N	2026-08-16 22:28:38.850266	t	f	\N	leramesnjankina@gmail.com	\N	\N	#C8A8D8	new	\N	\N	t	online	7VH6C8J2	\N	f
\.


--
-- Data for Name: counterparties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.counterparties (id, studio_id, name, counterparty_type, inn, category, balance, deals_count, color) FROM stdin;
\.


--
-- Data for Name: daily_metric_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_metric_snapshots (id, studio_id, date, revenue, new_clients, total_bookings, cancelled_bookings, retention_rate) FROM stdin;
\.


--
-- Data for Name: deposit_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deposit_transactions (id, studio_id, client_id, amount, description, created_at) FROM stdin;
\.


--
-- Data for Name: event_attendees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_attendees (id, studio_id, event_id, client_id, guest_name, paid_amount, attended) FROM stdin;
\.


--
-- Data for Name: fin_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fin_documents (id, studio_id, counterparty_id, title, doc_type, upload_date, amount, status, file_ext, file_url, requires_signature) FROM stdin;
\.


--
-- Data for Name: financial_goals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_goals (id, studio_id, title, target_amount, current_amount, deadline, category, color, priority, tracking_mode, created_at, op_type) FROM stdin;
\.


--
-- Data for Name: fx_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fx_rates (id, base, code, rate, fetched_at) FROM stdin;
31	eur	clp	0.0009274399415746226	2026-08-31 02:42:59.969052
32	eur	cnh	0.1281766006950248	2026-08-31 02:42:59.969052
33	eur	cny	0.12779389400774432	2026-08-31 02:42:59.969052
34	eur	cop	0.00027122383448271276	2026-08-31 02:42:59.969052
35	eur	crc	0.001898150393853394	2026-08-31 02:42:59.969052
36	eur	cup	0.035929632533276225	2026-08-31 02:42:59.969052
37	eur	cve	0.009069060898743935	2026-08-31 02:42:59.969052
38	eur	czk	0.0414112970018221	2026-08-31 02:42:59.969052
39	eur	djf	0.004852050099610405	2026-08-31 02:42:59.969052
40	eur	dkk	0.13378284368812543	2026-08-31 02:42:59.969052
41	eur	dop	0.014635761344182275	2026-08-31 02:42:59.969052
42	eur	dzd	0.0064588949113706245	2026-08-31 02:42:59.969052
43	eur	egp	0.017101727488247908	2026-08-31 02:42:59.969052
44	eur	ern	0.05748741370564328	2026-08-31 02:42:59.969052
45	eur	etb	0.0052918706098476044	2026-08-31 02:42:59.969052
46	eur	fjd	0.3935106938498607	2026-08-31 02:42:59.969052
47	eur	fkp	1.168119222920368	2026-08-31 02:42:59.969052
48	eur	fok	0.13378672763417035	2026-08-31 02:42:59.969052
49	eur	gbp	1.1665888940737286	2026-08-31 02:42:59.969052
50	eur	gel	0.3307245778631488	2026-08-31 02:42:59.969052
51	eur	ggp	1.168119222920368	2026-08-31 02:42:59.969052
52	eur	ghs	0.07699244119009371	2026-08-31 02:42:59.969052
53	eur	gip	1.168119222920368	2026-08-31 02:42:59.969052
54	eur	gmd	0.011497436077503434	2026-08-31 02:42:59.969052
55	eur	gnf	9.82682687024517e-05	2026-08-31 02:42:59.969052
56	eur	gtq	0.11278364240186751	2026-08-31 02:42:59.969052
57	eur	gyd	0.004126064183643327	2026-08-31 02:42:59.969052
58	eur	hkd	0.10955782461983436	2026-08-31 02:42:59.969052
59	eur	hnl	0.032068770837686	2026-08-31 02:42:59.969052
60	eur	hrk	0.13272280841462605	2026-08-31 02:42:59.969052
61	eur	htg	0.006602264830363784	2026-08-31 02:42:59.969052
62	eur	huf	0.002741303215548672	2026-08-31 02:42:59.969052
63	eur	idr	4.8477609161880305e-05	2026-08-31 02:42:59.969052
64	eur	ils	0.28891713856465967	2026-08-31 02:42:59.969052
65	eur	imp	1.168119222920368	2026-08-31 02:42:59.969052
66	eur	inr	0.00900426351877614	2026-08-31 02:42:59.969052
67	eur	iqd	0.0006576968804184049	2026-08-31 02:42:59.969052
68	eur	irr	6.247189755199708e-07	2026-08-31 02:42:59.969052
69	eur	isk	0.007102272727272727	2026-08-31 02:42:59.969052
70	eur	jep	1.168119222920368	2026-08-31 02:42:59.969052
71	eur	jmd	0.005430618416396806	2026-08-31 02:42:59.969052
72	eur	jod	1.2162357746023214	2026-08-31 02:42:59.969052
73	eur	jpy	0.005378657487091223	2026-08-31 02:42:59.969052
74	eur	kes	0.006648388252843125	2026-08-31 02:42:59.969052
75	eur	kgs	0.009856729577144625	2026-08-31 02:42:59.969052
76	eur	khr	0.00021361095260852078	2026-08-31 02:42:59.969052
77	eur	kid	0.6178205391966974	2026-08-31 02:42:59.969052
78	eur	kmf	0.0020326535631654714	2026-08-31 02:42:59.969052
79	eur	krw	0.0006248476933747399	2026-08-31 02:42:59.969052
80	eur	kwd	2.7934989691988803	2026-08-31 02:42:59.969052
81	eur	kyd	1.0347735656744912	2026-08-31 02:42:59.969052
82	eur	kzt	0.0018594418697424338	2026-08-31 02:42:59.969052
83	eur	lak	3.869529699026986e-05	2026-08-31 02:42:59.969052
84	eur	lbp	9.634761967592137e-06	2026-08-31 02:42:59.969052
85	eur	lkr	0.002628473336950463	2026-08-31 02:42:59.969052
86	eur	lrd	0.0047584508969694215	2026-08-31 02:42:59.969052
87	eur	lsl	0.05347434017744283	2026-08-31 02:42:59.969052
88	eur	lyd	0.13621914500146573	2026-08-31 02:42:59.969052
89	eur	mad	0.0928968038204368	2026-08-31 02:42:59.969052
90	eur	mdl	0.05025036238048831	2026-08-31 02:42:59.969052
1	eur	eur	1	2026-08-31 02:42:59.969052
2	eur	aed	0.2348022483724095	2026-08-31 02:42:59.969052
3	eur	afn	0.013151157191363118	2026-08-31 02:42:59.969052
4	eur	all	0.010835690258499911	2026-08-31 02:42:59.969052
5	eur	amd	0.0023667705397287914	2026-08-31 02:42:59.969052
6	eur	ang	0.48173803374767626	2026-08-31 02:42:59.969052
7	eur	aoa	0.0009282424968917451	2026-08-31 02:42:59.969052
8	eur	ars	0.0005699214373101317	2026-08-31 02:42:59.969052
9	eur	aud	0.6179323981956374	2026-08-31 02:42:59.969052
10	eur	awg	0.48173803374767626	2026-08-31 02:42:59.969052
11	eur	azn	0.5062222305467656	2026-08-31 02:42:59.969052
12	eur	bam	0.5112918811962185	2026-08-31 02:42:59.969052
13	eur	bbd	0.4311556523643713	2026-08-31 02:42:59.969052
14	eur	bdt	0.006993015159675047	2026-08-31 02:42:59.969052
15	eur	bgn	0.5112918811962185	2026-08-31 02:42:59.969052
16	eur	bhd	2.293383359669019	2026-08-31 02:42:59.969052
17	eur	bif	0.00028895855442690106	2026-08-31 02:42:59.969052
18	eur	bmd	0.8623113047287426	2026-08-31 02:42:59.969052
19	eur	bnd	0.6769220355045608	2026-08-31 02:42:59.969052
20	eur	bob	0.0736843385043774	2026-08-31 02:42:59.969052
21	eur	brl	0.16631740012640123	2026-08-31 02:42:59.969052
22	eur	bsd	0.8623113047287426	2026-08-31 02:42:59.969052
23	eur	btn	0.00903201819742124	2026-08-31 02:42:59.969052
24	eur	bwp	0.06365551468730056	2026-08-31 02:42:59.969052
25	eur	byn	0.28502801967947455	2026-08-31 02:42:59.969052
26	eur	bzd	0.4311556523643713	2026-08-31 02:42:59.969052
27	eur	cad	0.6199628022318661	2026-08-31 02:42:59.969052
28	eur	cdf	0.00037662983746856483	2026-08-31 02:42:59.969052
29	eur	chf	1.0679196924391285	2026-08-31 02:42:59.969052
30	eur	clf	36.65823527255398	2026-08-31 02:42:59.969052
91	eur	mga	0.00019982925469435087	2026-08-31 02:42:59.969052
92	eur	mkd	0.016260955818983038	2026-08-31 02:42:59.969052
93	eur	mmk	0.0004095957755405811	2026-08-31 02:42:59.969052
94	eur	mnt	0.00023801359444539184	2026-08-31 02:42:59.969052
95	eur	mop	0.10674474119363891	2026-08-31 02:42:59.969052
96	eur	mru	0.021496007320852224	2026-08-31 02:42:59.969052
97	eur	mur	0.01837333750922548	2026-08-31 02:42:59.969052
98	eur	mvr	0.055671541025555514	2026-08-31 02:42:59.969052
99	eur	mwk	0.0004963959078314695	2026-08-31 02:42:59.969052
100	eur	mxn	0.0506773021431431	2026-08-31 02:42:59.969052
101	eur	myr	0.21333333333333335	2026-08-31 02:42:59.969052
102	eur	mzn	0.013553096797911468	2026-08-31 02:42:59.969052
103	eur	nad	0.05347434017744283	2026-08-31 02:42:59.969052
104	eur	ngn	0.0006414225203877944	2026-08-31 02:42:59.969052
105	eur	nio	0.023402506305454287	2026-08-31 02:42:59.969052
106	eur	nok	0.09208527096090979	2026-08-31 02:42:59.969052
107	eur	npr	0.005645011360641813	2026-08-31 02:42:59.969052
108	eur	nzd	0.5105948429920858	2026-08-31 02:42:59.969052
109	eur	omr	2.242700570318755	2026-08-31 02:42:59.969052
110	eur	pab	0.8623113047287426	2026-08-31 02:42:59.969052
111	eur	pen	0.2568446531621173	2026-08-31 02:42:59.969052
112	eur	pgk	0.19423642263126253	2026-08-31 02:42:59.969052
113	eur	php	0.013796528793355592	2026-08-31 02:42:59.969052
114	eur	pkr	0.0031030685683416923	2026-08-31 02:42:59.969052
115	eur	pln	0.23060071486221606	2026-08-31 02:42:59.969052
116	eur	pyg	0.00014534224211493841	2026-08-31 02:42:59.969052
117	eur	qar	0.23689867417288013	2026-08-31 02:42:59.969052
118	eur	ron	0.19017191541153203	2026-08-31 02:42:59.969052
119	eur	rsd	0.008523566698759031	2026-08-31 02:42:59.969052
120	eur	rub	0.010018454995948035	2026-08-31 02:42:59.969052
121	eur	rwf	0.0005858727024791058	2026-08-31 02:42:59.969052
122	eur	sar	0.22994965482257312	2026-08-31 02:42:59.969052
123	eur	sbd	0.10923603810502563	2026-08-31 02:42:59.969052
124	eur	scr	0.05969925426079548	2026-08-31 02:42:59.969052
125	eur	sdg	0.0019309305859090068	2026-08-31 02:42:59.969052
126	eur	sek	0.09018352347026198	2026-08-31 02:42:59.969052
127	eur	sgd	0.6755843804891231	2026-08-31 02:42:59.969052
128	eur	shp	1.168119222920368	2026-08-31 02:42:59.969052
129	eur	sle	0.035026483173662776	2026-08-31 02:42:59.969052
130	eur	sll	3.50374544001962e-05	2026-08-31 02:42:59.969052
131	eur	sos	0.0015093300201164713	2026-08-31 02:42:59.969052
132	eur	srd	0.022839508146624162	2026-08-31 02:42:59.969052
133	eur	ssp	0.00014672725695574662	2026-08-31 02:42:59.969052
134	eur	stn	0.04081632653061224	2026-08-31 02:42:59.969052
135	eur	syp	0.007071712732545937	2026-08-31 02:42:59.969052
136	eur	szl	0.05347434017744283	2026-08-31 02:42:59.969052
137	eur	thb	0.026062027625749284	2026-08-31 02:42:59.969052
138	eur	tjs	0.09292220831486504	2026-08-31 02:42:59.969052
139	eur	tmt	0.24543930813604306	2026-08-31 02:42:59.969052
140	eur	tnd	0.2966881004040002	2026-08-31 02:42:59.969052
141	eur	top	0.3646264238206067	2026-08-31 02:42:59.969052
142	eur	try	0.017802527246767952	2026-08-31 02:42:59.969052
143	eur	ttd	0.12634227613443677	2026-08-31 02:42:59.969052
144	eur	tvd	0.6178205391966974	2026-08-31 02:42:59.969052
145	eur	twd	0.027249716868629308	2026-08-31 02:42:59.969052
146	eur	tzs	0.00032606670551103676	2026-08-31 02:42:59.969052
147	eur	uah	0.019311004970961658	2026-08-31 02:42:59.969052
148	eur	ugx	0.00023055217928219775	2026-08-31 02:42:59.969052
149	eur	usd	0.8588851670531651	2026-08-31 02:42:59.969052
150	eur	uyu	0.021406873879925462	2026-08-31 02:42:59.969052
151	eur	uzs	7.300238289742602e-05	2026-08-31 02:42:59.969052
152	eur	ves	0.0010837861914968245	2026-08-31 02:42:59.969052
153	eur	vnd	3.327598996230694e-05	2026-08-31 02:42:59.969052
154	eur	vuv	0.007342460839407304	2026-08-31 02:42:59.969052
155	eur	wst	0.322478804274392	2026-08-31 02:42:59.969052
156	eur	xaf	0.0015244901723741038	2026-08-31 02:42:59.969052
157	eur	xcd	0.31937453690692147	2026-08-31 02:42:59.969052
158	eur	xcg	0.48173803374767626	2026-08-31 02:42:59.969052
159	eur	xdr	1.177174122887561	2026-08-31 02:42:59.969052
160	eur	xof	0.0015244901723741038	2026-08-31 02:42:59.969052
161	eur	xpf	0.008379981899239098	2026-08-31 02:42:59.969052
162	eur	yer	0.003636277476421686	2026-08-31 02:42:59.969052
163	eur	zar	0.053674272311053144	2026-08-31 02:42:59.969052
164	eur	zmw	0.04531160382143567	2026-08-31 02:42:59.969052
165	eur	zwg	0.03241091859025468	2026-08-31 02:42:59.969052
166	eur	zwl	0.03241091859025468	2026-08-31 02:42:59.969052
\.


--
-- Data for Name: gift_certificates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gift_certificates (id, studio_id, client_id, recipient_name, code, amount, cert_type, status, issued_at, expires_at, used_at) FROM stdin;
\.


--
-- Data for Name: halls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.halls (id, studio_id, name, color, capacity, is_online, is_active, branch_id, area, equipment, hourly_rate, photo_url) FROM stdin;
1	1	Зал А	#B3A5D9	20	f	t	1	45	null	4500	/static/halls/776102fef8b845169d4fa3255368f5c0.jpg
\.


--
-- Data for Name: inbound_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inbound_events (id, provider, provider_event_id, studio_id, event_type, sender_ref, text, payload_sha256, received_at) FROM stdin;
\.


--
-- Data for Name: lessons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lessons (id, studio_id, name, teacher_name, start_time, duration_min, price, level, equipment, total_spots, teacher_id, hall_id, service_id, status, cancel_reason, clients_notified, gcal_event_id, tz_iana) FROM stdin;
1	1	Хатха	Кирилл	2026-08-19 09:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
2	1	Хатха	Кирилл	2026-08-19 10:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
3	1	Хатха	Кирилл	2026-08-19 11:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
4	1	Хатха	Кирилл	2026-08-19 12:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
5	1	Хатха	Кирилл	2026-08-19 13:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
6	1	Хатха	Кирилл	2026-08-19 14:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
7	1	Хатха	Кирилл	2026-08-19 15:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
8	1	Хатха	Кирилл	2026-08-19 16:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
9	1	Хатха	Кирилл	2026-08-19 17:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
10	1	Хатха	Кирилл	2026-08-20 09:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
11	1	Хатха	Кирилл	2026-08-20 10:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
12	1	Хатха	Кирилл	2026-08-20 11:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
13	1	Хатха	Кирилл	2026-08-20 12:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
14	1	Хатха	Кирилл	2026-08-20 13:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
15	1	Хатха	Кирилл	2026-08-20 14:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
16	1	Хатха	Кирилл	2026-08-20 15:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
17	1	Хатха	Кирилл	2026-08-20 16:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
18	1	Хатха	Кирилл	2026-08-20 17:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
19	1	Хатха	Кирилл	2026-08-21 09:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
20	1	Хатха	Кирилл	2026-08-21 10:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
21	1	Хатха	Кирилл	2026-08-21 11:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
22	1	Хатха	Кирилл	2026-08-21 12:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
23	1	Хатха	Кирилл	2026-08-21 13:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
24	1	Хатха	Кирилл	2026-08-21 14:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
25	1	Хатха	Кирилл	2026-08-21 15:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
26	1	Хатха	Кирилл	2026-08-21 16:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
27	1	Хатха	Кирилл	2026-08-21 17:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
28	1	Хатха	Кирилл	2026-08-22 10:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
29	1	Хатха	Кирилл	2026-08-22 11:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
30	1	Хатха	Кирилл	2026-08-22 12:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
31	1	Хатха	Кирилл	2026-08-22 13:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
32	1	Хатха	Кирилл	2026-08-22 14:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
33	1	Хатха	Кирилл	2026-08-22 15:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
34	1	Хатха	Кирилл	2026-08-24 09:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
35	1	Хатха	Кирилл	2026-08-24 10:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
36	1	Хатха	Кирилл	2026-08-24 11:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
37	1	Хатха	Кирилл	2026-08-24 12:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
38	1	Хатха	Кирилл	2026-08-24 13:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
39	1	Хатха	Кирилл	2026-08-24 14:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
40	1	Хатха	Кирилл	2026-08-24 15:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
41	1	Хатха	Кирилл	2026-08-24 16:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
42	1	Хатха	Кирилл	2026-08-24 17:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
43	1	Хатха	Кирилл	2026-08-25 09:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
44	1	Хатха	Кирилл	2026-08-25 10:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
45	1	Хатха	Кирилл	2026-08-25 11:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
46	1	Хатха	Кирилл	2026-08-25 12:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
47	1	Хатха	Кирилл	2026-08-25 13:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
49	1	Хатха	Кирилл	2026-08-25 15:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
50	1	Хатха	Кирилл	2026-08-25 16:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
51	1	Хатха	Кирилл	2026-08-25 17:00:00	60	0			8	4	\N	2	confirmed	\N	f	\N	\N
60	2	Booty+Abs	Тренер Петя	2026-08-18 15:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
61	2	Booty+Abs	Тренер Петя	2026-08-18 16:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
53	2	Booty+Abs	Тренер Петя	2026-08-17 11:00:00	60	0			5	5	\N	1	confirmed	\N	f	\N	\N
54	2	Booty+Abs	Тренер Петя	2026-08-18 09:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
55	2	Booty+Abs	Тренер Петя	2026-08-18 10:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
56	2	Booty+Abs	Тренер Петя	2026-08-18 11:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
57	2	Booty+Abs	Тренер Петя	2026-08-18 12:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
58	2	Booty+Abs	Тренер Петя	2026-08-18 13:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
59	2	Booty+Abs	Тренер Петя	2026-08-18 14:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
62	2	Booty+Abs	Тренер Петя	2026-08-18 17:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
63	2	Booty+Abs	Тренер Петя	2026-08-19 09:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
64	2	Booty+Abs	Тренер Петя	2026-08-19 10:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
65	2	Booty+Abs	Тренер Петя	2026-08-19 11:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
66	2	Booty+Abs	Тренер Петя	2026-08-19 12:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
67	2	Booty+Abs	Тренер Петя	2026-08-19 13:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
68	2	Booty+Abs	Тренер Петя	2026-08-19 14:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
69	2	Booty+Abs	Тренер Петя	2026-08-19 15:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
48	1	Хатха	Кирилл	2026-08-25 14:00:00	60	0			8	4	1	2	confirmed	\N	f	\N	\N
70	2	Booty+Abs	Тренер Петя	2026-08-19 16:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
75	2	Booty+Abs	Тренер Петя	2026-08-20 13:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
80	2	Booty+Abs	Тренер Петя	2026-08-21 09:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
85	2	Booty+Abs	Тренер Петя	2026-08-21 14:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
90	2	Booty+Abs	Тренер Петя	2026-08-24 13:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
71	2	Booty+Abs	Тренер Петя	2026-08-20 09:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
76	2	Booty+Abs	Тренер Петя	2026-08-20 14:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
81	2	Booty+Abs	Тренер Петя	2026-08-21 10:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
86	2	Booty+Abs	Тренер Петя	2026-08-24 09:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
91	2	Booty+Abs	Тренер Петя	2026-08-24 14:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
72	2	Booty+Abs	Тренер Петя	2026-08-20 10:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
77	2	Booty+Abs	Тренер Петя	2026-08-20 15:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
82	2	Booty+Abs	Тренер Петя	2026-08-21 11:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
87	2	Booty+Abs	Тренер Петя	2026-08-24 10:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
92	2	Booty+Abs	Тренер Петя	2026-08-24 15:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
73	2	Booty+Abs	Тренер Петя	2026-08-20 11:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
78	2	Booty+Abs	Тренер Петя	2026-08-20 16:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
83	2	Booty+Abs	Тренер Петя	2026-08-21 12:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
88	2	Booty+Abs	Тренер Петя	2026-08-24 11:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
93	2	Booty+Abs	Тренер Петя	2026-08-24 16:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
74	2	Booty+Abs	Тренер Петя	2026-08-20 12:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
79	2	Booty+Abs	Тренер Петя	2026-08-20 17:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
84	2	Booty+Abs	Тренер Петя	2026-08-21 13:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
89	2	Booty+Abs	Тренер Петя	2026-08-24 12:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
94	2	Booty+Abs	Тренер Петя	2026-08-24 17:00:00	60	400			10	5	\N	1	confirmed	\N	f	\N	\N
52	1	Хатха	Кирилл	2026-09-10 11:00:00	60	1500			8	4	\N	2	confirmed	\N	f	\N	\N
95	1	Хатха	Кирилл	2026-09-10 13:00:00	60	0			15	4	1	2	confirmed	\N	f	\N	\N
96	1	Хатха	Оля	2026-08-19 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
97	1	Хатха	Оля	2026-08-19 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
98	1	Хатха	Оля	2026-08-19 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
99	1	Хатха	Оля	2026-08-19 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
100	1	Хатха	Оля	2026-08-19 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
101	1	Хатха	Оля	2026-08-19 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
102	1	Хатха	Оля	2026-08-19 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
103	1	Хатха	Оля	2026-08-19 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
104	1	Хатха	Оля	2026-08-20 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
105	1	Хатха	Оля	2026-08-20 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
106	1	Хатха	Оля	2026-08-20 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
107	1	Хатха	Оля	2026-08-20 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
108	1	Хатха	Оля	2026-08-20 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
109	1	Хатха	Оля	2026-08-20 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
110	1	Хатха	Оля	2026-08-20 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
111	1	Хатха	Оля	2026-08-20 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
112	1	Хатха	Оля	2026-08-21 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
113	1	Хатха	Оля	2026-08-21 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
114	1	Хатха	Оля	2026-08-21 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
115	1	Хатха	Оля	2026-08-21 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
116	1	Хатха	Оля	2026-08-21 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
117	1	Хатха	Оля	2026-08-21 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
118	1	Хатха	Оля	2026-08-21 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
119	1	Хатха	Оля	2026-08-21 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
120	1	Хатха	Оля	2026-08-24 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
121	1	Хатха	Оля	2026-08-24 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
122	1	Хатха	Оля	2026-08-24 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
123	1	Хатха	Оля	2026-08-24 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
124	1	Хатха	Оля	2026-08-24 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
125	1	Хатха	Оля	2026-08-24 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
126	1	Хатха	Оля	2026-08-24 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
127	1	Хатха	Оля	2026-08-24 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
128	1	Хатха	Оля	2026-08-25 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
129	1	Хатха	Оля	2026-08-25 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
130	1	Хатха	Оля	2026-08-25 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
131	1	Хатха	Оля	2026-08-25 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
132	1	Хатха	Оля	2026-08-25 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
133	1	Хатха	Оля	2026-08-25 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
134	1	Хатха	Оля	2026-08-25 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
135	1	Хатха	Оля	2026-08-25 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
136	1	Хатха	Оля	2026-08-26 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
137	1	Хатха	Оля	2026-08-26 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
138	1	Хатха	Оля	2026-08-26 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
139	1	Хатха	Оля	2026-08-26 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
140	1	Хатха	Оля	2026-08-26 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
141	1	Хатха	Оля	2026-08-26 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
142	1	Хатха	Оля	2026-08-26 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
143	1	Хатха	Оля	2026-08-26 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
144	1	Хатха	Оля	2026-08-27 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
145	1	Хатха	Оля	2026-08-27 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
147	1	Хатха	Оля	2026-08-27 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
148	1	Хатха	Оля	2026-08-27 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
149	1	Хатха	Оля	2026-08-27 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
150	1	Хатха	Оля	2026-08-27 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
151	1	Хатха	Оля	2026-08-27 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
152	1	Хатха	Оля	2026-08-28 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
153	1	Хатха	Оля	2026-08-28 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
154	1	Хатха	Оля	2026-08-28 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
155	1	Хатха	Оля	2026-08-28 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
156	1	Хатха	Оля	2026-08-28 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
157	1	Хатха	Оля	2026-08-28 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
158	1	Хатха	Оля	2026-08-28 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
159	1	Хатха	Оля	2026-08-28 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
164	1	Хатха	Оля	2026-08-31 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
169	1	Хатха	Оля	2026-09-01 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
174	1	Хатха	Оля	2026-09-01 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
179	1	Хатха	Оля	2026-09-02 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
184	1	Хатха	Оля	2026-09-03 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
189	1	Хатха	Оля	2026-09-03 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
194	1	Хатха	Оля	2026-09-04 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
199	1	Хатха	Оля	2026-09-04 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
204	1	Хатха	Оля	2026-09-07 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
160	1	Хатха	Оля	2026-08-31 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
165	1	Хатха	Оля	2026-08-31 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
170	1	Хатха	Оля	2026-09-01 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
175	1	Хатха	Оля	2026-09-01 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
180	1	Хатха	Оля	2026-09-02 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
185	1	Хатха	Оля	2026-09-03 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
190	1	Хатха	Оля	2026-09-03 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
195	1	Хатха	Оля	2026-09-04 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
200	1	Хатха	Оля	2026-09-07 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
205	1	Хатха	Оля	2026-09-07 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
161	1	Хатха	Оля	2026-08-31 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
166	1	Хатха	Оля	2026-08-31 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
171	1	Хатха	Оля	2026-09-01 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
176	1	Хатха	Оля	2026-09-02 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
181	1	Хатха	Оля	2026-09-02 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
186	1	Хатха	Оля	2026-09-03 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
191	1	Хатха	Оля	2026-09-03 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
196	1	Хатха	Оля	2026-09-04 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
201	1	Хатха	Оля	2026-09-07 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
206	1	Хатха	Оля	2026-09-07 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
162	1	Хатха	Оля	2026-08-31 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
167	1	Хатха	Оля	2026-08-31 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
172	1	Хатха	Оля	2026-09-01 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
177	1	Хатха	Оля	2026-09-02 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
182	1	Хатха	Оля	2026-09-02 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
187	1	Хатха	Оля	2026-09-03 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
192	1	Хатха	Оля	2026-09-04 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
197	1	Хатха	Оля	2026-09-04 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
202	1	Хатха	Оля	2026-09-07 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
207	1	Хатха	Оля	2026-09-07 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
163	1	Хатха	Оля	2026-08-31 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
168	1	Хатха	Оля	2026-09-01 09:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
173	1	Хатха	Оля	2026-09-01 14:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
178	1	Хатха	Оля	2026-09-02 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
183	1	Хатха	Оля	2026-09-02 16:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
188	1	Хатха	Оля	2026-09-03 13:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
193	1	Хатха	Оля	2026-09-04 10:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
198	1	Хатха	Оля	2026-09-04 15:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
203	1	Хатха	Оля	2026-09-07 12:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
146	1	Хатха	Оля	2026-08-27 11:00:00	60	1500			15	9	1	2	confirmed	\N	f	\N	\N
208	1	Стретчинг	Кирилл	2026-08-29 10:00:00	60	1500			8	4	1	3	confirmed	\N	f	\N	\N
\.


--
-- Data for Name: loyalty_levels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.loyalty_levels (id, studio_id, name, color, min_threshold, max_threshold, sort_order, point_value) FROM stdin;
1	2	Серебро	#B0B0C0	0	10000	0	1
2	2	Золото	#F0C040	10000	50000	1	1
3	2	Платина	#FCAE91	50000	\N	2	1
4	1	Серебро	#B0B0C0	0	10000	0	1
5	1	Золото	#F0C040	10000	50000	1	1
6	1	Платина	#FCAE91	50000	\N	2	1
7	3	Серебро	#B0B0C0	0	10000	0	1
8	3	Золото	#F0C040	10000	50000	1	1
9	3	Платина	#FCAE91	50000	\N	2	1
\.


--
-- Data for Name: loyalty_point_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.loyalty_point_transactions (id, studio_id, client_id, points, description, created_at) FROM stdin;
1	1	2	72	Начисление за оплату	2026-08-16 22:34:55.529049
\.


--
-- Data for Name: loyalty_scenarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.loyalty_scenarios (id, studio_id, trigger_type, trigger_params, action_type, action_params, channel, is_enabled, fired_count, last_run_at, created_at) FROM stdin;
\.


--
-- Data for Name: notification_event_toggles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_event_toggles (id, studio_id, role, event_id, channel_key, is_enabled) FROM stdin;
1	3	trainer	t1	email	t
\.


--
-- Data for Name: notification_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_logs (id, studio_id, event_id, channel, recipient_id, recipient_address, dedup_key, status, error, created_at, finished_at) FROM stdin;
1	1	o2	email	1	smat5302@gmail.com	54cac932e9dafc58c4f58f1a77c8d544ccf037ec800b3c6c79adc125839b3855	sent	\N	2026-08-10 03:38:25.808552	2026-08-10 03:38:27.058678
2	2	o2	email	2	leramesnjankina@gmail.com	acb3d70e3d099f310046f178fc6b7607ded712e79d664ff0ed77d281ffc42f18	sent	\N	2026-08-10 03:38:27.946193	2026-08-10 03:38:29.045166
3	1	a8	email	1	smat5302@gmail.com	7768a00f00438d0a23ea1e27e28e7a867781b36e92ff87abb0c04a3135523a55	sent	\N	2026-08-10 19:02:47.025395	2026-08-10 19:02:48.835971
4	1	o1	email	1	smat5302@gmail.com	b023c8669ea35ed44434bf09c4371c241c4e9639cfd1308376c64cf51e6cad22	sent	\N	2026-08-10 19:02:48.847856	2026-08-10 19:02:50.527695
5	2	a8	email	2	leramesnjankina@gmail.com	e75b385bec01800b8f29f4ef888535cc0633c37fef780cf07706a3b405779f11	sent	\N	2026-08-10 19:02:50.560679	2026-08-10 19:02:52.949284
6	2	o1	email	2	leramesnjankina@gmail.com	4b5fd914c7b429a397f3471f3ff2df157a030d08181ab7fc579a8f6fde4043cb	sent	\N	2026-08-10 19:02:52.95749	2026-08-10 19:02:54.218427
7	3	a8	email	3	andrii.sadovskiy@gmail.com	2dfcbf8b3993df89b798f90b4289feb2c603e720ffd34d883ba38c312d7899d3	sent	\N	2026-08-10 19:02:54.247701	2026-08-10 19:02:55.352092
8	3	o1	email	3	andrii.sadovskiy@gmail.com	fe73d4a97137a7def6b1ba403a549a15a9cc5e88ef3bcc50ac4cbc61ea60f86f	sent	\N	2026-08-10 19:02:55.359855	2026-08-10 19:02:57.201634
9	1	a8	email	1	smat5302@gmail.com	858d4f1460170f68161ac72e6e54c90d4936cfc45d9ae9a49abf14f1341ab481	sent	\N	2026-08-11 19:00:07.432862	2026-08-11 19:00:08.93077
10	1	o1	email	1	smat5302@gmail.com	2fa9415ec7475c7ed4f42b6e929c004554d21c6ce739ce9bb407bd84ea1732af	sent	\N	2026-08-11 19:00:08.942862	2026-08-11 19:00:11.476304
11	2	a8	email	2	leramesnjankina@gmail.com	24364d61e15dd782761363d2b04df1996097a9c58796de9ebf4d1cf37eb6cf9d	sent	\N	2026-08-11 19:00:11.515131	2026-08-11 19:00:14.015482
12	2	o1	email	2	leramesnjankina@gmail.com	4ceccbb86a720eca95ec4be97fe7fee37e42ed66155064992c30e2eb78f555df	sent	\N	2026-08-11 19:00:14.024292	2026-08-11 19:00:15.335469
13	3	a8	email	3	andrii.sadovskiy@gmail.com	5a64ffef7f6f6faaf32b51bb78fa7ed69fddfb608efb0b000b70c7e4e2e0c302	sent	\N	2026-08-11 19:00:15.365554	2026-08-11 19:00:16.422908
14	3	o1	email	3	andrii.sadovskiy@gmail.com	c65966531a4492fbdd8ac211e0e1ea59ceb46fb0a9a9eb555e2b9b7cd01fa6d7	sent	\N	2026-08-11 19:00:16.431363	2026-08-11 19:00:17.413908
15	2	o1	email	2	leramesnjankina@gmail.com	0d0bf44e51204dc4b77cee8809a01ccbd7fa32d5157c9546f8b6b71b56a00645	sent	\N	2026-08-12 19:03:41.615264	2026-08-12 19:03:43.330794
16	3	o1	email	3	andrii.sadovskiy@gmail.com	c3eb31bf6e76bcac9274677b00416810facdbc1c722d0842cc03534454bc18d3	sent	\N	2026-08-12 19:03:43.366043	2026-08-12 19:03:44.344162
17	1	o1	email	1	smat5302@gmail.com	7af37b84168a38409dfcdd67c5ac17bc1c45aeec5d370b552cf90cfc79d8ac8f	sent	\N	2026-08-12 19:03:44.373021	2026-08-12 19:03:46.080356
18	2	o1	email	2	leramesnjankina@gmail.com	2c593e22935d6947512815d3a11d6596ca9944ad2b4ba6b90e8e4165d009e7d7	sent	\N	2026-08-13 19:03:50.596326	2026-08-13 19:03:52.59349
19	3	o1	email	3	andrii.sadovskiy@gmail.com	018bcca138a930235a8a4137dcb129ed8ecc247fbf6692d855b109de2938e8ae	sent	\N	2026-08-13 19:03:52.629986	2026-08-13 19:03:54.659383
20	1	o1	email	1	smat5302@gmail.com	59b63eec08128e5a622a1e29016cbd82c3a0bce6f4b49581d1763140de5b5a0e	sent	\N	2026-08-13 19:03:54.69081	2026-08-13 19:03:55.86943
21	2	o1	email	2	leramesnjankina@gmail.com	698ed01444fa7dc3ba81dea746599fe90884e9d8e53262e206ab6dbadf982c91	sent	\N	2026-08-14 19:04:00.302446	2026-08-14 19:04:01.571152
22	3	o1	email	3	andrii.sadovskiy@gmail.com	1fd272e0a023987fbdec960b3580d52d59d82d9cb70f7a878c02c981c44c2a00	sent	\N	2026-08-14 19:04:01.615454	2026-08-14 19:04:03.461059
23	1	o1	email	1	smat5302@gmail.com	4295dd266b12a19c2f5e87ba9bcbd59be3dc700817b5392420563df61c695062	sent	\N	2026-08-14 19:04:03.4964	2026-08-14 19:04:05.272725
24	2	o1	email	2	leramesnjankina@gmail.com	8e28048c83d7966a8db8b69d70ad608447241753b0a4a1cac857b7046ceb33f2	sent	\N	2026-08-15 19:04:09.729249	2026-08-15 19:04:12.786407
25	3	o1	email	3	andrii.sadovskiy@gmail.com	b4ffb45fb9140198d3452d134841082f1bf6c1d9483d5e887732694d6e9cb1be	sent	\N	2026-08-15 19:04:12.817752	2026-08-15 19:04:15.372327
26	1	o1	email	1	smat5302@gmail.com	d6199fd725f20de87c28e9f90b81f731225c5e58b1ab168b46d0df4da253ee3c	sent	\N	2026-08-15 19:04:15.397391	2026-08-15 19:04:18.081502
27	2	o6	email	2	leramesnjankina@gmail.com	77637bea47e667ac6328a317677619942b4131dd35f52b84d12bd5ddaa88d759	sent	\N	2026-08-15 23:04:18.83541	2026-08-15 23:04:22.523729
28	3	o6	email	3	andrii.sadovskiy@gmail.com	1b7b72175f971f598ca3d0b3df913af6112064e992a7b922ce7bf096b1fbbb61	sent	\N	2026-08-15 23:04:22.54605	2026-08-15 23:04:25.669787
29	1	o6	email	1	smat5302@gmail.com	7d9f825567954766758e2eda71b10bd1462c1dc93dc8714725ec6b033562d35c	sent	\N	2026-08-15 23:04:25.686555	2026-08-15 23:04:28.788813
30	1	o5	email	1	smat5302@gmail.com	6215ff72b39bddd8b24cd892246ef5988969543c7fb19ff1d75b1f4225a768d7	sent	\N	2026-08-16 17:17:19.488411	2026-08-16 17:17:20.671835
31	1	c4	email	1	smat5302@gmail.com	9e353966221d059c2100671ceb1d648a6831cf67ac8257ff1b2b024fed51418b	sent	\N	2026-08-16 20:41:53.639939	2026-08-16 20:41:55.031557
32	1	a4	email	1	smat5302@gmail.com	03a9abd76acc782f655dd1b050d9bd8a25a307ef912c5ffdee90ae1b1657c3fe	sent	\N	2026-08-16 20:41:55.044663	2026-08-16 20:41:56.605971
33	1	c1	email	1	smat5302@gmail.com	6894bedb7ea6b8a2100d13ae650f1c4b9c50739d0fde33b920f8973ebd28fb3d	sent	\N	2026-08-16 20:43:16.897623	2026-08-16 20:43:18.443505
34	1	a1	email	1	smat5302@gmail.com	751c26ba118ed8a8e086fc20aa0097330590545a0f69adbf840527d8cf7e9279	sent	\N	2026-08-16 20:43:18.454532	2026-08-16 20:43:19.655347
35	1	t1	email	4	cartoonlvl2@gmail.com	e440802b31d8bc77ca2034ae57b7c0e5364f75801bddd1db1aed25495eddb1f8	sent	\N	2026-08-16 20:43:19.664837	2026-08-16 20:43:20.780338
36	2	o5	email	2	leramesnjankina@gmail.com	a465af9bdc2bf4cc5d18cf32dd35161d08cba29f495cdab369d0fbfda548619f	sent	\N	2026-08-16 22:12:05.303777	2026-08-16 22:12:10.680576
38	2	t5	email	5	valeriatutor2025@gmail.com	e64eb469263796ce87e2de695a9e9f7e18009844419a2abe2d5898b2df24839b	sent	\N	2026-08-16 22:13:28.30908	2026-08-16 22:13:30.602025
37	2	t5	email	5	valeriatutor2025@gmail.com	f119748e998e6d56617da5478557b3029c07d57c9eaf74512389aab83d603cbf	sent	\N	2026-08-16 22:13:22.555394	2026-08-16 22:13:32.331389
39	1	c4	email	2	leramesnjankina@gmail.com	e4ce3104cb78ea627711a2bf595d9b56e5cc381b8239eca314644ada53e1e326	sent	\N	2026-08-16 22:34:55.590511	2026-08-16 22:34:57.020212
40	1	a4	email	1	smat5302@gmail.com	19ca66fd920af92984c1707017402f2debb8881090f5e2df6d2aa35d4fa92b8a	sent	\N	2026-08-16 22:34:57.030021	2026-08-16 22:34:58.321334
41	1	c1	email	2	leramesnjankina@gmail.com	b1b8595e88bc2019a6292699a1b27e2f24c574d1d1198faafbb6615f807a1d67	sent	\N	2026-08-16 22:35:39.903081	2026-08-16 22:35:41.085599
42	1	a1	email	1	smat5302@gmail.com	a709313404d6acc931f8966e4d114af1c74ccccc7ded5cfa84b8b390d81963a8	sent	\N	2026-08-16 22:35:41.095294	2026-08-16 22:35:42.648881
43	1	t1	email	4	cartoonlvl2@gmail.com	dba12f51f38b3116bd4df0dd4fede4974b0e635d40c8e43ed805e800efd051f2	sent	\N	2026-08-16 22:35:42.656796	2026-08-16 22:35:44.190618
44	1	c3	email	2	leramesnjankina@gmail.com	f370f7b4ef38f3756cb36d1c4f452003029e58df9c1c2f26b9c7537b71a34d1a	sent	\N	2026-08-16 22:37:08.960247	2026-08-16 22:37:10.62141
47	1	o2	email	1	smat5302@gmail.com	24a9b35c135e42a1455141bdcdd601695b956c8486a4eb0f97201954e9f18e01	sent	\N	2026-08-16 23:03:34.997946	2026-08-16 23:03:36.164827
45	2	o6	email	2	leramesnjankina@gmail.com	14ff8d13908e44c8e04fd7bfd99a46dd2c0d2eb9355ec17714a5d34aa8434862	sent	\N	2026-08-16 23:03:32.270673	2026-08-16 23:03:33.563215
64	1	c2	email	1	smat5302@gmail.com	6bf889d23c6295717b23133db771c6cecf4799b889ed1f4af71f4d1ed771c0c4	sent	\N	2026-08-18 09:03:52.147955	2026-08-18 09:03:53.342756
46	3	o6	email	3	andrii.sadovskiy@gmail.com	fc80152b76fa724256b4f77a62774690866038f75babfcfedbaefabd2be89904	sent	\N	2026-08-16 23:03:33.601207	2026-08-16 23:03:34.964352
48	1	o6	email	1	smat5302@gmail.com	5ef29985db856efe061534beb92249de0926c24467a3e0c006883db8c45b1476	sent	\N	2026-08-16 23:03:36.173567	2026-08-16 23:03:36.932632
66	1	o5	email	1	smat5302@gmail.com	c6ec1b0285b78a2c35d856cdd3072c0fc9b3f59c729bda35cd0e99eb0e53d799	sent	\N	2026-08-18 15:46:03.254792	2026-08-18 15:46:04.63205
49	1	c1	email	1	smat5302@gmail.com	e9a31b84bff8120cb503ec2782984bbb0ac7bd9101ad35845bedc85d90d31af1	sent	\N	2026-08-16 23:32:52.336505	2026-08-16 23:32:53.992176
51	1	t1	email	4	cartoonlvl2@gmail.com	c5a9f2d32548036f89882b8441778ed9432c511bc9069def31033b8db2c08be6	sent	\N	2026-08-16 23:32:55.164125	2026-08-16 23:32:56.690077
68	1	o5	email	1	smat5302@gmail.com	6ee866fa18938352d952337b2f93f7f6b3d7efc1caaa7ffa60e004a9a14c6665	sent	\N	2026-08-18 15:46:08.976608	2026-08-18 15:46:10.533841
70	1	t5	email	9	lvlcartoon8@gmail.com	c6f558c85aa4dbd69e68fdf6938ffbe223f0f1ecf87123c6ed6185041a59a531	sent	\N	2026-08-18 17:35:40.734072	2026-08-18 17:35:42.243036
71	1	t5	email	9	lvlcartoon8@gmail.com	8a0f9db0940c402cec3864a08c3f2fe9ba035075ddc73175cfc0a4152daffb1b	sent	\N	2026-08-18 17:35:41.302937	2026-08-18 17:35:42.731132
73	2	o1	email	2	leramesnjankina@gmail.com	c8cd44fa08f14b8794c2e5976a42e4d3ec42f7c0520eea48626f2e5c3deffc95	sent	\N	2026-08-18 19:02:30.694406	2026-08-18 19:02:31.635032
74	1	o4	email	1	smat5302@gmail.com	73797d2bf51578035dd570684f2533e60b2ff34a6c827e8baf9cdf2627c0cd43	sent	\N	2026-08-18 19:02:31.681217	2026-08-18 19:02:32.530254
75	2	o6	email	2	leramesnjankina@gmail.com	97b276f2e2b298ce06cca5bb7c6cfbf80801034a0348a01ce5e940e98f0b1ad2	sent	\N	2026-08-18 23:02:33.405109	2026-08-18 23:02:34.544682
77	1	o6	email	1	smat5302@gmail.com	e484cd9058988d5f9c47771b9154521815104de9b5d317cb157adbf4274b4bb3	sent	\N	2026-08-18 23:02:35.385623	2026-08-18 23:02:36.463667
79	1	t3	email	4	cartoonlvl2@gmail.com	2e0f8a5f1c9f77b3d22a910a688008f1d40feaa3122868208300ce419eb58a0c	sent	\N	2026-08-19 08:02:32.16421	2026-08-19 08:02:33.289563
80	1	t4	email	4	cartoonlvl2@gmail.com	c115d8f7818b2c10525ae3eae3641eaffbbd5242dab88ff12a6acb41747e3efa	sent	\N	2026-08-19 08:32:33.430829	2026-08-19 08:32:34.384813
86	1	o1	email	1	smat5302@gmail.com	077ddce0d4d06e539e05f6b479aa28b0df3739f5317b3afa4c4b98ec23aab5c3	sent	\N	2026-08-19 19:02:42.799624	2026-08-19 19:02:43.870396
88	2	o1	email	2	leramesnjankina@gmail.com	9de07e8b1f3c0890d1c0af777748aa395501b06ab3c0486771e83cb2932f19ae	sent	\N	2026-08-20 19:02:50.408896	2026-08-20 19:02:51.469038
89	1	a8	email	6	sadomat31@gmail.com	c68576dff2e6b3ff4f7cb98f9bbd50b02f8e635348c1aafe58ee2617165b98a8	sent	\N	2026-08-20 19:02:51.527883	2026-08-20 19:02:52.598749
91	1	o4	email	1	smat5302@gmail.com	c8b0656442881d6e7945bcb8479d4b5d4f6b1fa5a79836383e68544652877919	sent	\N	2026-08-20 19:02:53.733864	2026-08-20 19:02:55.543974
92	1	t6	email	1	smat5302@gmail.com	4d4ab2a0b4ea839fc29735c3d05584d41f1cb271b45086e832dc9a6eb3672ffd	sent	\N	2026-08-20 20:54:52.844295	2026-08-20 20:54:53.961381
95	1	o1	email	1	smat5302@gmail.com	20212741a1a07494105d6fbe56b6f421ef3400b54c48828d3c15bcf5c98ca573	sent	\N	2026-08-21 19:03:02.496904	2026-08-21 19:03:03.628738
100	1	o4	email	1	smat5302@gmail.com	ed7516001c244aaad5d3190d24d7e5661bfe58b1175cd7515620827522b65e24	sent	\N	2026-08-23 19:02:41.869581	2026-08-23 19:02:42.949664
103	2	o1	email	2	leramesnjankina@gmail.com	122e2579957d3c5d9fbc51e0c46f4c45f958b920dd3347df761434f41b5eeb98	sent	\N	2026-08-24 19:02:50.008815	2026-08-24 19:02:51.632603
104	1	a8	email	6	sadomat31@gmail.com	9d12cb84474bb355098c0a205080a368ccddd5413fb4c30a1bd9dde578384b91	sent	\N	2026-08-24 19:02:52.479666	2026-08-24 19:02:53.418639
105	1	o1	email	1	smat5302@gmail.com	67864317a593d9a88a21dac1ceabab3d4de0c7f6284a80e179bda30ee183cb64	sent	\N	2026-08-24 19:02:53.426943	2026-08-24 19:02:54.356491
107	1	o1	email	1	smat5302@gmail.com	fc40e4ad66e99e0a422d52efab9eed6ef77cfe940e37daade8502fef3c5b3816	sent	\N	2026-08-25 19:03:00.483554	2026-08-25 19:03:01.33619
109	1	o1	email	1	smat5302@gmail.com	9d896140d0b5aa9c823875e99460692539b78b09c82e0fcc5cbb305fabde72be	sent	\N	2026-08-26 19:03:07.123938	2026-08-26 19:03:07.913417
111	1	o1	email	1	smat5302@gmail.com	174547d1f5e843cc7d0568ddc5c815e2ba1907b980710794924f252df36b9738	sent	\N	2026-08-27 19:03:13.825764	2026-08-27 19:03:14.524011
113	1	a8	email	6	sadomat31@gmail.com	a91c32f481da62565217c2402c1ab59ce2ea1d650b42e317445a10b4c48238e4	sent	\N	2026-08-28 19:03:00.985029	2026-08-28 19:03:02.772471
115	4	o6	email	7	sadovskiymatviy64@gmail.com	9858910d1cacdd43f227e00d3e83ff954ed6352cb9711b77f15fc9fb0b74f935	sent	\N	2026-08-28 23:03:05.626449	2026-08-28 23:03:06.656074
118	4	o6	email	7	sadovskiymatviy64@gmail.com	dfa25cb49b66509a2fe6bd057e12e6e97a2f536115b638a4aa3c35bf20009e91	sent	\N	2026-08-29 23:03:14.04343	2026-08-29 23:03:17.350747
121	4	o6	email	7	sadovskiymatviy64@gmail.com	59ace3a7e897ade25c80cb77539c7498801c5de70ba7578cd545e4420ec6db19	sent	\N	2026-08-30 23:03:25.760699	2026-08-30 23:03:27.199642
123	1	o1	email	1	smat5302@gmail.com	d09ee0f42c56a604665fe7239f49ff3ebfc41a00a9717c4ac2bb08697a074def	sent	\N	2026-08-31 19:03:33.457567	2026-08-31 19:03:34.45222
50	1	a1	email	1	smat5302@gmail.com	9efd80c39eb1929131d826ef44efedd37c44fdfe79675ad4b29338a87d891a1d	sent	\N	2026-08-16 23:32:54.001284	2026-08-16 23:32:55.155478
65	1	c2	email	1	smat5302@gmail.com	0deebe11e13c6a705ea1c02a2b605884674c147f3655f975fa50295377d7b05c	sent	\N	2026-08-18 12:03:54.010694	2026-08-18 12:03:55.170212
52	1	o5	email	1	smat5302@gmail.com	7f110c941159e8504ba120058a0055d412226a987de870e88d7121f913c612f3	sent	\N	2026-08-16 23:38:22.760458	2026-08-16 23:38:26.023569
53	1	t5	email	4	cartoonlvl2@gmail.com	1619ba6ddf6c656ea0bace3aa10b9c7340dbe7ecd9393b64e753efef06353bff	sent	\N	2026-08-16 23:39:41.189507	2026-08-16 23:39:42.401481
67	1	o5	email	1	smat5302@gmail.com	90fc3cb42446533d7f8a93d9910736acec06461b3c585b516b20676738445e77	sent	\N	2026-08-18 15:46:06.664286	2026-08-18 15:46:07.594542
54	1	c3	email	1	smat5302@gmail.com	81bd94bd6bc02f7a497543bec04447be2314c5b03b573c5c87e816288e025638	sent	\N	2026-08-16 23:41:03.054818	2026-08-16 23:41:04.755453
56	1	a1	email	6	sadomat31@gmail.com	48f1119a5c276152f8764b7c6622bb79da055b41022360c8ac9cadc49957c16b	sent	\N	2026-08-16 23:41:07.874975	2026-08-16 23:41:09.109758
69	1	a7	email	6	sadomat31@gmail.com	2a43d2ab89094f476c077f543961a6a2e5010fbbe8e889ffb8e60d5bd2b1f5f4	sent	\N	2026-08-18 15:58:25.268667	2026-08-18 15:58:26.318901
58	1	t5	email	4	cartoonlvl2@gmail.com	1bd2fd959a28fc40800d541cb2d3680a8d056ae761b9c52735173ca6c32e2ae1	sent	\N	2026-08-17 00:09:28.530824	2026-08-17 00:09:30.832987
59	2	o1	email	2	leramesnjankina@gmail.com	1ec30bd92b09733412e437aab243afd77bf0612cb15be17dcd9cc0dbeb35beea	sent	\N	2026-08-17 19:03:41.12043	2026-08-17 19:03:43.540121
72	1	a7	email	6	sadomat31@gmail.com	291e7ff75ea48eb2abb87177aad5be11cc8e01da954c34e4266e5ca541a8f87b	sent	\N	2026-08-18 17:35:42.256971	2026-08-18 17:35:44.263719
60	1	o4	email	1	smat5302@gmail.com	2b784534770e84222cb6e767753c264f5de1dddee2c626f75d725445d9a21c2f	sent	\N	2026-08-17 19:03:43.602244	2026-08-17 19:03:45.598939
61	2	o6	email	2	leramesnjankina@gmail.com	85896689e0eda35b4130f34014baf2a5164cfc5d6f53f6e951607b9c6ed821ac	sent	\N	2026-08-17 23:03:46.48173	2026-08-17 23:03:48.020233
76	3	o6	email	3	andrii.sadovskiy@gmail.com	84581e10683d188972c5e2184af27d373d6e7f6a64cc471d2ff1dd70b4852f6c	sent	\N	2026-08-18 23:02:34.58238	2026-08-18 23:02:35.368225
62	3	o6	email	3	andrii.sadovskiy@gmail.com	20a472dc78b0914f1e79394e9cb6a03dfec575d82cc4666e3a60b1806e002333	sent	\N	2026-08-17 23:03:48.044195	2026-08-17 23:03:49.039696
63	1	o6	email	1	smat5302@gmail.com	6206cb1127d9ac2ffd45c25ce178dec2007b8ac9c0e9a05d87389bfc7657479d	sent	\N	2026-08-17 23:03:49.055302	2026-08-17 23:03:50.078405
78	1	c2	email	1	smat5302@gmail.com	0f55f7755debda4b48daa8aa1e856e0770dc5c45dc00b9aa6a953b24c531d2ed	sent	\N	2026-08-19 07:02:30.809811	2026-08-19 07:02:31.940795
81	1	c2	email	1	smat5302@gmail.com	4d8af5afe088da1c2e4e36b6528f3f6fa94eccfeb6fe1f4ad5c88a5c156bb85c	sent	\N	2026-08-19 10:02:34.740478	2026-08-19 10:02:36.036039
82	1	t3	email	4	cartoonlvl2@gmail.com	151c9fe3972bd27499a1ff2d8d8112abdb7cd3d04d96af2427026f43e4b7e224	sent	\N	2026-08-19 11:02:36.327322	2026-08-19 11:02:37.518902
83	1	t4	email	4	cartoonlvl2@gmail.com	d6fe379e3b3512b53db936f6a3c8ae80fc135f1592babae874002c0f52c4b882	sent	\N	2026-08-19 11:32:37.666101	2026-08-19 11:32:38.699864
84	2	o1	email	2	leramesnjankina@gmail.com	809cce1192e942030c913a45508b33e2cefe716e2c48f798c0415088a1d7abc6	sent	\N	2026-08-19 19:02:40.507097	2026-08-19 19:02:41.601433
85	1	a8	email	6	sadomat31@gmail.com	5a44e95f2c92509ae95bd5cca8c12c029966e42c7faf37a0bc64659844065251	sent	\N	2026-08-19 19:02:41.661093	2026-08-19 19:02:42.791246
87	1	o4	email	1	smat5302@gmail.com	9e805791a2ec812f341740c74dbafd27d0b059885b88152a7b266d479b522779	sent	\N	2026-08-19 19:02:43.879449	2026-08-19 19:02:45.013703
90	1	o1	email	1	smat5302@gmail.com	bf7d3b5bcac352bf02e50679b6bbd897443fdee232d1b02907b01bbc19fce3fc	sent	\N	2026-08-20 19:02:52.606992	2026-08-20 19:02:53.724968
93	2	o1	email	2	leramesnjankina@gmail.com	355c55bd33952ab6e3dfa89543d5b61c35acb940765f5c8fccbb0cb74b9e8443	sent	\N	2026-08-21 19:03:00.546959	2026-08-21 19:03:01.647814
94	1	a8	email	6	sadomat31@gmail.com	d7adeea8294fb40542291d775814eeb13ccbfd36b976834bdf20b11f5728b1c6	sent	\N	2026-08-21 19:03:01.694144	2026-08-21 19:03:02.488699
96	1	o4	email	1	smat5302@gmail.com	bcef3d756dd0bf9d9c35786ea593b6abb9d77b8e7d99d6ae74f9b960387b9d27	sent	\N	2026-08-21 19:03:03.638052	2026-08-21 19:03:04.688143
97	1	a8	email	6	sadomat31@gmail.com	895722879d70a57950490d0da4a07fc251cb92fa9c34af0e43aa02f0ebee3a9a	sent	\N	2026-08-22 19:03:09.638074	2026-08-22 19:03:10.773141
98	1	o1	email	1	smat5302@gmail.com	2a2e24f108bba2809243a1832d9eff9562bb33e93e46f4687690db3471cfebf5	sent	\N	2026-08-22 19:03:10.784818	2026-08-22 19:03:11.817194
99	1	o4	email	1	smat5302@gmail.com	3798383b46eed9f36b0af5d9ba6a61270f6bdb5ba2da677ee13b7d3895e48455	sent	\N	2026-08-22 19:03:11.827121	2026-08-22 19:03:12.710375
101	2	o2	email	2	leramesnjankina@gmail.com	6996276acb7cf94d0ef63f05d12ed52426d7fde36b01490b838af7b39b51bb65	sent	\N	2026-08-23 23:02:43.795588	2026-08-23 23:02:44.785614
102	1	o2	email	1	smat5302@gmail.com	b3d9a3d950b05de58a794a43c336a652a5811865c781b4147fd9011f898e3d22	sent	\N	2026-08-23 23:02:44.846123	2026-08-23 23:02:45.777977
106	1	a8	email	6	sadomat31@gmail.com	c0731492014f5cdb2c0f1bd473a27e1c3138b6e841d214e0b631eb5dd42b7db1	sent	\N	2026-08-25 19:02:59.354185	2026-08-25 19:03:00.473927
108	1	a8	email	6	sadomat31@gmail.com	a0ceba0989166e28059951cd59561275b192e1c2474cb579d0113cb779b6c653	sent	\N	2026-08-26 19:03:06.260557	2026-08-26 19:03:07.115201
110	1	a8	email	6	sadomat31@gmail.com	3bb36ae6e92f7e6fb2315ffd6babe910753624e2edf6fd06a7e1de1a0754fc4c	sent	\N	2026-08-27 19:03:12.715395	2026-08-27 19:03:13.815862
112	4	o6	email	7	sadovskiymatviy64@gmail.com	163eeda8f29ccda7f0d99cc0607d81df9249b63ce165af15ed0fba6f5d14c5ef	sent	\N	2026-08-27 23:03:15.359441	2026-08-27 23:03:16.422423
114	1	o1	email	1	smat5302@gmail.com	5f58c9d91208df332baa3034c85c3fbe01cd65df623d037df36af6b0b54306f7	sent	\N	2026-08-28 19:03:02.782111	2026-08-28 19:03:04.783123
116	1	a8	email	6	sadomat31@gmail.com	61e36fe53747b40546edeedeb29be6bb6ee3afa361d41f5899f1baccfc5c60a4	sent	\N	2026-08-29 19:03:10.610123	2026-08-29 19:03:12.222804
117	1	o1	email	1	smat5302@gmail.com	3d80827238c4a5e8b1bb74e941401680c100bdc8093d5b28ed02e04bd04aea0c	sent	\N	2026-08-29 19:03:12.231373	2026-08-29 19:03:13.218239
119	2	o2	email	2	leramesnjankina@gmail.com	607f5e02a841edfae712494c1deadc999064fea9d9a1b00c634e9e88b586cbb2	sent	\N	2026-08-30 23:03:22.108254	2026-08-30 23:03:23.788722
120	1	o2	email	1	smat5302@gmail.com	13db1a7b89a1b8ea4773bbe71d1d597b99cf09a1886d8d87a487bc16643ef19e	sent	\N	2026-08-30 23:03:23.874126	2026-08-30 23:03:25.72679
122	1	a8	email	6	sadomat31@gmail.com	f0738c1435001286938b90983d2bbaa4d5c16314dcdc3068b0ad671fac09b0c9	sent	\N	2026-08-31 19:03:31.681521	2026-08-31 19:03:33.447982
\.


--
-- Data for Name: offline_transaction_fees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.offline_transaction_fees (id, studio_id, client_id, sale_amount, fee_amount, currency, percent_rate, payment_method, created_at, invoice_id) FROM stdin;
\.


--
-- Data for Name: online_channel_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.online_channel_metrics (id, studio_id, channel_id, period_type, period_date, amount, transactions_count) FROM stdin;
\.


--
-- Data for Name: online_channels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.online_channels (id, studio_id, channel_type, is_active, monthly_amount, monthly_sessions, account_id) FROM stdin;
1	1	stripe	t	0	0	acct_1U6c7z0A1y9aB3tp
\.


--
-- Data for Name: operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operations (id, studio_id, client_id, account_id, counterparty_id, trainer_id, product_id, type, title, amount, op_date, category, method, status, service_id) FROM stdin;
1	1	1	1	\N	\N	\N	in	Абонемент «8 занятий»	8000	2026-08-16	Абонементы	cash	completed	\N
2	1	2	1	\N	\N	\N	in	Абонемент «8 занятий»	7200	2026-08-16	Абонементы	cash	completed	\N
3	1	\N	\N	\N	1	\N	out	Зарплата: Sad Mat	0	2026-08-20	Зарплата		completed	\N
\.


--
-- Data for Name: outbound_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outbound_messages (id, studio_id, thread_id, origin, payload, dedup_key, status, attempt, run_after, locked_by, locked_at, provider_message_id, created_at, accepted_at, last_error) FROM stdin;
\.


--
-- Data for Name: payment_cards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_cards (id, user_id, card_last4, card_brand, card_expiry, cardholder_name, is_primary, rectoken, method_type, stripe_customer_id) FROM stdin;
\.


--
-- Data for Name: payment_method_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_method_configs (id, studio_id, method_type, method_name, is_enabled, commission_rate, monthly_transactions) FROM stdin;
\.


--
-- Data for Name: platform_revenue_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.platform_revenue_ledger (id, studio_id, source, amount, currency, external_id, occurred_at) FROM stdin;
\.


--
-- Data for Name: product_sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_sales (id, studio_id, product_id, client_id, operation_id, quantity, amount, payment_method, is_new_client, sold_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, studio_id, name, product_type, price, unit_label, badge_type, is_active, color, sort_order) FROM stdin;
\.


--
-- Data for Name: referral_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.referral_records (id, studio_id, referrer_client_id, referred_client_id, status, bonus_paid, created_at, discount_used) FROM stdin;
\.


--
-- Data for Name: reservations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reservations (id, client_id, lesson_id, spot_number, status, rating, review_text, created_at, booking_channel, cancelled_at, cancellation_reason, subscription_id, coffee, is_trial, debt_payment_id) FROM stdin;
1	1	4	3	active	\N	\N	2026-08-16 20:43:16.597476	telegram	\N	\N	1	t	f	\N
2	2	28	3	cancelled	\N	\N	2026-08-16 22:35:39.875491	telegram	2026-08-16 22:37:08.945812	\N	\N	t	f	\N
3	1	1	3	cancelled	\N	\N	2026-08-16 23:32:52.302803	telegram	2026-08-16 23:41:03.03612	\N	\N	f	f	\N
4	1	1	3	active	\N	\N	2026-08-16 23:41:07.842794	telegram	\N	\N	1	t	f	\N
\.


--
-- Data for Name: salary_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_payments (id, studio_id, user_id, period_start, period_end, sessions_count, hours_worked, rate_snapshot, rate_type_snapshot, amount, status, paid_at, note) FROM stdin;
1	1	1	2026-07-31	2026-08-30	0	0	0	fixed	0	paid	2026-08-20 20:54:52.814037	\N
\.


--
-- Data for Name: scenario_fires; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scenario_fires (id, scenario_id, client_id, dedup_key, fired_at) FROM stdin;
\.


--
-- Data for Name: service_schedule_slots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_schedule_slots (id, service_id, day_of_week, start_time, end_time) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, studio_id, name, description, price, duration_min, category, service_type, color, max_clients, bookings_count, revenue_total) FROM stdin;
1	2	Booty+Abs	\N	400	60	yoga	group	#A3C9A8	10	0	0
2	1	Хатха	\N	1500	60	pilates	group	#B3A5D9	15	0	0
3	1	Стретчинг	\N	1500	60	stretching	group	\N	\N	0	0
\.


--
-- Data for Name: staff_day_overrides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_day_overrides (id, user_id, studio_id, day, is_working) FROM stdin;
16	9	1	2026-08-18	t
17	9	1	2026-08-19	t
18	9	1	2026-08-20	t
19	9	1	2026-08-21	t
20	9	1	2026-08-24	t
21	9	1	2026-08-25	t
22	9	1	2026-08-26	t
23	9	1	2026-08-27	t
24	9	1	2026-08-28	t
25	9	1	2026-08-31	t
26	9	1	2026-08-22	f
27	9	1	2026-08-29	f
29	9	1	2026-08-23	f
28	9	1	2026-08-30	f
\.


--
-- Data for Name: staff_working_hours; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_working_hours (id, user_id, day_of_week, is_open, open_time, close_time, studio_id) FROM stdin;
1	4	0	t	09:00	18:00	1
2	4	1	t	09:00	18:00	1
3	4	2	t	09:00	18:00	1
4	4	3	t	09:00	18:00	1
5	4	4	t	09:00	18:00	1
6	4	5	t	10:00	16:00	1
7	4	6	t	10:00	16:00	1
8	5	0	t	09:00	18:00	2
9	5	1	t	09:00	18:00	2
10	5	2	t	09:00	18:00	2
11	5	3	t	09:00	18:00	2
12	5	4	t	09:00	18:00	2
13	5	5	f	10:00	16:00	2
14	5	6	f	10:00	16:00	2
15	9	0	t	09:00	17:00	1
16	9	1	t	09:00	17:00	1
17	9	2	t	09:00	17:00	1
18	9	3	t	09:00	17:00	1
19	9	4	t	09:00	17:00	1
\.


--
-- Data for Name: stripe_checkouts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stripe_checkouts (id, studio_id, user_id, session_id, account_id, payload, amount, status, created_at, application_fee, subscription_id) FROM stdin;
\.


--
-- Data for Name: studio_ai_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_ai_settings (id, studio_id, model, language, system_prompt, tg_enabled, tg_token, tg_username, tg_tone, tg_max_length, tg_handled_count, tg_avg_rating, ig_enabled, ig_token, ig_username, ig_tone, ig_max_length, ig_off_hours_only, ig_handled_count, ig_avg_rating, ig_user_id, ig_token_expires_at, wa_enabled, wa_tone, wa_max_length, wa_off_hours_only, wa_handled_count, wa_avg_rating) FROM stdin;
2	2	velora-3.5	auto	Ты — вежливый ассистент студии «Valeria Studio». Отвечай кратко, по делу и дружелюбно.	f	\N	\N	friendly	500	0	0	f	\N	\N	friendly	300	t	0	0	\N	\N	f	friendly	300	f	0	0
3	3	velora-3.5	auto	Ты — вежливый ассистент студии «Andrii». Отвечай кратко, по делу и дружелюбно.	f	\N	\N	friendly	500	0	0	f	\N	\N	friendly	300	t	0	0	\N	\N	f	friendly	300	f	0	0
1	1	velora-3.5	auto	Ты — вежливый ассистент студии «Велора». Отвечай кратко, по делу и дружелюбно.	t	gAAAAABqhF4RW2jdzgx6loFat5FI4Nqv5QGVMbIolwzBKcR7H_EcoIXvV5o_0EDWo5zDCn2FO5U1KDuJ0-Avajg5YusQNXdOjg6dU5UfXL_ssesR54ndZli5rfnxHk_jmkBZnkw1Irbj	ClientToBarberBot	friendly	500	14	0	f	\N	\N	friendly	300	t	0	0	\N	\N	f	friendly	300	f	0	0
\.


--
-- Data for Name: studio_billing_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_billing_plans (id, studio_id, plan_name, billing_cycle, status, expires_at, max_staff, billing_mode, percent_rate, fixed_base_amount, auto_renewal, email_receipt_enabled, notify_before_days, sms_notification_enabled, notify_before_autocharge, stripe_customer_id, stripe_subscription_id, percent_terms_accepted_at, percent_terms_rate, percent_terms_version, scheduled_plan, scheduled_at, trial_started_at) FROM stdin;
3	3	free_trial	monthly	trial	2026-08-19 22:55:40.606335	15	subscription	\N	\N	t	t	3	f	t	\N	\N	\N	\N	\N	\N	\N	2026-08-16 00:30:53.213809
4	4	free_trial	monthly	trial	2026-08-31 09:33:55.100219	15	subscription	\N	\N	t	t	3	f	t	\N	\N	\N	\N	\N	\N	\N	2026-08-17 09:33:55.100219
1	1	free_trial	monthly	active	2026-09-19 02:38:07	15	subscription	\N	\N	t	t	3	f	t	cus_V39ypYykBFzGbW	sub_1U3O1B1PBkRXkxBRx0aEHavF	\N	\N	\N	\N	\N	2026-08-16 00:30:53.213809
2	2	free_trial	monthly	trial	2026-08-19 08:22:41.364185	15	percent	3	\N	t	t	3	f	t	\N	\N	2026-08-31 13:05:13.628209	3	2026-08-4	\N	\N	2026-08-16 00:30:53.213809
5	5	free_trial	monthly	trial	2026-09-14 13:23:49.275443	15	subscription	\N	\N	t	t	3	f	t	\N	\N	\N	\N	\N	\N	\N	2026-08-31 13:23:49.275443
6	6	free_trial	monthly	trial	2026-09-14 14:02:55.595004	15	subscription	\N	\N	t	t	3	f	t	\N	\N	\N	\N	\N	\N	\N	2026-08-31 14:02:55.595004
\.


--
-- Data for Name: studio_booking_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_booking_settings (id, studio_id, booking_active, prefill_on_booking, trainer_confirmation_required, repeat_booking_allowed, min_booking_advance_min, booking_window_days, cancellation_deadline_min, widget_accent_color, widget_logo_url, widget_dark_mode, widget_language, reminder_24h, reminder_2h, review_request, miniapp_generated, widget_work_start, widget_work_end, coffee_enabled, coffee_spots, trial_lesson_free) FROM stdin;
3	3	t	t	f	f	120	7	240	#FCAE91	\N	f	ru	t	t	t	f	09:00	21:00	t	\N	f
2	2	t	t	f	f	120	7	240	#FCAE91	\N	f	ru	t	t	t	f	09:00	21:00	t	\N	f
1	1	t	t	f	f	120	7	240	#C96B9E	\N	t	ru	t	t	t	f	09:00	21:00	t	\N	f
\.


--
-- Data for Name: studio_branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_branches (id, studio_id, name, phone, email, address, country, city, photo_url) FROM stdin;
1	1	Студия	+420722274622	smat5302@gmail.com	улица Абонемент	Чехия	Прага	/static/branches/f06e2397d47c475abe290835b01fc3ff.jpg
2	1	Велора	+420722274622	smat5302@gmail.com	ул Украинская	Чехия	Прага	/static/branches/08472a5160eb45a792910615d0b2fd21.jpg
\.


--
-- Data for Name: studio_certificate_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_certificate_configs (id, studio_id, is_enabled, cert_type, expiry_days, denominations, service_id) FROM stdin;
1	2	f	gift	365	\N	\N
3	3	f	gift	365	\N	\N
2	1	t	gift	365	\N	\N
\.


--
-- Data for Name: studio_client_segment_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_client_segment_configs (id, studio_id, new_client_days, active_within_days, vip_min_spent, vip_min_visits) FROM stdin;
\.


--
-- Data for Name: studio_discount_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_discount_configs (id, studio_id, is_enabled, discount_type, discount_value, min_purchase_amount, applies_to_all_services, stackable, visible_in_cabinet) FROM stdin;
1	2	f	percentage	10	\N	t	f	t
3	3	f	percentage	10	\N	t	f	t
2	1	t	percentage	10	3000	t	f	t
\.


--
-- Data for Name: studio_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_events (id, studio_id, title, description, event_type, status, event_date, start_time, duration_min, max_attendees, revenue, trainer_id, color, created_at) FROM stdin;
\.


--
-- Data for Name: studio_feature_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_feature_flags (id, studio_id, flag, is_enabled, updated_at) FROM stdin;
\.


--
-- Data for Name: studio_integrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_integrations (id, studio_id, integration_type, is_connected, config, updated_at) FROM stdin;
1	1	email_sender	t	{"email": "smat5302@gmail.com", "verified": true}	2026-08-05 02:47:30.086377
8	6	notify_state	t	{"bday": "2026-09-01", "weekly": "2026-08-31", "billing": "2026-09-01", "report": "2026-08-31"}	2026-08-31 22:03:35.242874
5	2	notify_state	t	{"bday": "2026-09-01", "weekly": "2026-08-31", "billing": "2026-09-01", "report": "2026-08-31"}	2026-08-31 23:03:35.497278
2	3	notify_state	t	{"bday": "2026-09-01", "billing": "2026-09-01", "report": "2026-08-31", "weekly": "2026-08-31"}	2026-08-31 23:03:35.504864
4	1	notify_state	t	{"bday": "2026-09-01", "weekly": "2026-08-31", "billing": "2026-09-01", "report": "2026-08-31"}	2026-08-31 23:03:35.514247
6	4	notify_state	t	{"bday": "2026-09-01", "weekly": "2026-08-31", "billing": "2026-09-01", "report": "2026-08-31"}	2026-08-31 23:03:35.521225
7	5	notify_state	t	{"bday": "2026-09-01", "weekly": "2026-08-31", "billing": "2026-09-01", "report": "2026-08-31"}	2026-08-31 23:03:35.526485
3	1	tg_notify	t	{"token": "7957635360:AAEe8sp-YfNzRIM6cfN5CiPCzHCr8TtEpew", "bot_username": "ClientToBarberBot"}	2026-08-18 13:28:49.287528
\.


--
-- Data for Name: studio_loyalty_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_loyalty_configs (id, studio_id, is_enabled, program_name, points_exchange_rate, expiry_period) FROM stdin;
1	2	f	Velora Club	100	never
3	3	f	Velora Club	100	never
2	1	t	Velora Club	100	never
\.


--
-- Data for Name: studio_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_members (id, user_id, studio_id, role, department, salary, rate, rate_type, name, last_name, photo_url, status) FROM stdin;
1	1	1	owner	\N	\N	\N	\N	Sad Mat	\N	\N	active
2	2	2	owner	\N	\N	\N	\N	Valeri	\N	\N	active
3	3	3	owner	\N	\N	\N	\N	Andriy Sadovskiy	\N	\N	active
4	4	1	trainer	\N	\N	\N	\N	Кирилл		\N	active
5	5	2	trainer	\N	400	\N	hourly	Тренер Петя	\N	\N	pending
6	6	1	admin	\N	\N	\N	\N	Валерия	\N	\N	active
7	7	4	owner	\N	\N	\N	\N	Sadovskiy Matvii	\N	\N	active
9	9	1	trainer	Тренер по стретчингу	\N	300	hourly	Оля	\N	\N	active
11	11	5	owner	\N	\N	\N	\N	Valeria Mesniankina	\N	\N	active
12	12	6	owner	\N	\N	\N	\N	Matvey	\N	\N	active
\.


--
-- Data for Name: studio_notification_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_notification_settings (id, studio_id, telegram_notifications, instagram_notifications, whatsapp_notifications, email_notifications, sms_notifications, push_notifications, marketing_emails, primary_email, backup_email) FROM stdin;
1	1	t	f	t	t	f	f	t	\N	\N
3	2	t	f	t	t	f	f	t	\N	\N
5	3	t	f	t	t	f	f	t	\N	\N
7	4	t	f	t	t	f	f	t	\N	\N
\.


--
-- Data for Name: studio_promo_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_promo_codes (id, studio_id, code, discount_type, value, valid_until, usage_limit, used_count, is_active, created_at) FROM stdin;
1	1	ЛЕТО26	percent	25	2026-09-01	\N	0	t	2026-08-16 21:33:09.469761
\.


--
-- Data for Name: studio_referral_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_referral_configs (id, studio_id, is_enabled, referrer_bonus, new_client_discount, trigger_condition, bonus_type) FROM stdin;
1	2	f	500	15	first_visit	points
2	1	f	500	15	first_visit	points
3	3	f	500	15	first_visit	points
\.


--
-- Data for Name: studio_reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_reviews (id, studio_id, client_id, author_name, rating, nps_score, text, source, lesson_id, event_id, created_at) FROM stdin;
\.


--
-- Data for Name: studio_subscription_program_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_subscription_program_configs (id, studio_id, is_enabled, allow_freeze, allow_transfer, auto_renewal) FROM stdin;
1	1	f	t	f	f
\.


--
-- Data for Name: studio_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_tasks (id, studio_id, author_id, text, priority, tag, is_done, done_at, created_at, assignee_id) FROM stdin;
\.


--
-- Data for Name: studio_working_hours; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studio_working_hours (id, studio_id, day_of_week, is_open, open_time, close_time) FROM stdin;
1	1	0	t	09:00	21:00
2	1	1	t	09:00	21:00
3	1	2	t	09:00	21:00
4	1	3	t	09:00	21:00
5	1	4	t	09:00	21:00
6	1	5	t	10:00	18:00
7	1	6	f	10:00	18:00
8	2	0	t	09:00	21:00
9	2	1	t	09:00	21:00
10	2	2	t	09:00	17:00
11	2	3	t	09:00	21:00
12	2	4	t	09:00	15:00
13	2	5	t	10:00	18:00
14	2	6	f	10:00	18:00
15	3	0	t	09:00	21:00
16	3	1	t	09:00	10:00
17	3	2	t	09:00	21:00
18	3	3	t	09:00	21:00
19	3	4	t	09:00	21:00
20	3	5	t	10:00	18:00
21	3	6	f	10:00	18:00
22	4	0	t	09:00	21:00
23	4	1	t	09:00	21:00
24	4	2	t	09:00	21:00
25	4	3	t	09:00	21:00
26	4	4	t	09:00	21:00
27	4	5	t	10:00	18:00
28	4	6	t	10:00	18:00
29	5	0	t	09:00	21:00
30	5	1	t	09:00	21:00
31	5	2	t	09:00	21:00
32	5	3	t	09:00	21:00
33	5	4	t	09:00	21:00
34	5	5	t	10:00	18:00
35	5	6	t	10:00	18:00
36	6	0	t	09:00	21:00
37	6	1	t	09:00	21:00
38	6	2	t	09:00	21:00
39	6	3	t	09:00	21:00
40	6	4	t	09:00	21:00
41	6	5	t	10:00	18:00
42	6	6	t	10:00	18:00
\.


--
-- Data for Name: studios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.studios (id, name, phone, business_type, business_subtype, timezone, language, currency, description, email, website, address, logo_url, date_format, first_day_of_week, journal_time_step, country, postal_code, vat_id, company_id, city, tz_iana) FROM stdin;
2	Valeria Studio	+420606281292	fitness	pilates	UTC+1	en	UAH	Мы студия пилатеса в центре Праги.	leramesnjankina@gmail.com	\N	Uzavřena , 649/8	/static/logos/63dd8c596c894b29ae117c25e2fa80f3.jpeg	DD.MM.YYYY	monday	15	\N	\N	\N	\N	\N	\N
3	Andrii	+420774215709	fitness	pilates	UTC+1	ru	CZK	\N	andrii.sadovskiy@gmail.com	\N	Olgy Havlove 2930/35	\N	DD.MM.YYYY	monday	15	\N	\N	\N	\N	\N	\N
1	Велора	+420722274622	fitness	pilates	UTC+1	ru	UAH	\N	\N	\N	\N	/static/logos/09f808874cda4ccdb2fce8e1a76cdd1a.jpg	DD.MM.YYYY	monday	15	DE	13000	\N	\N	\N	\N
4	Велора	+420722274622	fitness	pilates	UTC+1	en	EUR	\N	\N	\N	Бейкер стрит	\N	DD.MM.YYYY	monday	15	\N	\N	\N	\N	\N	\N
5	Forma	+420722274622	fitness	dance	UTC+1	ru	CZK	\N	\N	\N	Da stret	\N	DD.MM.YYYY	monday	15	\N	\N	\N	\N	\N	\N
6	Forma	+420722274327	fitness	stretching	UTC+2	ru	RUB	\N	\N	\N	\N	\N	DD.MM.YYYY	monday	15	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: subscription_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_packages (id, studio_id, config_id, name, class_count, price, per_visit_price, is_active, sort_order, duration_days, service_ids, sold_as_single, sold_as_subscription) FROM stdin;
1	1	1	8 занятий	8	8000	1000	t	0	30	null	t	t
\.


--
-- Data for Name: thread_options; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.thread_options (id, studio_id, thread_id, token, search_version, ordinal, lesson_id, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: trainer_sales_goals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trainer_sales_goals (id, studio_id, user_id, period_start, period_end, target_revenue, target_sessions, actual_revenue, actual_sessions) FROM stdin;
\.


--
-- Data for Name: user_consents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_consents (id, user_id, version, source, ip, user_agent, accepted_at) FROM stdin;
1	4	2026-08-15.1	invite	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-16 17:18:29.537523
2	6	2026-08-15.1	invite	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-16 23:39:24.935533
3	7	2026-08-15.1	google	195.22.55.245	Mozilla/5.0 (iPhone; CPU iPhone OS 18_0_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/433.5.957829776 Mobile/15E148 Safari/604.1	2026-08-17 09:32:49.346342
4	9	2026-08-15.1	invite	195.22.55.245	Mozilla/5.0 (iPhone; CPU iPhone OS 18_0_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/433.5.957829776 Mobile/15E148 Safari/604.1	2026-08-18 15:53:08.42256
5	11	2026-08-21.1	google	109.81.172.253	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15	2026-08-31 13:21:36.935654
6	12	2026-08-21.1	register	109.81.172.253	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15	2026-08-31 14:02:04.835378
\.


--
-- Data for Name: user_notification_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_notification_preferences (id, user_id, event_id, channel_key, is_enabled) FROM stdin;
\.


--
-- Data for Name: user_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_services (user_id, service_id) FROM stdin;
5	1
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, user_id, device, platform, browser, location_city, location_country, last_active, is_current, token_hash, ip_address, user_agent, created_at, revoked_at) FROM stdin;
2	1	Mobile	iOS	Safari	\N	\N	2026-08-05 02:49:08.975415	f	b3f5eaee9dd6683474108f9e0e269371d1355dea06c3d47f20aa987343ed9910	195.22.55.245	Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/22A3354 Safari/604.1	2026-08-05 02:41:10.483051	\N
1	1	Desktop	Windows	Chrome	\N	\N	2026-08-05 02:38:07.721055	f	d69627e52b832a30701cc031590f07d7f5fe61daa5471c69ae843c7d578220d6	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-08-05 02:37:00.611634	2026-08-05 02:41:10.476532
11	4	Desktop	Windows	Chrome	\N	\N	2026-08-16 23:35:11.35521	f	42c09e74b7b4b3be44a9951e0ff7ead3a7efb1a03dc7f07c600bf9b298f176ea	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-16 23:34:56.169069	\N
16	7	Mobile	iOS	Safari	\N	\N	2026-08-17 09:33:44.612193	f	292aa4d5db0253c82616b36ed7e994c301897dc2332177674de39a500650563c	195.22.55.245	Mozilla/5.0 (iPhone; CPU iPhone OS 18_0_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/433.5.957829776 Mobile/15E148 Safari/604.1	2026-08-17 09:32:49.603784	\N
7	1	Desktop	Windows	Chrome	\N	\N	2026-08-16 17:17:47.389792	f	05b8c52e4817cabece733b5bc8bdb57e20b1fc01f7cca3e30e2add8b85abec64	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-11 13:11:37.039646	\N
4	1	Mobile	iOS	Safari	\N	\N	2026-08-06 19:29:54.760405	f	f2c2532a8e19dbe07fbcc3538ea290c8975f3a386254f2eeba1f4f135b0bdf72	178.133.41.83	Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1	2026-08-05 14:40:45.160823	\N
14	4	Desktop	Windows	Chrome	\N	\N	2026-08-16 23:40:16.186531	f	12e3e3c95c28e5ed87eedf02633b975634aea84591527071c8d80e07eaca7d6f	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-16 23:39:51.860332	\N
20	6	Desktop	Windows	Chrome	\N	\N	2026-08-28 11:31:06.1636	f	955e5eeaaf7b4da49984ee81c1231c6221bb5128e21d2d1c33d1ff770f8ea09c	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-25 22:43:07.060884	2026-08-28 11:31:06.167637
5	3	Desktop	Windows	Edge	\N	\N	2026-08-05 22:55:40.581656	f	a097ab021cd0ed410ca34b6d28421ca85214450d075dcacc8ef24ecd9cedf38d	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0	2026-08-05 22:53:48.20398	\N
23	11	Desktop	macOS	Safari	\N	\N	2026-08-31 13:23:45.530074	f	6eb1ffb6744cb1460125a7d435dd794749516583a5dd599e6dd07fe9d1d0ce97	109.81.172.253	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15	2026-08-31 13:21:37.207501	\N
3	1	Desktop	Windows	Chrome	\N	\N	2026-08-11 13:10:55.103127	f	cc8fb2f144f4284eb7f5d63ba85d41e914c7c633fc718e244729ef34f7fb67a6	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-08-05 12:08:28.643572	\N
9	1	Desktop	Windows	Chrome	\N	\N	2026-08-16 23:34:47.898609	f	efefe3107c678af4eceb5cfa4d5292f37aac566535fe6204ad5595e41aca3463	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-16 17:19:24.640143	\N
12	1	Desktop	Windows	Chrome	\N	\N	2026-08-16 23:39:12.593647	f	de8920093ef1938e7344b6ed32e9f7eaafc49169c09b92d1b4d655a9ff93dd79	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-16 23:35:17.424515	\N
17	9	Mobile	iOS	Safari	\N	\N	2026-08-18 15:54:25.077453	f	2ea7a7752ccf838a8a3c99b9b1b4cc379e44aba33c3545b1a01b99637f26808d	195.22.55.245	Mozilla/5.0 (iPhone; CPU iPhone OS 18_0_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/433.5.957829776 Mobile/15E148 Safari/604.1	2026-08-18 15:53:08.679905	2026-08-18 15:54:25.081932
8	4	Desktop	Windows	Chrome	\N	\N	2026-08-16 17:19:17.570811	f	ce89344aa4b95abff9d8aa277d6f7e905987785920777f27016a7280f83c3855	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-16 17:18:29.790706	\N
18	1	Mobile	iOS	Safari	\N	\N	2026-08-18 16:12:12.571483	f	3b324ea8bc067acc36131f2e4c7f69204ee2dc8fd9e618ddcab5e97c9ecc1ab9	195.22.55.245	Mozilla/5.0 (iPhone; CPU iPhone OS 18_0_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/433.5.957829776 Mobile/15E148 Safari/604.1	2026-08-18 15:54:31.519652	\N
21	1	Desktop	Windows	Chrome	\N	\N	2026-08-28 11:38:57.083371	f	f0c9d0c911f3a0c7efd99ec94216ce60c1f626896f559de7a181dd86e25ce49b	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-28 11:38:56.672728	\N
24	2	Desktop	macOS	Safari	\N	\N	2026-08-31 13:26:50.125438	f	58ba0f5ad02ed5eea3c97acd2eb2f961ad317915157f95460fa8cf1f8ead8781	109.81.172.253	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15	2026-08-31 13:24:46.923654	2026-08-31 13:26:50.12874
25	12	Desktop	macOS	Safari	\N	\N	2026-08-31 14:04:26.327574	f	6bc4791ce44c6d4463f202774f1393214057c1f089e3bc7a0a989485775e5d63	109.81.172.253	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15	2026-08-31 14:04:15.007881	2026-08-31 14:04:26.332732
26	2	Desktop	macOS	Safari	\N	\N	2026-08-31 14:36:44.589059	f	0b390a84aef8eaa9a3135ae21d706c62d71233b2950fc10a4798b3f230f5c76d	109.81.172.253	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15	2026-08-31 14:04:31.455652	\N
22	2	Desktop	macOS	Safari	\N	\N	2026-08-31 13:21:14.339881	f	6db6d829dc9d327d56447b3a3b585f208c3e9ee94fe0c7faea47459978ed978d	109.81.172.253	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15	2026-08-31 13:04:08.30111	2026-08-31 13:21:14.343399
10	2	Desktop	macOS	Safari	\N	\N	2026-08-19 06:47:20.242334	f	c4d202a6bbd6b10e09fc41414b42a3ccdfdb09ec91c1b4c69ad958efffb00a65	37.203.18.136	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15	2026-08-16 22:07:38.702552	\N
27	1	Desktop	Windows	Chrome	\N	\N	2026-09-01 00:24:23.501232	f	1741bdc898d8647dd2d30a4316e8d5cea673295b49e25856d87db98e77639af6	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-31 19:14:02.64939	2026-09-01 00:24:23.504701
6	3	Mobile	iOS	Safari	\N	\N	2026-08-06 12:10:43.675543	f	f9b913b0f28d761f5d0eecf79feacf0683d311ec244574333cc480a2138ee9c5	89.209.84.114	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7 Mobile/15E148 Safari/604.1	2026-08-06 12:07:50.135688	\N
15	1	Desktop	Windows	Chrome	\N	\N	2026-08-20 20:58:56.262089	f	ecf30125226173e4ce1a7b499e776b337a7065358fde00c16a0b5e9394f43872	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-16 23:40:22.937357	\N
19	1	Mobile	iOS	Safari	\N	\N	2026-08-24 21:59:45.499545	f	0eabc3cacd1f3ed75b5c27c11eb6304a84d5176cee40a1ab377d9b2b1c908df0	178.133.41.212	Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1	2026-08-23 12:48:59.012492	\N
13	6	Desktop	Windows	Chrome	\N	\N	2026-08-16 23:39:44.166552	f	6c2ea9707fc22de67d6fda0ebff880d98c3cd72ac24ad21c69f6a20e50089c85	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-08-16 23:39:25.185178	\N
28	1	Desktop	Windows	Chrome	\N	\N	2026-09-01 00:43:20.154833	f	dc199139cadbc29662562bf7bc80365db9a532a6ff5402d19eef8b30e0c62d18	195.22.55.245	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	2026-09-01 00:24:29.6431	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, hashed_password, name, phone, is_verified, verification_code, is_onboarded, last_name, photo_url, avg_rating, two_fa_enabled, theme, accent_color, account_label, avatar_gradient, primary_user_id, last_online_at, tg_id, otp_code_hash, otp_action, otp_expires_at, otp_attempts, ig_id, last_studio_id, language, billing_country, billing_line1, billing_line2, billing_postal_code, billing_city, billing_vat_id, billing_vat_verified) FROM stdin;
10	sadovmat1@gmail.com	$2b$12$tJnZd34HY8HjqMuLVXohPOuP5mW33AEO25IsvroxgEfwNEU1.NuNi	Вика	\N	f	\N	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
9	lvlcartoon8@gmail.com	$2b$12$j0pio9F92c6k1dKeI8EAXOdbhCx7fRDLuKj4WcmDE27gwyTM6hQmW	Оля	+420722274621	t	\N	t	\N	\N	\N	f	dark	\N	\N	\N	\N	2026-08-18	\N	\N	\N	\N	0	\N	1	\N	\N	\N	\N	\N	\N	\N	f
11	mesniankinavi@gmail.com	$2b$12$FlZ7GUy6JhiOMo9yyAQ5LuWUbh/canlTPRQpbtUXskQIGIBXugyZu	Valeria Mesniankina	+420722274623	t	\N	t	\N	\N	\N	f	light	\N	\N	\N	\N	2026-08-31	\N	\N	\N	\N	0	\N	5	\N	\N	\N	\N	\N	\N	\N	f
6	sadomat31@gmail.com	$2b$12$N3WIRtkza.snn9bimrwWf.FxX81x4G8/..UMbsLqzBj.qoBHwv3dG	Валерия	+420722274620	t	\N	t	\N	\N	\N	f	dark	\N	\N	\N	\N	2026-08-28	\N	\N	\N	\N	0	\N	1	\N	\N	\N	\N	\N	\N	\N	f
12	sweetgame.2023@gmail.com	$2b$12$DAfIH34q6BbFp.aKB7BB4OmZlKrr7ss6N0adH1uSHpBfTQenix3tK	Matvey	+420722432547	t	\N	t	\N	\N	\N	f	\N	\N	\N	\N	\N	2026-08-31	\N	\N	\N	\N	1	\N	6	\N	\N	\N	\N	\N	\N	\N	f
2	leramesnjankina@gmail.com	$2b$12$g7LfxtiarhOC994aKZLfxumznUepeF.P3mpXqTOUE9/Ov00bEOUi6	Valeri	+420606281292	t	\N	t	\N	\N	\N	f	light	\N	\N	\N	\N	2026-08-31	\N	\N	\N	\N	0	\N	2	ru	CZ	Olgy Havlove	\N	11000	Prague	\N	f
4	cartoonlvl2@gmail.com	$2b$12$BRgXNmzqm4u9T5eCA3AZcegfeq8dkbOPjG3NIiWNam4vcT1j4X5hW	Кирилл	+420507509240	t	\N	t	\N	\N	\N	f	dark	\N	\N	\N	\N	2026-08-16	\N	\N	\N	\N	0	\N	1	\N	\N	\N	\N	\N	\N	\N	f
3	andrii.sadovskiy@gmail.com	$2b$12$5bc55epD9uY.oZ9SXC28lOq9Qb2PCk2p5dpKMvKE/QaZu1iI6YTiS	Andriy Sadovskiy	+420774215709	t	\N	t	\N	\N	\N	f	light	\N	\N	\N	\N	2026-08-06	\N	\N	\N	\N	0	\N	3	\N	\N	\N	\N	\N	\N	\N	f
5	valeriatutor2025@gmail.com	$2b$12$y5nzow978s.NaA3Qf0nEr.oFePdq.jvHc7O/upcvLP3iTfF7dLg6y	Тренер Петя	\N	f	\N	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
7	sadovskiymatviy64@gmail.com	$2b$12$GgVsp5NpZXJ.pPPUmLR5b.cIUCXxXEKCPsXT9zNhRr7shOBdW9KxS	Sadovskiy Matvii	+380507509240	t	\N	t	\N	\N	\N	f	dark	\N	\N	\N	\N	2026-08-18	\N	\N	\N	\N	0	\N	4	ru	\N	\N	\N	\N	\N	\N	f
8	triboys@gmail.com	$2b$12$61aEjY/nlOjDZLUNn0ckE.MrJytu4R62ltrkfbe52C2AuuHszDt9C	Саша	\N	f	\N	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
1	smat5302@gmail.com	$2b$12$r0HkBrj6LLpXlANNonokv.zawM3Z6oSfR3eQ9A37yFXfkUafJE2km	Sad Mat	+420722274622	t	\N	t	\N	\N	\N	f	dark	\N	\N	\N	\N	2026-09-01	\N	\N	\N	\N	1	\N	1	\N	\N	\N	\N	\N	\N	\N	f
\.


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounts_id_seq', 1, true);


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 8, true);


--
-- Name: agent_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_jobs_id_seq', 1, false);


--
-- Name: ai_chat_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_chat_messages_id_seq', 112, true);


--
-- Name: ai_chat_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_chat_sessions_id_seq', 21, true);


--
-- Name: ai_studio_facts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_studio_facts_id_seq', 1, false);


--
-- Name: ai_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_usage_id_seq', 117, true);


--
-- Name: billing_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.billing_invoices_id_seq', 1, true);


--
-- Name: booking_channel_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.booking_channel_configs_id_seq', 1, true);


--
-- Name: branch_working_hours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.branch_working_hours_id_seq', 21, true);


--
-- Name: channel_threads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.channel_threads_id_seq', 1, false);


--
-- Name: client_email_otp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.client_email_otp_id_seq', 3, true);


--
-- Name: client_loyalty_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.client_loyalty_cards_id_seq', 2, true);


--
-- Name: client_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.client_notes_id_seq', 1, false);


--
-- Name: client_offers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.client_offers_id_seq', 1, false);


--
-- Name: client_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.client_payments_id_seq', 2, true);


--
-- Name: client_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.client_subscriptions_id_seq', 2, true);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clients_id_seq', 2, true);


--
-- Name: counterparties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.counterparties_id_seq', 1, false);


--
-- Name: daily_metric_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_metric_snapshots_id_seq', 1, false);


--
-- Name: deposit_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deposit_transactions_id_seq', 1, false);


--
-- Name: event_attendees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.event_attendees_id_seq', 1, false);


--
-- Name: fin_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fin_documents_id_seq', 1, false);


--
-- Name: financial_goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.financial_goals_id_seq', 1, false);


--
-- Name: fx_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fx_rates_id_seq', 1494, true);


--
-- Name: gift_certificates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gift_certificates_id_seq', 1, false);


--
-- Name: halls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.halls_id_seq', 1, true);


--
-- Name: inbound_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inbound_events_id_seq', 1, false);


--
-- Name: lessons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lessons_id_seq', 208, true);


--
-- Name: loyalty_levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.loyalty_levels_id_seq', 9, true);


--
-- Name: loyalty_point_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.loyalty_point_transactions_id_seq', 1, true);


--
-- Name: loyalty_scenarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.loyalty_scenarios_id_seq', 1, false);


--
-- Name: notification_event_toggles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_event_toggles_id_seq', 1, true);


--
-- Name: notification_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_logs_id_seq', 123, true);


--
-- Name: offline_transaction_fees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.offline_transaction_fees_id_seq', 1, false);


--
-- Name: online_channel_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.online_channel_metrics_id_seq', 1, false);


--
-- Name: online_channels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.online_channels_id_seq', 2, true);


--
-- Name: operations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.operations_id_seq', 3, true);


--
-- Name: outbound_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.outbound_messages_id_seq', 1, false);


--
-- Name: payment_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_cards_id_seq', 1, false);


--
-- Name: payment_method_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_method_configs_id_seq', 1, false);


--
-- Name: platform_revenue_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.platform_revenue_ledger_id_seq', 1, false);


--
-- Name: product_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_sales_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: referral_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.referral_records_id_seq', 1, false);


--
-- Name: reservations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reservations_id_seq', 4, true);


--
-- Name: salary_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_payments_id_seq', 1, true);


--
-- Name: scenario_fires_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.scenario_fires_id_seq', 1, false);


--
-- Name: service_schedule_slots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_schedule_slots_id_seq', 1, false);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.services_id_seq', 3, true);


--
-- Name: staff_day_overrides_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staff_day_overrides_id_seq', 29, true);


--
-- Name: staff_working_hours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staff_working_hours_id_seq', 19, true);


--
-- Name: stripe_checkouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stripe_checkouts_id_seq', 1, false);


--
-- Name: studio_ai_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_ai_settings_id_seq', 3, true);


--
-- Name: studio_billing_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_billing_plans_id_seq', 6, true);


--
-- Name: studio_booking_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_booking_settings_id_seq', 3, true);


--
-- Name: studio_branches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_branches_id_seq', 2, true);


--
-- Name: studio_certificate_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_certificate_configs_id_seq', 3, true);


--
-- Name: studio_client_segment_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_client_segment_configs_id_seq', 1, false);


--
-- Name: studio_discount_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_discount_configs_id_seq', 3, true);


--
-- Name: studio_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_events_id_seq', 1, false);


--
-- Name: studio_feature_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_feature_flags_id_seq', 1, false);


--
-- Name: studio_integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_integrations_id_seq', 8, true);


--
-- Name: studio_loyalty_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_loyalty_configs_id_seq', 3, true);


--
-- Name: studio_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_members_id_seq', 12, true);


--
-- Name: studio_notification_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_notification_settings_id_seq', 7, true);


--
-- Name: studio_promo_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_promo_codes_id_seq', 1, true);


--
-- Name: studio_referral_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_referral_configs_id_seq', 3, true);


--
-- Name: studio_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_reviews_id_seq', 1, false);


--
-- Name: studio_subscription_program_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_subscription_program_configs_id_seq', 1, true);


--
-- Name: studio_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_tasks_id_seq', 1, false);


--
-- Name: studio_working_hours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studio_working_hours_id_seq', 42, true);


--
-- Name: studios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.studios_id_seq', 6, true);


--
-- Name: subscription_packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscription_packages_id_seq', 1, true);


--
-- Name: thread_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.thread_options_id_seq', 1, false);


--
-- Name: trainer_sales_goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trainer_sales_goals_id_seq', 1, false);


--
-- Name: user_consents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_consents_id_seq', 6, true);


--
-- Name: user_notification_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_notification_preferences_id_seq', 1, false);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 28, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 12, true);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: agent_jobs agent_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_jobs
    ADD CONSTRAINT agent_jobs_pkey PRIMARY KEY (id);


--
-- Name: ai_chat_messages ai_chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_pkey PRIMARY KEY (id);


--
-- Name: ai_chat_sessions ai_chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: ai_studio_facts ai_studio_facts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_studio_facts
    ADD CONSTRAINT ai_studio_facts_pkey PRIMARY KEY (id);


--
-- Name: ai_usage ai_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage
    ADD CONSTRAINT ai_usage_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: billing_invoices billing_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_invoices
    ADD CONSTRAINT billing_invoices_pkey PRIMARY KEY (id);


--
-- Name: booking_channel_configs booking_channel_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_channel_configs
    ADD CONSTRAINT booking_channel_configs_pkey PRIMARY KEY (id);


--
-- Name: branch_working_hours branch_working_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branch_working_hours
    ADD CONSTRAINT branch_working_hours_pkey PRIMARY KEY (id);


--
-- Name: channel_threads channel_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_threads
    ADD CONSTRAINT channel_threads_pkey PRIMARY KEY (id);


--
-- Name: client_email_otp client_email_otp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_email_otp
    ADD CONSTRAINT client_email_otp_pkey PRIMARY KEY (id);


--
-- Name: client_loyalty_cards client_loyalty_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_loyalty_cards
    ADD CONSTRAINT client_loyalty_cards_pkey PRIMARY KEY (id);


--
-- Name: client_notes client_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_notes
    ADD CONSTRAINT client_notes_pkey PRIMARY KEY (id);


--
-- Name: client_offers client_offers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_offers
    ADD CONSTRAINT client_offers_pkey PRIMARY KEY (id);


--
-- Name: client_payments client_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_payments
    ADD CONSTRAINT client_payments_pkey PRIMARY KEY (id);


--
-- Name: client_subscriptions client_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_subscriptions
    ADD CONSTRAINT client_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: counterparties counterparties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_pkey PRIMARY KEY (id);


--
-- Name: daily_metric_snapshots daily_metric_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_metric_snapshots
    ADD CONSTRAINT daily_metric_snapshots_pkey PRIMARY KEY (id);


--
-- Name: deposit_transactions deposit_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deposit_transactions
    ADD CONSTRAINT deposit_transactions_pkey PRIMARY KEY (id);


--
-- Name: event_attendees event_attendees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendees
    ADD CONSTRAINT event_attendees_pkey PRIMARY KEY (id);


--
-- Name: fin_documents fin_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fin_documents
    ADD CONSTRAINT fin_documents_pkey PRIMARY KEY (id);


--
-- Name: financial_goals financial_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_goals
    ADD CONSTRAINT financial_goals_pkey PRIMARY KEY (id);


--
-- Name: fx_rates fx_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fx_rates
    ADD CONSTRAINT fx_rates_pkey PRIMARY KEY (id);


--
-- Name: gift_certificates gift_certificates_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_certificates
    ADD CONSTRAINT gift_certificates_code_key UNIQUE (code);


--
-- Name: gift_certificates gift_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_certificates
    ADD CONSTRAINT gift_certificates_pkey PRIMARY KEY (id);


--
-- Name: halls halls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.halls
    ADD CONSTRAINT halls_pkey PRIMARY KEY (id);


--
-- Name: inbound_events inbound_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inbound_events
    ADD CONSTRAINT inbound_events_pkey PRIMARY KEY (id);


--
-- Name: lessons lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_pkey PRIMARY KEY (id);


--
-- Name: loyalty_levels loyalty_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_levels
    ADD CONSTRAINT loyalty_levels_pkey PRIMARY KEY (id);


--
-- Name: loyalty_point_transactions loyalty_point_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_point_transactions
    ADD CONSTRAINT loyalty_point_transactions_pkey PRIMARY KEY (id);


--
-- Name: loyalty_scenarios loyalty_scenarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_scenarios
    ADD CONSTRAINT loyalty_scenarios_pkey PRIMARY KEY (id);


--
-- Name: notification_event_toggles notification_event_toggles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_event_toggles
    ADD CONSTRAINT notification_event_toggles_pkey PRIMARY KEY (id);


--
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- Name: offline_transaction_fees offline_transaction_fees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offline_transaction_fees
    ADD CONSTRAINT offline_transaction_fees_pkey PRIMARY KEY (id);


--
-- Name: online_channel_metrics online_channel_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_channel_metrics
    ADD CONSTRAINT online_channel_metrics_pkey PRIMARY KEY (id);


--
-- Name: online_channels online_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_channels
    ADD CONSTRAINT online_channels_pkey PRIMARY KEY (id);


--
-- Name: operations operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_pkey PRIMARY KEY (id);


--
-- Name: outbound_messages outbound_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbound_messages
    ADD CONSTRAINT outbound_messages_pkey PRIMARY KEY (id);


--
-- Name: payment_cards payment_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_cards
    ADD CONSTRAINT payment_cards_pkey PRIMARY KEY (id);


--
-- Name: payment_method_configs payment_method_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_method_configs
    ADD CONSTRAINT payment_method_configs_pkey PRIMARY KEY (id);


--
-- Name: platform_revenue_ledger platform_revenue_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_revenue_ledger
    ADD CONSTRAINT platform_revenue_ledger_pkey PRIMARY KEY (id);


--
-- Name: product_sales product_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_sales
    ADD CONSTRAINT product_sales_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: referral_records referral_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_records
    ADD CONSTRAINT referral_records_pkey PRIMARY KEY (id);


--
-- Name: referral_records referral_records_referred_client_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_records
    ADD CONSTRAINT referral_records_referred_client_id_key UNIQUE (referred_client_id);


--
-- Name: reservations reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_pkey PRIMARY KEY (id);


--
-- Name: salary_payments salary_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_payments
    ADD CONSTRAINT salary_payments_pkey PRIMARY KEY (id);


--
-- Name: scenario_fires scenario_fires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scenario_fires
    ADD CONSTRAINT scenario_fires_pkey PRIMARY KEY (id);


--
-- Name: service_schedule_slots service_schedule_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_schedule_slots
    ADD CONSTRAINT service_schedule_slots_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: staff_day_overrides staff_day_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_day_overrides
    ADD CONSTRAINT staff_day_overrides_pkey PRIMARY KEY (id);


--
-- Name: staff_working_hours staff_working_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_working_hours
    ADD CONSTRAINT staff_working_hours_pkey PRIMARY KEY (id);


--
-- Name: stripe_checkouts stripe_checkouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stripe_checkouts
    ADD CONSTRAINT stripe_checkouts_pkey PRIMARY KEY (id);


--
-- Name: studio_ai_settings studio_ai_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_ai_settings
    ADD CONSTRAINT studio_ai_settings_pkey PRIMARY KEY (id);


--
-- Name: studio_billing_plans studio_billing_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_billing_plans
    ADD CONSTRAINT studio_billing_plans_pkey PRIMARY KEY (id);


--
-- Name: studio_booking_settings studio_booking_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_booking_settings
    ADD CONSTRAINT studio_booking_settings_pkey PRIMARY KEY (id);


--
-- Name: studio_branches studio_branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_branches
    ADD CONSTRAINT studio_branches_pkey PRIMARY KEY (id);


--
-- Name: studio_certificate_configs studio_certificate_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_certificate_configs
    ADD CONSTRAINT studio_certificate_configs_pkey PRIMARY KEY (id);


--
-- Name: studio_client_segment_configs studio_client_segment_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_client_segment_configs
    ADD CONSTRAINT studio_client_segment_configs_pkey PRIMARY KEY (id);


--
-- Name: studio_discount_configs studio_discount_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_discount_configs
    ADD CONSTRAINT studio_discount_configs_pkey PRIMARY KEY (id);


--
-- Name: studio_events studio_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_events
    ADD CONSTRAINT studio_events_pkey PRIMARY KEY (id);


--
-- Name: studio_feature_flags studio_feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_feature_flags
    ADD CONSTRAINT studio_feature_flags_pkey PRIMARY KEY (id);


--
-- Name: studio_integrations studio_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_integrations
    ADD CONSTRAINT studio_integrations_pkey PRIMARY KEY (id);


--
-- Name: studio_loyalty_configs studio_loyalty_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_loyalty_configs
    ADD CONSTRAINT studio_loyalty_configs_pkey PRIMARY KEY (id);


--
-- Name: studio_members studio_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_members
    ADD CONSTRAINT studio_members_pkey PRIMARY KEY (id);


--
-- Name: studio_notification_settings studio_notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_notification_settings
    ADD CONSTRAINT studio_notification_settings_pkey PRIMARY KEY (id);


--
-- Name: studio_promo_codes studio_promo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_promo_codes
    ADD CONSTRAINT studio_promo_codes_pkey PRIMARY KEY (id);


--
-- Name: studio_referral_configs studio_referral_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_referral_configs
    ADD CONSTRAINT studio_referral_configs_pkey PRIMARY KEY (id);


--
-- Name: studio_reviews studio_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_reviews
    ADD CONSTRAINT studio_reviews_pkey PRIMARY KEY (id);


--
-- Name: studio_subscription_program_configs studio_subscription_program_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_subscription_program_configs
    ADD CONSTRAINT studio_subscription_program_configs_pkey PRIMARY KEY (id);


--
-- Name: studio_tasks studio_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_tasks
    ADD CONSTRAINT studio_tasks_pkey PRIMARY KEY (id);


--
-- Name: studio_working_hours studio_working_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_working_hours
    ADD CONSTRAINT studio_working_hours_pkey PRIMARY KEY (id);


--
-- Name: studios studios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studios
    ADD CONSTRAINT studios_pkey PRIMARY KEY (id);


--
-- Name: subscription_packages subscription_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_packages
    ADD CONSTRAINT subscription_packages_pkey PRIMARY KEY (id);


--
-- Name: thread_options thread_options_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_options
    ADD CONSTRAINT thread_options_pkey PRIMARY KEY (id);


--
-- Name: thread_options thread_options_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_options
    ADD CONSTRAINT thread_options_token_key UNIQUE (token);


--
-- Name: trainer_sales_goals trainer_sales_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer_sales_goals
    ADD CONSTRAINT trainer_sales_goals_pkey PRIMARY KEY (id);


--
-- Name: agent_jobs uq_agent_job_event; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_jobs
    ADD CONSTRAINT uq_agent_job_event UNIQUE (inbound_event_id);


--
-- Name: ai_chat_messages uq_ai_chat_messages_action_jti; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT uq_ai_chat_messages_action_jti UNIQUE (action_jti);


--
-- Name: billing_invoices uq_billing_invoice_period; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_invoices
    ADD CONSTRAINT uq_billing_invoice_period UNIQUE (studio_id, kind, period);


--
-- Name: booking_channel_configs uq_booking_channel; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_channel_configs
    ADD CONSTRAINT uq_booking_channel UNIQUE (studio_id, channel_type);


--
-- Name: branch_working_hours uq_branch_day; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branch_working_hours
    ADD CONSTRAINT uq_branch_day UNIQUE (branch_id, day_of_week);


--
-- Name: online_channel_metrics uq_channel_metric; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_channel_metrics
    ADD CONSTRAINT uq_channel_metric UNIQUE (channel_id, period_type, period_date);


--
-- Name: channel_threads uq_channel_thread; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_threads
    ADD CONSTRAINT uq_channel_thread UNIQUE (studio_id, channel, sender_ref);


--
-- Name: client_email_otp uq_client_email_otp_studio_email; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_email_otp
    ADD CONSTRAINT uq_client_email_otp_studio_email UNIQUE (studio_id, email);


--
-- Name: daily_metric_snapshots uq_daily_snapshot_studio_date; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_metric_snapshots
    ADD CONSTRAINT uq_daily_snapshot_studio_date UNIQUE (studio_id, date);


--
-- Name: event_attendees uq_event_client; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendees
    ADD CONSTRAINT uq_event_client UNIQUE (event_id, client_id);


--
-- Name: fx_rates uq_fx_rate_base_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fx_rates
    ADD CONSTRAINT uq_fx_rate_base_code UNIQUE (base, code);


--
-- Name: inbound_events uq_inbound_provider_event; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inbound_events
    ADD CONSTRAINT uq_inbound_provider_event UNIQUE (provider, provider_event_id);


--
-- Name: notification_event_toggles uq_notif_toggle; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_event_toggles
    ADD CONSTRAINT uq_notif_toggle UNIQUE (studio_id, role, event_id, channel_key);


--
-- Name: outbound_messages uq_outbound_dedup; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbound_messages
    ADD CONSTRAINT uq_outbound_dedup UNIQUE (dedup_key);


--
-- Name: studio_promo_codes uq_promo_code_per_studio; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_promo_codes
    ADD CONSTRAINT uq_promo_code_per_studio UNIQUE (studio_id, code);


--
-- Name: scenario_fires uq_scenario_fire; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scenario_fires
    ADD CONSTRAINT uq_scenario_fire UNIQUE (scenario_id, client_id, dedup_key);


--
-- Name: staff_day_overrides uq_staff_studio_date; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_day_overrides
    ADD CONSTRAINT uq_staff_studio_date UNIQUE (user_id, studio_id, day);


--
-- Name: staff_working_hours uq_staff_studio_day; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_working_hours
    ADD CONSTRAINT uq_staff_studio_day UNIQUE (user_id, studio_id, day_of_week);


--
-- Name: online_channels uq_studio_channel; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_channels
    ADD CONSTRAINT uq_studio_channel UNIQUE (studio_id, channel_type);


--
-- Name: studio_working_hours uq_studio_day; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_working_hours
    ADD CONSTRAINT uq_studio_day UNIQUE (studio_id, day_of_week);


--
-- Name: studio_feature_flags uq_studio_feature_flag; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_feature_flags
    ADD CONSTRAINT uq_studio_feature_flag UNIQUE (studio_id, flag);


--
-- Name: studio_integrations uq_studio_integration; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_integrations
    ADD CONSTRAINT uq_studio_integration UNIQUE (studio_id, integration_type);


--
-- Name: studio_members uq_studio_member; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_members
    ADD CONSTRAINT uq_studio_member UNIQUE (user_id, studio_id);


--
-- Name: payment_method_configs uq_studio_pay_method; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_method_configs
    ADD CONSTRAINT uq_studio_pay_method UNIQUE (studio_id, method_type);


--
-- Name: trainer_sales_goals uq_trainer_goal_period; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer_sales_goals
    ADD CONSTRAINT uq_trainer_goal_period UNIQUE (user_id, period_start, period_end);


--
-- Name: user_notification_preferences uq_user_notif_pref; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT uq_user_notif_pref UNIQUE (user_id, event_id, channel_key);


--
-- Name: user_consents user_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_consents
    ADD CONSTRAINT user_consents_pkey PRIMARY KEY (id);


--
-- Name: user_notification_preferences user_notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_services user_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_services
    ADD CONSTRAINT user_services_pkey PRIMARY KEY (user_id, service_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_accounts_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_accounts_id ON public.accounts USING btree (id);


--
-- Name: ix_accounts_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_accounts_studio_id ON public.accounts USING btree (studio_id);


--
-- Name: ix_activity_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_logs_created_at ON public.activity_logs USING btree (created_at);


--
-- Name: ix_activity_logs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_logs_id ON public.activity_logs USING btree (id);


--
-- Name: ix_activity_logs_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_logs_studio_id ON public.activity_logs USING btree (studio_id);


--
-- Name: ix_agent_jobs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_jobs_id ON public.agent_jobs USING btree (id);


--
-- Name: ix_agent_jobs_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_jobs_open ON public.agent_jobs USING btree (claimed_at) WHERE ((status)::text = ANY ((ARRAY['pending'::character varying, 'running'::character varying])::text[]));


--
-- Name: ix_agent_jobs_run_after; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_jobs_run_after ON public.agent_jobs USING btree (run_after);


--
-- Name: ix_ai_chat_messages_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_chat_messages_id ON public.ai_chat_messages USING btree (id);


--
-- Name: ix_ai_chat_messages_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_chat_messages_request_id ON public.ai_chat_messages USING btree (request_id);


--
-- Name: ix_ai_chat_messages_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_chat_messages_session_id ON public.ai_chat_messages USING btree (session_id);


--
-- Name: ix_ai_chat_sessions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_chat_sessions_id ON public.ai_chat_sessions USING btree (id);


--
-- Name: ix_ai_chat_sessions_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_chat_sessions_studio_id ON public.ai_chat_sessions USING btree (studio_id);


--
-- Name: ix_ai_chat_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_chat_sessions_user_id ON public.ai_chat_sessions USING btree (user_id);


--
-- Name: ix_ai_studio_facts_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_studio_facts_id ON public.ai_studio_facts USING btree (id);


--
-- Name: ix_ai_studio_facts_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_studio_facts_studio_id ON public.ai_studio_facts USING btree (studio_id);


--
-- Name: ix_ai_usage_billable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_billable ON public.ai_usage USING btree (billable);


--
-- Name: ix_ai_usage_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_created_at ON public.ai_usage USING btree (created_at);


--
-- Name: ix_ai_usage_escalation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_escalation ON public.ai_usage USING btree (escalation_reason) WHERE (escalation_reason IS NOT NULL);


--
-- Name: ix_ai_usage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_id ON public.ai_usage USING btree (id);


--
-- Name: ix_ai_usage_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_request_id ON public.ai_usage USING btree (request_id);


--
-- Name: ix_ai_usage_studio_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_studio_created ON public.ai_usage USING btree (studio_id, created_at);


--
-- Name: ix_ai_usage_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_usage_studio_id ON public.ai_usage USING btree (studio_id);


--
-- Name: ix_billing_invoices_due_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_billing_invoices_due_at ON public.billing_invoices USING btree (due_at);


--
-- Name: ix_billing_invoices_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_billing_invoices_id ON public.billing_invoices USING btree (id);


--
-- Name: ix_billing_invoices_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_billing_invoices_kind ON public.billing_invoices USING btree (kind);


--
-- Name: ix_billing_invoices_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_billing_invoices_order_id ON public.billing_invoices USING btree (order_id);


--
-- Name: ix_billing_invoices_stripe_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_billing_invoices_stripe_invoice_id ON public.billing_invoices USING btree (stripe_invoice_id);


--
-- Name: ix_billing_invoices_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_billing_invoices_studio_id ON public.billing_invoices USING btree (studio_id);


--
-- Name: ix_booking_channel_configs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_booking_channel_configs_id ON public.booking_channel_configs USING btree (id);


--
-- Name: ix_booking_channel_configs_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_booking_channel_configs_studio_id ON public.booking_channel_configs USING btree (studio_id);


--
-- Name: ix_branch_working_hours_branch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_branch_working_hours_branch_id ON public.branch_working_hours USING btree (branch_id);


--
-- Name: ix_branch_working_hours_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_branch_working_hours_id ON public.branch_working_hours USING btree (id);


--
-- Name: ix_channel_threads_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_threads_id ON public.channel_threads USING btree (id);


--
-- Name: ix_channel_threads_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_threads_studio_id ON public.channel_threads USING btree (studio_id);


--
-- Name: ix_client_email_otp_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_email_otp_id ON public.client_email_otp USING btree (id);


--
-- Name: ix_client_email_otp_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_email_otp_studio_id ON public.client_email_otp USING btree (studio_id);


--
-- Name: ix_client_loyalty_cards_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_client_loyalty_cards_client_id ON public.client_loyalty_cards USING btree (client_id);


--
-- Name: ix_client_loyalty_cards_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_loyalty_cards_id ON public.client_loyalty_cards USING btree (id);


--
-- Name: ix_client_loyalty_cards_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_loyalty_cards_studio_id ON public.client_loyalty_cards USING btree (studio_id);


--
-- Name: ix_client_notes_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_notes_client_id ON public.client_notes USING btree (client_id);


--
-- Name: ix_client_notes_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_notes_id ON public.client_notes USING btree (id);


--
-- Name: ix_client_notes_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_notes_studio_id ON public.client_notes USING btree (studio_id);


--
-- Name: ix_client_offers_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_offers_client_id ON public.client_offers USING btree (client_id);


--
-- Name: ix_client_offers_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_offers_id ON public.client_offers USING btree (id);


--
-- Name: ix_client_offers_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_offers_studio_id ON public.client_offers USING btree (studio_id);


--
-- Name: ix_client_payments_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_payments_id ON public.client_payments USING btree (id);


--
-- Name: ix_client_subscriptions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_subscriptions_id ON public.client_subscriptions USING btree (id);


--
-- Name: ix_clients_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clients_id ON public.clients USING btree (id);


--
-- Name: ix_clients_ig_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clients_ig_id ON public.clients USING btree (ig_id);


--
-- Name: ix_clients_invite_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_clients_invite_code ON public.clients USING btree (invite_code);


--
-- Name: ix_clients_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clients_studio_id ON public.clients USING btree (studio_id);


--
-- Name: ix_clients_tg_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_clients_tg_id ON public.clients USING btree (tg_id);


--
-- Name: ix_counterparties_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_counterparties_id ON public.counterparties USING btree (id);


--
-- Name: ix_counterparties_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_counterparties_studio_id ON public.counterparties USING btree (studio_id);


--
-- Name: ix_daily_metric_snapshots_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_daily_metric_snapshots_date ON public.daily_metric_snapshots USING btree (date);


--
-- Name: ix_daily_metric_snapshots_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_daily_metric_snapshots_id ON public.daily_metric_snapshots USING btree (id);


--
-- Name: ix_daily_metric_snapshots_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_daily_metric_snapshots_studio_id ON public.daily_metric_snapshots USING btree (studio_id);


--
-- Name: ix_deposit_transactions_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deposit_transactions_client_id ON public.deposit_transactions USING btree (client_id);


--
-- Name: ix_deposit_transactions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deposit_transactions_id ON public.deposit_transactions USING btree (id);


--
-- Name: ix_deposit_transactions_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_deposit_transactions_studio_id ON public.deposit_transactions USING btree (studio_id);


--
-- Name: ix_event_attendees_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_attendees_client_id ON public.event_attendees USING btree (client_id);


--
-- Name: ix_event_attendees_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_attendees_event_id ON public.event_attendees USING btree (event_id);


--
-- Name: ix_event_attendees_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_attendees_id ON public.event_attendees USING btree (id);


--
-- Name: ix_event_attendees_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_attendees_studio_id ON public.event_attendees USING btree (studio_id);


--
-- Name: ix_fin_documents_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fin_documents_id ON public.fin_documents USING btree (id);


--
-- Name: ix_fin_documents_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fin_documents_studio_id ON public.fin_documents USING btree (studio_id);


--
-- Name: ix_financial_goals_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_financial_goals_id ON public.financial_goals USING btree (id);


--
-- Name: ix_financial_goals_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_financial_goals_studio_id ON public.financial_goals USING btree (studio_id);


--
-- Name: ix_fx_rates_base; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fx_rates_base ON public.fx_rates USING btree (base);


--
-- Name: ix_fx_rates_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fx_rates_code ON public.fx_rates USING btree (code);


--
-- Name: ix_fx_rates_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fx_rates_id ON public.fx_rates USING btree (id);


--
-- Name: ix_gift_certificates_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gift_certificates_client_id ON public.gift_certificates USING btree (client_id);


--
-- Name: ix_gift_certificates_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gift_certificates_id ON public.gift_certificates USING btree (id);


--
-- Name: ix_gift_certificates_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_gift_certificates_studio_id ON public.gift_certificates USING btree (studio_id);


--
-- Name: ix_halls_branch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_halls_branch_id ON public.halls USING btree (branch_id);


--
-- Name: ix_halls_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_halls_id ON public.halls USING btree (id);


--
-- Name: ix_halls_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_halls_studio_id ON public.halls USING btree (studio_id);


--
-- Name: ix_inbound_events_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inbound_events_id ON public.inbound_events USING btree (id);


--
-- Name: ix_inbound_events_received_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inbound_events_received_at ON public.inbound_events USING btree (received_at);


--
-- Name: ix_inbound_events_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inbound_events_studio_id ON public.inbound_events USING btree (studio_id);


--
-- Name: ix_lessons_gcal_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lessons_gcal_event_id ON public.lessons USING btree (gcal_event_id);


--
-- Name: ix_lessons_hall_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lessons_hall_id ON public.lessons USING btree (hall_id);


--
-- Name: ix_lessons_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lessons_id ON public.lessons USING btree (id);


--
-- Name: ix_lessons_service_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lessons_service_id ON public.lessons USING btree (service_id);


--
-- Name: ix_lessons_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lessons_studio_id ON public.lessons USING btree (studio_id);


--
-- Name: ix_lessons_teacher_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lessons_teacher_id ON public.lessons USING btree (teacher_id);


--
-- Name: ix_loyalty_levels_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_loyalty_levels_id ON public.loyalty_levels USING btree (id);


--
-- Name: ix_loyalty_levels_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_loyalty_levels_studio_id ON public.loyalty_levels USING btree (studio_id);


--
-- Name: ix_loyalty_point_transactions_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_loyalty_point_transactions_client_id ON public.loyalty_point_transactions USING btree (client_id);


--
-- Name: ix_loyalty_point_transactions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_loyalty_point_transactions_id ON public.loyalty_point_transactions USING btree (id);


--
-- Name: ix_loyalty_point_transactions_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_loyalty_point_transactions_studio_id ON public.loyalty_point_transactions USING btree (studio_id);


--
-- Name: ix_loyalty_scenarios_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_loyalty_scenarios_id ON public.loyalty_scenarios USING btree (id);


--
-- Name: ix_loyalty_scenarios_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_loyalty_scenarios_studio_id ON public.loyalty_scenarios USING btree (studio_id);


--
-- Name: ix_notification_event_toggles_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_event_toggles_id ON public.notification_event_toggles USING btree (id);


--
-- Name: ix_notification_event_toggles_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_event_toggles_studio_id ON public.notification_event_toggles USING btree (studio_id);


--
-- Name: ix_notification_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_logs_created_at ON public.notification_logs USING btree (created_at);


--
-- Name: ix_notification_logs_dedup_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_notification_logs_dedup_key ON public.notification_logs USING btree (dedup_key);


--
-- Name: ix_notification_logs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_logs_id ON public.notification_logs USING btree (id);


--
-- Name: ix_notification_logs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_logs_status ON public.notification_logs USING btree (status);


--
-- Name: ix_notification_logs_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_logs_studio_id ON public.notification_logs USING btree (studio_id);


--
-- Name: ix_offline_transaction_fees_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_offline_transaction_fees_created_at ON public.offline_transaction_fees USING btree (created_at);


--
-- Name: ix_offline_transaction_fees_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_offline_transaction_fees_id ON public.offline_transaction_fees USING btree (id);


--
-- Name: ix_offline_transaction_fees_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_offline_transaction_fees_invoice_id ON public.offline_transaction_fees USING btree (invoice_id);


--
-- Name: ix_offline_transaction_fees_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_offline_transaction_fees_studio_id ON public.offline_transaction_fees USING btree (studio_id);


--
-- Name: ix_online_channel_metrics_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_online_channel_metrics_channel_id ON public.online_channel_metrics USING btree (channel_id);


--
-- Name: ix_online_channel_metrics_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_online_channel_metrics_id ON public.online_channel_metrics USING btree (id);


--
-- Name: ix_online_channel_metrics_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_online_channel_metrics_studio_id ON public.online_channel_metrics USING btree (studio_id);


--
-- Name: ix_online_channels_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_online_channels_id ON public.online_channels USING btree (id);


--
-- Name: ix_online_channels_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_online_channels_studio_id ON public.online_channels USING btree (studio_id);


--
-- Name: ix_operations_counterparty_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_operations_counterparty_id ON public.operations USING btree (counterparty_id);


--
-- Name: ix_operations_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_operations_id ON public.operations USING btree (id);


--
-- Name: ix_operations_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_operations_product_id ON public.operations USING btree (product_id);


--
-- Name: ix_operations_service_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_operations_service_id ON public.operations USING btree (service_id);


--
-- Name: ix_operations_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_operations_studio_id ON public.operations USING btree (studio_id);


--
-- Name: ix_operations_trainer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_operations_trainer_id ON public.operations USING btree (trainer_id);


--
-- Name: ix_outbound_messages_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_outbound_messages_created_at ON public.outbound_messages USING btree (created_at);


--
-- Name: ix_outbound_messages_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_outbound_messages_id ON public.outbound_messages USING btree (id);


--
-- Name: ix_outbound_messages_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_outbound_messages_studio_id ON public.outbound_messages USING btree (studio_id);


--
-- Name: ix_outbound_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_outbound_open ON public.outbound_messages USING btree (thread_id, id) WHERE ((status)::text = ANY ((ARRAY['queued'::character varying, 'sending'::character varying])::text[]));


--
-- Name: ix_payment_cards_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payment_cards_id ON public.payment_cards USING btree (id);


--
-- Name: ix_payment_cards_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payment_cards_user_id ON public.payment_cards USING btree (user_id);


--
-- Name: ix_payment_method_configs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payment_method_configs_id ON public.payment_method_configs USING btree (id);


--
-- Name: ix_payment_method_configs_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payment_method_configs_studio_id ON public.payment_method_configs USING btree (studio_id);


--
-- Name: ix_platform_revenue_ledger_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_platform_revenue_ledger_external_id ON public.platform_revenue_ledger USING btree (external_id);


--
-- Name: ix_platform_revenue_ledger_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_platform_revenue_ledger_id ON public.platform_revenue_ledger USING btree (id);


--
-- Name: ix_platform_revenue_ledger_occurred_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_platform_revenue_ledger_occurred_at ON public.platform_revenue_ledger USING btree (occurred_at);


--
-- Name: ix_platform_revenue_ledger_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_platform_revenue_ledger_source ON public.platform_revenue_ledger USING btree (source);


--
-- Name: ix_platform_revenue_ledger_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_platform_revenue_ledger_studio_id ON public.platform_revenue_ledger USING btree (studio_id);


--
-- Name: ix_product_sales_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_sales_client_id ON public.product_sales USING btree (client_id);


--
-- Name: ix_product_sales_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_sales_id ON public.product_sales USING btree (id);


--
-- Name: ix_product_sales_operation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_sales_operation_id ON public.product_sales USING btree (operation_id);


--
-- Name: ix_product_sales_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_sales_product_id ON public.product_sales USING btree (product_id);


--
-- Name: ix_product_sales_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_sales_studio_id ON public.product_sales USING btree (studio_id);


--
-- Name: ix_products_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_products_id ON public.products USING btree (id);


--
-- Name: ix_products_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_products_studio_id ON public.products USING btree (studio_id);


--
-- Name: ix_referral_records_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_referral_records_id ON public.referral_records USING btree (id);


--
-- Name: ix_referral_records_referrer_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_referral_records_referrer_client_id ON public.referral_records USING btree (referrer_client_id);


--
-- Name: ix_referral_records_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_referral_records_studio_id ON public.referral_records USING btree (studio_id);


--
-- Name: ix_reservations_debt_payment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservations_debt_payment_id ON public.reservations USING btree (debt_payment_id);


--
-- Name: ix_reservations_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservations_id ON public.reservations USING btree (id);


--
-- Name: ix_reservations_subscription_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reservations_subscription_id ON public.reservations USING btree (subscription_id);


--
-- Name: ix_salary_payments_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_salary_payments_id ON public.salary_payments USING btree (id);


--
-- Name: ix_salary_payments_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_salary_payments_studio_id ON public.salary_payments USING btree (studio_id);


--
-- Name: ix_salary_payments_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_salary_payments_user_id ON public.salary_payments USING btree (user_id);


--
-- Name: ix_scenario_fires_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_scenario_fires_client_id ON public.scenario_fires USING btree (client_id);


--
-- Name: ix_scenario_fires_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_scenario_fires_id ON public.scenario_fires USING btree (id);


--
-- Name: ix_scenario_fires_scenario_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_scenario_fires_scenario_id ON public.scenario_fires USING btree (scenario_id);


--
-- Name: ix_service_schedule_slots_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_schedule_slots_id ON public.service_schedule_slots USING btree (id);


--
-- Name: ix_service_schedule_slots_service_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_schedule_slots_service_id ON public.service_schedule_slots USING btree (service_id);


--
-- Name: ix_services_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_services_id ON public.services USING btree (id);


--
-- Name: ix_services_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_services_studio_id ON public.services USING btree (studio_id);


--
-- Name: ix_staff_day_overrides_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_staff_day_overrides_id ON public.staff_day_overrides USING btree (id);


--
-- Name: ix_staff_day_overrides_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_staff_day_overrides_studio_id ON public.staff_day_overrides USING btree (studio_id);


--
-- Name: ix_staff_day_overrides_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_staff_day_overrides_user_id ON public.staff_day_overrides USING btree (user_id);


--
-- Name: ix_staff_working_hours_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_staff_working_hours_id ON public.staff_working_hours USING btree (id);


--
-- Name: ix_staff_working_hours_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_staff_working_hours_studio_id ON public.staff_working_hours USING btree (studio_id);


--
-- Name: ix_staff_working_hours_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_staff_working_hours_user_id ON public.staff_working_hours USING btree (user_id);


--
-- Name: ix_stripe_checkouts_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stripe_checkouts_id ON public.stripe_checkouts USING btree (id);


--
-- Name: ix_stripe_checkouts_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_stripe_checkouts_session_id ON public.stripe_checkouts USING btree (session_id);


--
-- Name: ix_stripe_checkouts_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stripe_checkouts_studio_id ON public.stripe_checkouts USING btree (studio_id);


--
-- Name: ix_studio_ai_settings_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_ai_settings_id ON public.studio_ai_settings USING btree (id);


--
-- Name: ix_studio_ai_settings_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_studio_ai_settings_studio_id ON public.studio_ai_settings USING btree (studio_id);


--
-- Name: ix_studio_billing_plans_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_billing_plans_id ON public.studio_billing_plans USING btree (id);


--
-- Name: ix_studio_billing_plans_stripe_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_studio_billing_plans_stripe_customer_id ON public.studio_billing_plans USING btree (stripe_customer_id);


--
-- Name: ix_studio_billing_plans_stripe_subscription_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_studio_billing_plans_stripe_subscription_id ON public.studio_billing_plans USING btree (stripe_subscription_id);


--
-- Name: ix_studio_billing_plans_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_studio_billing_plans_studio_id ON public.studio_billing_plans USING btree (studio_id);


--
-- Name: ix_studio_booking_settings_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_booking_settings_id ON public.studio_booking_settings USING btree (id);


--
-- Name: ix_studio_booking_settings_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_studio_booking_settings_studio_id ON public.studio_booking_settings USING btree (studio_id);


--
-- Name: ix_studio_branches_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_branches_id ON public.studio_branches USING btree (id);


--
-- Name: ix_studio_branches_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_branches_studio_id ON public.studio_branches USING btree (studio_id);


--
-- Name: ix_studio_certificate_configs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_certificate_configs_id ON public.studio_certificate_configs USING btree (id);


--
-- Name: ix_studio_certificate_configs_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_studio_certificate_configs_studio_id ON public.studio_certificate_configs USING btree (studio_id);


--
-- Name: ix_studio_client_segment_configs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_client_segment_configs_id ON public.studio_client_segment_configs USING btree (id);


--
-- Name: ix_studio_client_segment_configs_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_studio_client_segment_configs_studio_id ON public.studio_client_segment_configs USING btree (studio_id);


--
-- Name: ix_studio_discount_configs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_discount_configs_id ON public.studio_discount_configs USING btree (id);


--
-- Name: ix_studio_discount_configs_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_studio_discount_configs_studio_id ON public.studio_discount_configs USING btree (studio_id);


--
-- Name: ix_studio_events_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_events_id ON public.studio_events USING btree (id);


--
-- Name: ix_studio_events_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_events_studio_id ON public.studio_events USING btree (studio_id);


--
-- Name: ix_studio_events_trainer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_events_trainer_id ON public.studio_events USING btree (trainer_id);


--
-- Name: ix_studio_feature_flags_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_feature_flags_id ON public.studio_feature_flags USING btree (id);


--
-- Name: ix_studio_feature_flags_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_feature_flags_studio_id ON public.studio_feature_flags USING btree (studio_id);


--
-- Name: ix_studio_integrations_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_integrations_id ON public.studio_integrations USING btree (id);


--
-- Name: ix_studio_integrations_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_integrations_studio_id ON public.studio_integrations USING btree (studio_id);


--
-- Name: ix_studio_loyalty_configs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_loyalty_configs_id ON public.studio_loyalty_configs USING btree (id);


--
-- Name: ix_studio_loyalty_configs_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_studio_loyalty_configs_studio_id ON public.studio_loyalty_configs USING btree (studio_id);


--
-- Name: ix_studio_members_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_members_id ON public.studio_members USING btree (id);


--
-- Name: ix_studio_members_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_members_studio_id ON public.studio_members USING btree (studio_id);


--
-- Name: ix_studio_members_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_members_user_id ON public.studio_members USING btree (user_id);


--
-- Name: ix_studio_notification_settings_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_notification_settings_id ON public.studio_notification_settings USING btree (id);


--
-- Name: ix_studio_notification_settings_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_studio_notification_settings_studio_id ON public.studio_notification_settings USING btree (studio_id);


--
-- Name: ix_studio_promo_codes_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_promo_codes_id ON public.studio_promo_codes USING btree (id);


--
-- Name: ix_studio_promo_codes_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_promo_codes_studio_id ON public.studio_promo_codes USING btree (studio_id);


--
-- Name: ix_studio_referral_configs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_referral_configs_id ON public.studio_referral_configs USING btree (id);


--
-- Name: ix_studio_referral_configs_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_studio_referral_configs_studio_id ON public.studio_referral_configs USING btree (studio_id);


--
-- Name: ix_studio_reviews_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_reviews_client_id ON public.studio_reviews USING btree (client_id);


--
-- Name: ix_studio_reviews_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_reviews_event_id ON public.studio_reviews USING btree (event_id);


--
-- Name: ix_studio_reviews_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_reviews_id ON public.studio_reviews USING btree (id);


--
-- Name: ix_studio_reviews_lesson_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_reviews_lesson_id ON public.studio_reviews USING btree (lesson_id);


--
-- Name: ix_studio_reviews_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_reviews_studio_id ON public.studio_reviews USING btree (studio_id);


--
-- Name: ix_studio_subscription_program_configs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_subscription_program_configs_id ON public.studio_subscription_program_configs USING btree (id);


--
-- Name: ix_studio_subscription_program_configs_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_studio_subscription_program_configs_studio_id ON public.studio_subscription_program_configs USING btree (studio_id);


--
-- Name: ix_studio_tasks_assignee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_tasks_assignee_id ON public.studio_tasks USING btree (assignee_id);


--
-- Name: ix_studio_tasks_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_tasks_id ON public.studio_tasks USING btree (id);


--
-- Name: ix_studio_tasks_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_tasks_studio_id ON public.studio_tasks USING btree (studio_id);


--
-- Name: ix_studio_working_hours_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_working_hours_id ON public.studio_working_hours USING btree (id);


--
-- Name: ix_studio_working_hours_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studio_working_hours_studio_id ON public.studio_working_hours USING btree (studio_id);


--
-- Name: ix_studios_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_studios_id ON public.studios USING btree (id);


--
-- Name: ix_subscription_packages_config_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_subscription_packages_config_id ON public.subscription_packages USING btree (config_id);


--
-- Name: ix_subscription_packages_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_subscription_packages_id ON public.subscription_packages USING btree (id);


--
-- Name: ix_subscription_packages_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_subscription_packages_studio_id ON public.subscription_packages USING btree (studio_id);


--
-- Name: ix_thread_options_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_thread_options_expires ON public.thread_options USING btree (expires_at);


--
-- Name: ix_thread_options_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_thread_options_id ON public.thread_options USING btree (id);


--
-- Name: ix_thread_options_pick; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_thread_options_pick ON public.thread_options USING btree (thread_id, search_version, ordinal);


--
-- Name: ix_thread_options_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_thread_options_studio_id ON public.thread_options USING btree (studio_id);


--
-- Name: ix_thread_options_thread_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_thread_options_thread_id ON public.thread_options USING btree (thread_id);


--
-- Name: ix_trainer_sales_goals_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trainer_sales_goals_id ON public.trainer_sales_goals USING btree (id);


--
-- Name: ix_trainer_sales_goals_studio_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trainer_sales_goals_studio_id ON public.trainer_sales_goals USING btree (studio_id);


--
-- Name: ix_trainer_sales_goals_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trainer_sales_goals_user_id ON public.trainer_sales_goals USING btree (user_id);


--
-- Name: ix_user_consents_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_consents_user_id ON public.user_consents USING btree (user_id);


--
-- Name: ix_user_notification_preferences_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_notification_preferences_id ON public.user_notification_preferences USING btree (id);


--
-- Name: ix_user_notification_preferences_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_notification_preferences_user_id ON public.user_notification_preferences USING btree (user_id);


--
-- Name: ix_user_sessions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_sessions_id ON public.user_sessions USING btree (id);


--
-- Name: ix_user_sessions_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_sessions_token_hash ON public.user_sessions USING btree (token_hash);


--
-- Name: ix_user_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_primary_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_primary_user_id ON public.users USING btree (primary_user_id);


--
-- Name: uq_outbound_thread_sending; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_outbound_thread_sending ON public.outbound_messages USING btree (thread_id) WHERE ((status)::text = 'sending'::text);


--
-- Name: uq_reservation_spot_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_reservation_spot_active ON public.reservations USING btree (lesson_id, spot_number) WHERE ((status)::text <> 'cancelled'::text);


--
-- Name: uq_users_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_users_phone ON public.users USING btree (phone) WHERE ((phone IS NOT NULL) AND ((phone)::text <> ''::text));


--
-- Name: uq_users_tg_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_users_tg_id ON public.users USING btree (tg_id) WHERE (tg_id IS NOT NULL);


--
-- Name: accounts accounts_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: agent_jobs agent_jobs_inbound_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_jobs
    ADD CONSTRAINT agent_jobs_inbound_event_id_fkey FOREIGN KEY (inbound_event_id) REFERENCES public.inbound_events(id) ON DELETE CASCADE;


--
-- Name: ai_chat_messages ai_chat_messages_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.ai_chat_sessions(id) ON DELETE CASCADE;


--
-- Name: ai_chat_sessions ai_chat_sessions_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: ai_chat_sessions ai_chat_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ai_studio_facts ai_studio_facts_author_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_studio_facts
    ADD CONSTRAINT ai_studio_facts_author_user_id_fkey FOREIGN KEY (author_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ai_studio_facts ai_studio_facts_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_studio_facts
    ADD CONSTRAINT ai_studio_facts_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: ai_usage ai_usage_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage
    ADD CONSTRAINT ai_usage_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: ai_usage ai_usage_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage
    ADD CONSTRAINT ai_usage_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: billing_invoices billing_invoices_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_invoices
    ADD CONSTRAINT billing_invoices_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: billing_invoices billing_invoices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_invoices
    ADD CONSTRAINT billing_invoices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: booking_channel_configs booking_channel_configs_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_channel_configs
    ADD CONSTRAINT booking_channel_configs_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: branch_working_hours branch_working_hours_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branch_working_hours
    ADD CONSTRAINT branch_working_hours_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.studio_branches(id) ON DELETE CASCADE;


--
-- Name: channel_threads channel_threads_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_threads
    ADD CONSTRAINT channel_threads_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: client_email_otp client_email_otp_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_email_otp
    ADD CONSTRAINT client_email_otp_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: client_loyalty_cards client_loyalty_cards_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_loyalty_cards
    ADD CONSTRAINT client_loyalty_cards_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: client_loyalty_cards client_loyalty_cards_level_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_loyalty_cards
    ADD CONSTRAINT client_loyalty_cards_level_id_fkey FOREIGN KEY (level_id) REFERENCES public.loyalty_levels(id) ON DELETE SET NULL;


--
-- Name: client_loyalty_cards client_loyalty_cards_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_loyalty_cards
    ADD CONSTRAINT client_loyalty_cards_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: client_notes client_notes_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_notes
    ADD CONSTRAINT client_notes_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: client_notes client_notes_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_notes
    ADD CONSTRAINT client_notes_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: client_notes client_notes_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_notes
    ADD CONSTRAINT client_notes_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: client_offers client_offers_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_offers
    ADD CONSTRAINT client_offers_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: client_offers client_offers_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_offers
    ADD CONSTRAINT client_offers_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: client_payments client_payments_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_payments
    ADD CONSTRAINT client_payments_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: client_subscriptions client_subscriptions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_subscriptions
    ADD CONSTRAINT client_subscriptions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: clients clients_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: counterparties counterparties_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: daily_metric_snapshots daily_metric_snapshots_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_metric_snapshots
    ADD CONSTRAINT daily_metric_snapshots_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: deposit_transactions deposit_transactions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deposit_transactions
    ADD CONSTRAINT deposit_transactions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: deposit_transactions deposit_transactions_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deposit_transactions
    ADD CONSTRAINT deposit_transactions_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: event_attendees event_attendees_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendees
    ADD CONSTRAINT event_attendees_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: event_attendees event_attendees_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendees
    ADD CONSTRAINT event_attendees_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.studio_events(id) ON DELETE CASCADE;


--
-- Name: event_attendees event_attendees_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_attendees
    ADD CONSTRAINT event_attendees_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: fin_documents fin_documents_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fin_documents
    ADD CONSTRAINT fin_documents_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE SET NULL;


--
-- Name: fin_documents fin_documents_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fin_documents
    ADD CONSTRAINT fin_documents_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: financial_goals financial_goals_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_goals
    ADD CONSTRAINT financial_goals_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: client_subscriptions fk_client_subscriptions_package_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_subscriptions
    ADD CONSTRAINT fk_client_subscriptions_package_id FOREIGN KEY (package_id) REFERENCES public.subscription_packages(id) ON DELETE SET NULL;


--
-- Name: halls fk_halls_branch_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.halls
    ADD CONSTRAINT fk_halls_branch_id FOREIGN KEY (branch_id) REFERENCES public.studio_branches(id) ON DELETE SET NULL;


--
-- Name: operations fk_operations_service_id_services; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT fk_operations_service_id_services FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE SET NULL;


--
-- Name: reservations fk_reservations_debt_payment_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT fk_reservations_debt_payment_id FOREIGN KEY (debt_payment_id) REFERENCES public.client_payments(id) ON DELETE SET NULL;


--
-- Name: reservations fk_reservations_subscription_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT fk_reservations_subscription_id FOREIGN KEY (subscription_id) REFERENCES public.client_subscriptions(id) ON DELETE SET NULL;


--
-- Name: staff_working_hours fk_staff_working_hours_studio; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_working_hours
    ADD CONSTRAINT fk_staff_working_hours_studio FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: stripe_checkouts fk_stripe_checkouts_subscription_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stripe_checkouts
    ADD CONSTRAINT fk_stripe_checkouts_subscription_id FOREIGN KEY (subscription_id) REFERENCES public.client_subscriptions(id) ON DELETE SET NULL;


--
-- Name: users fk_users_last_studio_id_studios; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_last_studio_id_studios FOREIGN KEY (last_studio_id) REFERENCES public.studios(id) ON DELETE SET NULL;


--
-- Name: gift_certificates gift_certificates_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_certificates
    ADD CONSTRAINT gift_certificates_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: gift_certificates gift_certificates_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_certificates
    ADD CONSTRAINT gift_certificates_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: halls halls_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.halls
    ADD CONSTRAINT halls_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: inbound_events inbound_events_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inbound_events
    ADD CONSTRAINT inbound_events_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: lessons lessons_hall_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_hall_id_fkey FOREIGN KEY (hall_id) REFERENCES public.halls(id) ON DELETE SET NULL;


--
-- Name: lessons lessons_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE SET NULL;


--
-- Name: lessons lessons_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: lessons lessons_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: loyalty_levels loyalty_levels_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_levels
    ADD CONSTRAINT loyalty_levels_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: loyalty_point_transactions loyalty_point_transactions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_point_transactions
    ADD CONSTRAINT loyalty_point_transactions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: loyalty_point_transactions loyalty_point_transactions_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_point_transactions
    ADD CONSTRAINT loyalty_point_transactions_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: loyalty_scenarios loyalty_scenarios_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_scenarios
    ADD CONSTRAINT loyalty_scenarios_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: notification_event_toggles notification_event_toggles_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_event_toggles
    ADD CONSTRAINT notification_event_toggles_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: notification_logs notification_logs_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: offline_transaction_fees offline_transaction_fees_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offline_transaction_fees
    ADD CONSTRAINT offline_transaction_fees_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: offline_transaction_fees offline_transaction_fees_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offline_transaction_fees
    ADD CONSTRAINT offline_transaction_fees_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.billing_invoices(id) ON DELETE SET NULL;


--
-- Name: offline_transaction_fees offline_transaction_fees_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offline_transaction_fees
    ADD CONSTRAINT offline_transaction_fees_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: online_channel_metrics online_channel_metrics_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_channel_metrics
    ADD CONSTRAINT online_channel_metrics_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.online_channels(id) ON DELETE CASCADE;


--
-- Name: online_channel_metrics online_channel_metrics_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_channel_metrics
    ADD CONSTRAINT online_channel_metrics_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: online_channels online_channels_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_channels
    ADD CONSTRAINT online_channels_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: operations operations_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE SET NULL;


--
-- Name: operations operations_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: operations operations_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON DELETE SET NULL;


--
-- Name: operations operations_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: operations operations_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: operations operations_trainer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_trainer_id_fkey FOREIGN KEY (trainer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: outbound_messages outbound_messages_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbound_messages
    ADD CONSTRAINT outbound_messages_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: outbound_messages outbound_messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbound_messages
    ADD CONSTRAINT outbound_messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.channel_threads(id) ON DELETE CASCADE;


--
-- Name: payment_cards payment_cards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_cards
    ADD CONSTRAINT payment_cards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_method_configs payment_method_configs_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_method_configs
    ADD CONSTRAINT payment_method_configs_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: platform_revenue_ledger platform_revenue_ledger_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_revenue_ledger
    ADD CONSTRAINT platform_revenue_ledger_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: product_sales product_sales_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_sales
    ADD CONSTRAINT product_sales_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: product_sales product_sales_operation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_sales
    ADD CONSTRAINT product_sales_operation_id_fkey FOREIGN KEY (operation_id) REFERENCES public.operations(id) ON DELETE SET NULL;


--
-- Name: product_sales product_sales_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_sales
    ADD CONSTRAINT product_sales_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: product_sales product_sales_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_sales
    ADD CONSTRAINT product_sales_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: products products_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: referral_records referral_records_referred_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_records
    ADD CONSTRAINT referral_records_referred_client_id_fkey FOREIGN KEY (referred_client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: referral_records referral_records_referrer_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_records
    ADD CONSTRAINT referral_records_referrer_client_id_fkey FOREIGN KEY (referrer_client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: referral_records referral_records_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_records
    ADD CONSTRAINT referral_records_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: reservations reservations_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: reservations reservations_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id) ON DELETE CASCADE;


--
-- Name: salary_payments salary_payments_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_payments
    ADD CONSTRAINT salary_payments_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: salary_payments salary_payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_payments
    ADD CONSTRAINT salary_payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: scenario_fires scenario_fires_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scenario_fires
    ADD CONSTRAINT scenario_fires_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: scenario_fires scenario_fires_scenario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scenario_fires
    ADD CONSTRAINT scenario_fires_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES public.loyalty_scenarios(id) ON DELETE CASCADE;


--
-- Name: service_schedule_slots service_schedule_slots_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_schedule_slots
    ADD CONSTRAINT service_schedule_slots_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: services services_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: staff_day_overrides staff_day_overrides_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_day_overrides
    ADD CONSTRAINT staff_day_overrides_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: staff_day_overrides staff_day_overrides_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_day_overrides
    ADD CONSTRAINT staff_day_overrides_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: staff_working_hours staff_working_hours_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_working_hours
    ADD CONSTRAINT staff_working_hours_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stripe_checkouts stripe_checkouts_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stripe_checkouts
    ADD CONSTRAINT stripe_checkouts_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: stripe_checkouts stripe_checkouts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stripe_checkouts
    ADD CONSTRAINT stripe_checkouts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: studio_ai_settings studio_ai_settings_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_ai_settings
    ADD CONSTRAINT studio_ai_settings_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_billing_plans studio_billing_plans_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_billing_plans
    ADD CONSTRAINT studio_billing_plans_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_booking_settings studio_booking_settings_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_booking_settings
    ADD CONSTRAINT studio_booking_settings_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_branches studio_branches_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_branches
    ADD CONSTRAINT studio_branches_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_certificate_configs studio_certificate_configs_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_certificate_configs
    ADD CONSTRAINT studio_certificate_configs_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE SET NULL;


--
-- Name: studio_certificate_configs studio_certificate_configs_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_certificate_configs
    ADD CONSTRAINT studio_certificate_configs_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_client_segment_configs studio_client_segment_configs_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_client_segment_configs
    ADD CONSTRAINT studio_client_segment_configs_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_discount_configs studio_discount_configs_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_discount_configs
    ADD CONSTRAINT studio_discount_configs_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_events studio_events_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_events
    ADD CONSTRAINT studio_events_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_events studio_events_trainer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_events
    ADD CONSTRAINT studio_events_trainer_id_fkey FOREIGN KEY (trainer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: studio_feature_flags studio_feature_flags_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_feature_flags
    ADD CONSTRAINT studio_feature_flags_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_integrations studio_integrations_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_integrations
    ADD CONSTRAINT studio_integrations_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_loyalty_configs studio_loyalty_configs_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_loyalty_configs
    ADD CONSTRAINT studio_loyalty_configs_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_members studio_members_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_members
    ADD CONSTRAINT studio_members_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_members studio_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_members
    ADD CONSTRAINT studio_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: studio_notification_settings studio_notification_settings_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_notification_settings
    ADD CONSTRAINT studio_notification_settings_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_promo_codes studio_promo_codes_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_promo_codes
    ADD CONSTRAINT studio_promo_codes_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_referral_configs studio_referral_configs_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_referral_configs
    ADD CONSTRAINT studio_referral_configs_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_reviews studio_reviews_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_reviews
    ADD CONSTRAINT studio_reviews_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: studio_reviews studio_reviews_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_reviews
    ADD CONSTRAINT studio_reviews_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.studio_events(id) ON DELETE SET NULL;


--
-- Name: studio_reviews studio_reviews_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_reviews
    ADD CONSTRAINT studio_reviews_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id) ON DELETE SET NULL;


--
-- Name: studio_reviews studio_reviews_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_reviews
    ADD CONSTRAINT studio_reviews_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_subscription_program_configs studio_subscription_program_configs_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_subscription_program_configs
    ADD CONSTRAINT studio_subscription_program_configs_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_tasks studio_tasks_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_tasks
    ADD CONSTRAINT studio_tasks_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: studio_tasks studio_tasks_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_tasks
    ADD CONSTRAINT studio_tasks_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: studio_tasks studio_tasks_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_tasks
    ADD CONSTRAINT studio_tasks_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: studio_working_hours studio_working_hours_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.studio_working_hours
    ADD CONSTRAINT studio_working_hours_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: subscription_packages subscription_packages_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_packages
    ADD CONSTRAINT subscription_packages_config_id_fkey FOREIGN KEY (config_id) REFERENCES public.studio_subscription_program_configs(id) ON DELETE CASCADE;


--
-- Name: subscription_packages subscription_packages_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_packages
    ADD CONSTRAINT subscription_packages_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: thread_options thread_options_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_options
    ADD CONSTRAINT thread_options_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id) ON DELETE CASCADE;


--
-- Name: thread_options thread_options_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_options
    ADD CONSTRAINT thread_options_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: thread_options thread_options_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_options
    ADD CONSTRAINT thread_options_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.channel_threads(id) ON DELETE CASCADE;


--
-- Name: trainer_sales_goals trainer_sales_goals_studio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer_sales_goals
    ADD CONSTRAINT trainer_sales_goals_studio_id_fkey FOREIGN KEY (studio_id) REFERENCES public.studios(id) ON DELETE CASCADE;


--
-- Name: trainer_sales_goals trainer_sales_goals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trainer_sales_goals
    ADD CONSTRAINT trainer_sales_goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_consents user_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_consents
    ADD CONSTRAINT user_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_notification_preferences user_notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_services user_services_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_services
    ADD CONSTRAINT user_services_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: user_services user_services_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_services
    ADD CONSTRAINT user_services_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_primary_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_primary_user_id_fkey FOREIGN KEY (primary_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 1Zpiw87ABIhhd1Uujbq4RYCe3wgfQmIsacqHae9HMEU54fzRiTy5b9d5vmjwr7V

